⚽  NEON FOOTBALL
=================
Build your legacy from nothing. Take a club from Division 4 to the top: pick your
squad and tactics, buy and sell players, and watch every match live on the pitch.


▶ HOW TO PLAY
-------------
1. Unzip this folder.
2. Double-click  "Neon Football.html"
3. That's it — it opens in your web browser.

• No internet needed, nothing to install.
• Works in Chrome, Edge, Firefox and Safari. Best on a computer or tablet.


💾 SAVING
---------
Your career saves automatically in the browser you play in.
• Close it and come back later — you'll carry on where you left off.
• Use the SAME browser on the SAME computer to keep your save.
• Clearing your browser's history/site data will delete your save.
• If your progress ever doesn't save, try Chrome or Edge.


🎮 QUICK GUIDE
--------------
• Squad       Pick your starting eleven, tactics and player roles.
• Transfers   Scout, buy and sell players.
• Season      Your fixtures — press MATCH DAY, then PLAY MATCH.
• Table       The league: top 3 go up, bottom 3 go down.

During a match:
• ⏸ Pause any time to make substitutions or change tactics and formation.
  Changes happen at the next stoppage — a throw-in, goal kick, foul or goal.
• 1x / 2x / 4x  Change the match speed.
• 🗺️ Pitch   Watch the match live: tackles, shots, corners, free kicks and more.
• ⚡ Tempo   See how fast and how fierce the match is, and why.


📁 WHAT'S IN THIS FOLDER
-----------------------
Neon Football.html           The game. Double-click to play.
README.txt                   This file.
source/football-manager.jsx  The game's source code, for anyone who wants to
                             look inside or build on it.

Have fun, boss! 🏆
