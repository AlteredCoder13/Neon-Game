import { useState, useMemo, useCallback, useEffect, useRef } from "react";

/* ═══════════════════════════════════════════════════════════════════════
   FORMATIONS
   ═══════════════════════════════════════════════════════════════════════ */

const FORMATIONS = {
  "4-3-3": {
    positions: ["GK", "LB", "CB", "CB", "RB", "CM", "CM", "CM", "LW", "ST", "RW"],
    coords: [
      { x: 50, y: 90 },
      { x: 12, y: 68 }, { x: 35, y: 74 }, { x: 65, y: 74 }, { x: 88, y: 68 },
      { x: 25, y: 48 }, { x: 50, y: 44 }, { x: 75, y: 48 },
      { x: 15, y: 22 }, { x: 50, y: 16 }, { x: 85, y: 22 },
    ],
    style: "attacking",
  },
  "4-4-2": {
    positions: ["GK", "LB", "CB", "CB", "RB", "LM", "CM", "CM", "RM", "ST", "ST"],
    coords: [
      { x: 50, y: 90 },
      { x: 12, y: 68 }, { x: 35, y: 74 }, { x: 65, y: 74 }, { x: 88, y: 68 },
      { x: 12, y: 46 }, { x: 38, y: 50 }, { x: 62, y: 50 }, { x: 88, y: 46 },
      { x: 35, y: 20 }, { x: 65, y: 20 },
    ],
    style: "balanced",
  },
  "3-5-2": {
    positions: ["GK", "CB", "CB", "CB", "LWB", "CM", "CDM", "CM", "RWB", "ST", "ST"],
    coords: [
      { x: 50, y: 90 },
      { x: 25, y: 74 }, { x: 50, y: 76 }, { x: 75, y: 74 },
      { x: 10, y: 50 }, { x: 32, y: 46 }, { x: 50, y: 52 }, { x: 68, y: 46 }, { x: 90, y: 50 },
      { x: 35, y: 20 }, { x: 65, y: 20 },
    ],
    style: "midfield",
  },
  "4-2-3-1": {
    positions: ["GK", "LB", "CB", "CB", "RB", "CDM", "CDM", "LW", "CAM", "RW", "ST"],
    coords: [
      { x: 50, y: 90 },
      { x: 12, y: 68 }, { x: 35, y: 74 }, { x: 65, y: 74 }, { x: 88, y: 68 },
      { x: 35, y: 52 }, { x: 65, y: 52 },
      { x: 15, y: 32 }, { x: 50, y: 30 }, { x: 85, y: 32 },
      { x: 50, y: 14 },
    ],
    style: "defensive",
  },
  "5-3-2": {
    positions: ["GK", "LWB", "CB", "CB", "CB", "RWB", "CM", "CM", "CM", "ST", "ST"],
    coords: [
      { x: 50, y: 90 },
      { x: 8, y: 64 }, { x: 28, y: 74 }, { x: 50, y: 76 }, { x: 72, y: 74 }, { x: 92, y: 64 },
      { x: 25, y: 46 }, { x: 50, y: 42 }, { x: 75, y: 46 },
      { x: 35, y: 20 }, { x: 65, y: 20 },
    ],
    style: "ultradef",
  },
  "4-1-2-1-2": {
    positions: ["GK", "LB", "CB", "CB", "RB", "CDM", "LM", "RM", "CAM", "ST", "ST"],
    coords: [
      { x: 50, y: 90 },
      { x: 12, y: 68 }, { x: 35, y: 74 }, { x: 65, y: 74 }, { x: 88, y: 68 },
      { x: 50, y: 56 },
      { x: 20, y: 42 }, { x: 80, y: 42 },
      { x: 50, y: 30 },
      { x: 35, y: 16 }, { x: 65, y: 16 },
    ],
    style: "narrow",
  },
  "3-4-3": {
    positions: ["GK", "CB", "CB", "CB", "LM", "CM", "CM", "RM", "LW", "ST", "RW"],
    coords: [
      { x: 50, y: 90 },
      { x: 25, y: 74 }, { x: 50, y: 76 }, { x: 75, y: 74 },
      { x: 10, y: 48 }, { x: 38, y: 50 }, { x: 62, y: 50 }, { x: 90, y: 48 },
      { x: 15, y: 22 }, { x: 50, y: 16 }, { x: 85, y: 22 },
    ],
    style: "ultraatk",
  },
  "4-5-1": {
    positions: ["GK", "LB", "CB", "CB", "RB", "LM", "CM", "CDM", "CM", "RM", "ST"],
    coords: [
      { x: 50, y: 90 },
      { x: 12, y: 68 }, { x: 35, y: 74 }, { x: 65, y: 74 }, { x: 88, y: 68 },
      { x: 10, y: 46 }, { x: 32, y: 48 }, { x: 50, y: 52 }, { x: 68, y: 48 }, { x: 90, y: 46 },
      { x: 50, y: 18 },
    ],
    style: "packed_mid",
  },
  "4-1-4-1": {
    positions: ["GK", "LB", "CB", "CB", "RB", "CDM", "LM", "CM", "CM", "RM", "ST"],
    coords: [
      { x: 50, y: 90 },
      { x: 12, y: 68 }, { x: 35, y: 74 }, { x: 65, y: 74 }, { x: 88, y: 68 },
      { x: 50, y: 56 },
      { x: 10, y: 40 }, { x: 35, y: 42 }, { x: 65, y: 42 }, { x: 90, y: 40 },
      { x: 50, y: 18 },
    ],
    style: "midblock",
  },
  "5-4-1": {
    positions: ["GK", "LWB", "CB", "CB", "CB", "RWB", "LM", "CM", "CM", "RM", "ST"],
    coords: [
      { x: 50, y: 90 },
      { x: 8, y: 64 }, { x: 28, y: 74 }, { x: 50, y: 76 }, { x: 72, y: 74 }, { x: 92, y: 64 },
      { x: 12, y: 44 }, { x: 38, y: 46 }, { x: 62, y: 46 }, { x: 88, y: 44 },
      { x: 50, y: 18 },
    ],
    style: "bunker",
  },
  "3-4-2-1": {
    positions: ["GK", "CB", "CB", "CB", "LM", "CM", "CM", "RM", "CAM", "CAM", "ST"],
    coords: [
      { x: 50, y: 90 },
      { x: 25, y: 74 }, { x: 50, y: 76 }, { x: 75, y: 74 },
      { x: 10, y: 50 }, { x: 38, y: 52 }, { x: 62, y: 52 }, { x: 90, y: 50 },
      { x: 35, y: 30 }, { x: 65, y: 30 },
      { x: 50, y: 14 },
    ],
    style: "creative",
  },
};

const FORMATION_KEYS = Object.keys(FORMATIONS);

/* ═══════════════════════════════════════════════════════════════════════
   FORMATION MATCHUP TABLE
   Each formation has advantages/disadvantages vs others.
   Positive = advantage for the first formation.
   ═══════════════════════════════════════════════════════════════════════ */

/* ═══════════════════════════════════════════════════════════════════════
   DYNAMIC SHAPE — the same formation looks different in possession
   Roles, focus and team behaviour physically move players.
   ═══════════════════════════════════════════════════════════════════════ */

// Roles that tuck inside when the team has the ball
const INVERTING_ROLES = new Set([
  "Inverted Fullback", "Inverted Winger", "Inside Forward", "Inside Midfielder",
  "Half-Winger", "Mezzala", "False 9", "Trequartista", "Raumdeuter",
]);
// Roles that push high up the pitch in possession
const ADVANCING_ROLES = new Set([
  "Attacking Fullback", "Wing-Back", "Complete Wing-Back", "Shadow Striker",
  "Advanced Forward", "Poacher", "Pace Merchant", "Box-to-Box", "Libero",
  "Advanced Playmaker", "Pressing Forward", "Wide Forward",
]);
// Roles that stay deep / drop even deeper
const ANCHORING_ROLES = new Set([
  "Anchor", "Holding Midfielder", "Half-Back", "Defensive Fullback",
  "Defensive Wing-Back", "Deep Playmaker", "Deep-Lying Playmaker",
  "Stopper", "Leader", "Goalkeeper", "Shot Stopper", "Defensive Winger",
]);

const FOCUS_SHIFT = {
  Attack: -9, Support: -3, Balanced: 0, Defend: 6, "Build-Up": 5,
};

// ── How each role moves on the live map ──
// fwdIn  push forward when we have the ball (pitch %, toward their goal)
// inIn   drift inside (+) or hug the touchline (−) when we have the ball
// fwdOut step up (+) or drop off (−) when they have the ball
// press  how hard he hunts the ball when they have it (0–1)
// seek   how much he comes toward the ball to offer an option (0–1)
// roam   how freely he wanders from his spot (0–1), scaled by creative freedom
const ROLE_MOVEMENT = {
  "Goalkeeper":           { roam: 0 },
  "Shot Stopper":         { roam: 0 },
  "Sweeper Keeper":       { fwdIn: 7, roam: 0.05 },
  "Stopper":              { fwdOut: 5, press: 0.35, roam: 0.12 },
  "Ball-Playing CB":      { fwdIn: 4, seek: 0.1, roam: 0.12 },
  "Leader":               { roam: 0.1 },
  "Libero":               { fwdIn: 9, seek: 0.25, roam: 0.4 },
  "Defensive Fullback":   { fwdIn: 3, roam: 0.12 },
  "Attacking Fullback":   { fwdIn: 18, inIn: -3, roam: 0.35 },
  "Inverted Fullback":    { fwdIn: 10, inIn: 15, roam: 0.3 },
  "Wing-Back":            { fwdIn: 22, inIn: -3, roam: 0.4 },
  "Complete Wing-Back":   { fwdIn: 26, inIn: -4, roam: 0.5, seek: 0.15 },
  "Defensive Wing-Back":  { fwdIn: 10, roam: 0.2 },
  "Destroyer":            { fwdOut: 4, press: 0.65, roam: 0.45 },
  "Deep Playmaker":       { fwdIn: -3, seek: 0.35, roam: 0.25 },
  "Deep-Lying Playmaker": { fwdIn: -3, seek: 0.35, roam: 0.25 },
  "Holding Midfielder":   { fwdIn: -2, press: 0.2, roam: 0.1 },
  "Anchor":               { roam: 0.03 },
  "Half-Back":            { fwdIn: -14, inIn: 6, roam: 0.1 },
  "Box-to-Box":           { fwdIn: 16, press: 0.4, roam: 0.6 },
  "Playmaker":            { fwdIn: 6, seek: 0.4, roam: 0.45 },
  "Mezzala":              { fwdIn: 14, inIn: -12, roam: 0.55 },
  "Carrilero":            { press: 0.3, roam: 0.35 },
  "Pressing Midfielder":  { fwdOut: 5, press: 0.7, roam: 0.5 },
  "Inside Midfielder":    { fwdIn: 6, roam: 0.3 },
  "Utility":              { roam: 0.25 },
  "Advanced Playmaker":   { fwdIn: 10, seek: 0.45, roam: 0.6 },
  "Enganche":             { fwdIn: 4, seek: 0.3, roam: 0.08 },
  "Shadow Striker":       { fwdIn: 16, roam: 0.55 },
  "Trequartista":         { fwdIn: 8, seek: 0.5, press: 0.05, roam: 1.0 },
  "Winger":               { fwdIn: 10, inIn: -6, roam: 0.4 },
  "Inverted Winger":      { fwdIn: 12, inIn: 16, roam: 0.5 },
  "Inside Forward":       { fwdIn: 14, inIn: 16, roam: 0.5 },
  "Wide Playmaker":       { fwdIn: 6, inIn: 12, seek: 0.35, roam: 0.5 },
  "Wide Midfielder":      { fwdIn: 6, roam: 0.3 },
  "Defensive Winger":     { fwdOut: -8, press: 0.4, roam: 0.3 },
  "Half-Winger":          { fwdIn: 8, inIn: 8, roam: 0.4 },
  "Raumdeuter":           { fwdIn: 16, inIn: 10, roam: 0.8 },
  "Wide Forward":         { fwdIn: 14, inIn: 4, roam: 0.4 },
  "Pace Merchant":        { fwdIn: 16, roam: 0.35 },
  "Poacher":              { fwdIn: 8, press: 0.05, roam: 0.2 },
  "Advanced Forward":     { fwdIn: 10, press: 0.3, roam: 0.4 },
  "Complete Forward":     { fwdIn: 4, seek: 0.3, roam: 0.6 },
  "Deep-Lying Forward":   { fwdIn: -12, seek: 0.35, roam: 0.45 },
  "Target Man":           { fwdIn: 4, roam: 0.1 },
  "Pressing Forward":     { fwdOut: 6, press: 0.85, roam: 0.55 },
  "Aerial Threat":        { fwdIn: 6, roam: 0.15 },
};

// A small surname pool means most squads have two "Kowalski"s. Add the first
// initial only where a surname actually clashes, so the map stays readable.
// Escalates only as far as needed: "Santos" → "E. Santos" → "Emile Santos",
// and numbers the rare players who share an identical full name.
function withLabels(list) {
  const variants = (p) => [
    p.lastName,
    `${(p.firstName || "?")[0]}. ${p.lastName}`,
    `${p.firstName || ""} ${p.lastName}`.trim(),
  ];
  const labels = list.map(() => null);
  for (let lvl = 0; lvl < 3; lvl++) {
    const counts = {};
    list.forEach((p, i) => { if (labels[i] === null) { const k = variants(p)[lvl]; counts[k] = (counts[k] || 0) + 1; } });
    list.forEach((p, i) => { if (labels[i] === null && counts[variants(p)[lvl]] === 1) labels[i] = variants(p)[lvl]; });
  }
  const seen = {};
  list.forEach((p, i) => {
    if (labels[i] !== null) return;
    const k = variants(p)[1];
    seen[k] = (seen[k] || 0) + 1;
    labels[i] = `${k} ${seen[k]}`;
  });
  return list.map((p, i) => ({ ...p, label: labels[i] }));
}

function focusMods(focus) {
  const f = String(focus || "").toLowerCase();
  if (f.includes("att")) return { inMul: 1.3, outAdd: 2 };
  if (f.includes("def")) return { inMul: 0.6, outAdd: -3 };
  return { inMul: 1, outAdd: 0 };
}

function seedOf(id) {
  const str = String(id || "");
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
  return h;
}

// Where every player on the live map should be right now. Starts from the
// formation spot, then layers on: the team block moving with the play, the
// tactic (width, defensive line, pressing, creative freedom, tempo), each
// player's role and focus, and how he reacts to the ball.
function computeLivePositions(live) {
  const play = live.play;
  const attackingHome = play ? play.attKey === "home" : true;
  const phase = play ? play.phase : 0;
  const carrierId = play?.carrierId || null;
  // A continuous clock (seconds of match time) when the map is animating
  // every screen frame; falls back to the stage counter otherwise.
  const t = live.clock ?? (live.frame || 0);
  const pos = {};

  const teams = [
    { list: live.xi || [], isHome: true, beh: live.homeBeh || {} },
    { list: live.oppXi || [], isHome: false, beh: live.awayBeh || {} },
  ];

  // Pass 1 — shape, tactic, role and the player's own wandering
  teams.forEach(({ list, isHome, beh }) => {
    const inPoss = isHome === attackingHome;
    const dir = isHome ? -1 : 1;             // you attack up the screen, they attack down it
    // Creative freedom decides how far players leave their positions. A
    // disciplined side holds its shape; an expressive one roams, overlaps and
    // interchanges. Curved so the difference between the two is unmistakable.
    const freedom = 0.1 + Math.pow((beh.creativeFreedom ?? 50) / 100, 1.3) * 1.7;
    const roleK = 0.4 + freedom * 0.6;
    const widthK = inPoss ? 0.85 + ((beh.width ?? 50) / 100) * 0.35 : 0.86;
    const lineK = ((beh.defLine ?? 50) - 50) / 50;
    const tempoK = 0.6 + ((beh.tempo ?? 50) / 100) * 0.8;
    const amount = 3 + phase * 3.4;
    const block = inPoss ? amount : -amount * 0.55 + lineK * 4;

    list.forEach((pl) => {
      const isGk = pl.slot === "GK";
      const m = ROLE_MOVEMENT[pl.role] || { roam: 0.3 };
      const fm = focusMods(pl.focus);
      let x = pl.x, y = pl.y;
      let fwd = isGk ? block * 0.25 : block;

      if (inPoss) {
        fwd += (m.fwdIn || 0) * fm.inMul * roleK;
        const xc = x - 50;
        const inward = (m.inIn || 0) * roleK;
        if (Math.abs(xc) > 4 && inward) x = 50 + Math.sign(xc) * Math.max(3, Math.abs(xc) - inward);
      } else {
        fwd += (m.fwdOut || 0) + fm.outAdd;
      }
      if (!isGk) x = 50 + (x - 50) * widthK;
      y += dir * fwd;

      const sd = seedOf(pl.id);
      const amp = (m.roam ?? 0.3) * freedom * 11;
      const tt = t * 0.55 * tempoK;
      x += amp * Math.sin(tt * (0.7 + (sd % 7) / 10) + (sd % 13));
      y += amp * 0.8 * Math.cos(tt * (0.6 + (sd % 5) / 10) + (sd % 11));

      // Nobody on a pitch is ever completely still: small, quicker adjustments
      // on top of the bigger role-driven wandering above.
      const jog = isGk ? 0.35 : 0.9;
      x += jog * Math.sin(t * (1.6 + (sd % 9) / 10) + (sd % 17));
      y += jog * 0.8 * Math.cos(t * (1.3 + (sd % 6) / 10) + (sd % 19));

      pos[pl.id] = { x, y, isHome, isGk, m, inPoss, freedom };
    });
  });

  // Pass 2 — the man on the ball carries it into the zone the move reached
  const BALL_Y = [74, 54, 30, 16];
  const zoneY = attackingHome ? BALL_Y[phase] : 100 - BALL_Y[phase];
  let ball = { x: 50, y: zoneY };
  if (carrierId && pos[carrierId]) {
    const c = pos[carrierId];
    c.y += (zoneY - c.y) * 0.55;
    ball = { x: c.x, y: c.y };
  }

  // Pass 3 — everyone else reacts to where the ball is
  Object.entries(pos).forEach(([id, p]) => {
    if (p.isGk && id !== carrierId) {
      // Keepers shadow the ball across the face of goal, and come off their
      // line as play gets closer — a sweeper keeper more than most.
      const line = p.isHome ? 92 : 8;
      const near = Math.max(0, 1 - Math.abs(ball.y - line) / 70);
      const step = (2 + near * 7) * (p.m.fwdIn ? 1.4 : 1);
      p.x += (50 + (ball.x - 50) * 0.35 - p.x) * 0.8;
      p.y += ((p.isHome ? line - step : line + step) - p.y) * 0.6;
      return;
    }
    if (id === carrierId) return;
    const beh = p.isHome ? (live.homeBeh || {}) : (live.awayBeh || {});
    const dx = ball.x - p.x, dy = ball.y - p.y;
    const dist = Math.hypot(dx, dy) || 1;
    if (p.inPoss) {
      const pull = (p.m.seek || 0) * p.freedom * Math.max(0, 1 - dist / 50) * 0.35;
      if (dist > 9) { p.x += dx * pull; p.y += dy * pull; }
    } else {
      const press = (p.m.press || 0) * ((beh.pressIntensity ?? 50) / 100);
      const pull = press * Math.max(0, 1 - dist / 40) * 0.55;
      p.x += dx * pull + dx * 0.12;           // the whole block leans toward the ball
      p.y += dy * pull;
    }
  });

  // Pass 4 — on the pitch, keepers in their area, nobody standing on a team-mate
  Object.values(pos).forEach((p) => {
    p.x = Math.max(5, Math.min(95, p.x));
    p.y = Math.max(5, Math.min(95, p.y));
    if (p.isGk) {
      p.x = Math.max(32, Math.min(68, p.x));
      p.y = p.isHome ? Math.max(76, Math.min(95, p.y)) : Math.max(5, Math.min(24, p.y));
    }
  });
  [true, false].forEach((home) => {
    const team = Object.entries(pos).filter(([, p]) => p.isHome === home);
    for (let i = 0; i < team.length; i++) for (let j = i + 1; j < team.length; j++) {
      const a = team[i][1], b = team[j][1];
      const dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy);
      if (d > 0 && d < 5) {
        const push = (5 - d) / 2, ux = dx / d, uy = dy / d;
        if (team[i][0] !== carrierId) { a.x -= ux * push; a.y -= uy * push; }
        if (team[j][0] !== carrierId) { b.x += ux * push; b.y += uy * push; }
      }
    }
  });

  if (carrierId && pos[carrierId]) ball = { x: pos[carrierId].x, y: pos[carrierId].y };
  return { pos, ball, attackingHome, phase, carrierId };
}

// ── Tempo tab ──
// Reads the tempo and intensity the engine actually played the match at.
// Nothing here is invented for display: every number and every line comes
// from the pulse the simulation recorded possession by possession.
const TEMPO_WORDS = [[40, "Slow"], [55, "Measured"], [70, "Brisk"], [82, "Quick"], [101, "Frantic"]];
const INTENSITY_WORDS = [[40, "Low"], [55, "Steady"], [70, "Competitive"], [82, "Fierce"], [101, "Ferocious"]];
const wordFor = (table, v) => table.find(([lim]) => v < lim)[1];
const pulseColor = (v) => (v < 40 ? "#64748b" : v < 55 ? "#00d4ff" : v < 70 ? "#00ff88" : v < 82 ? "#ffa800" : "#ff4060");

function smoothSeries(values, w = 5) {
  return values.map((_, i) => {
    const a = Math.max(0, i - Math.floor(w / 2)), b = Math.min(values.length, i + Math.ceil(w / 2));
    const slice = values.slice(a, b);
    return slice.reduce((x, y) => x + y, 0) / slice.length;
  });
}

function TempoPanel({ pulse, events, homeName, awayName, live }) {
  const [mode, setMode] = useState("match");
  if (!pulse || pulse.length === 0) {
    return <div style={{ padding: 20, textAlign: "center", fontSize: 11, color: N.muted, marginBottom: 16 }}>Waiting for kick-off…</div>;
  }
  const now = pulse[pulse.length - 1];
  const avg = (k) => Math.round(pulse.reduce((a, p) => a + p[k], 0) / pulse.length);

  // Trend over the last ~5 minutes
  const past = [...pulse].reverse().find((p) => p.min <= now.min - 5) || pulse[0];
  const trend = (k) => {
    const d = now[k] - past[k];
    return d > 4 ? { icon: "▲", text: "rising", c: "#ffa800" } : d < -4 ? { icon: "▼", text: "easing", c: "#00d4ff" } : { icon: "►", text: "steady", c: N.muted };
  };

  // Plain-words reasons, straight from the engine's own drivers
  const reasons = [];
  const phrase = {
    chasing: (n) => `${n} are chasing the game`,
    managing: (n) => `${n} are managing their lead`,
    responding: (n) => `${n} are responding to conceding`,
    settling: (n) => `${n} are settling after scoring`,
    shorthanded: (n) => `${n} are a man down`,
    tiring: (n) => `${n}'s legs are going`,
  };
  [["home", homeName], ["away", awayName]].forEach(([k, name]) => {
    (now[k]?.drivers || []).forEach((d) => { if (phrase[d]) reasons.push(phrase[d](name)); });
  });
  const shared = [...(now.home?.drivers || []), ...(now.away?.drivers || [])];
  if (shared.includes("opening")) reasons.unshift("Opening exchanges — both sides starting at pace");
  if (shared.includes("finalpush")) reasons.push("Final push in the closing minutes");
  if ((now.heat || 0) >= 6) reasons.push("Recent flashpoints have raised the temperature");
  if (!reasons.length) reasons.push("A settled spell — both sides playing to their tactics");

  // Busiest and calmest five-minute spells
  const spell = (k, pick) => {
    let best = null;
    pulse.forEach((p) => {
      const win = pulse.filter((q) => q.min >= p.min && q.min < p.min + 5);
      if (win.length < 3) return;
      const v = win.reduce((a, q) => a + q[k], 0) / win.length;
      if (!best || (pick === "max" ? v > best.v : v < best.v)) best = { v, from: Math.round(p.min) };
    });
    return best;
  };
  const peakI = spell("intensity", "max");
  const calmT = spell("tempo", "min");

  // ── Chart ──
  const W = 320, H = 150, X0 = 8, X1 = 312, Y0 = 10, Y1 = 124;
  const xOf = (m) => X0 + (Math.min(90, Math.max(0, m)) / 90) * (X1 - X0);
  const yOf = (v) => Y0 + (1 - v / 100) * (Y1 - Y0);
  const line = (vals) => {
    const sm = smoothSeries(vals);
    return sm.map((v, i) => `${i ? "L" : "M"}${xOf(pulse[i].min).toFixed(1)},${yOf(v).toFixed(1)}`).join(" ");
  };
  const series = mode === "match"
    ? [{ vals: pulse.map((p) => p.tempo), color: N.cyan, label: "Tempo" },
       { vals: pulse.map((p) => p.intensity), color: "#ffa800", label: "Intensity" }]
    : mode === "teamTempo"
    ? [{ vals: pulse.map((p) => p.home.tempo), color: N.cyan, label: homeName },
       { vals: pulse.map((p) => p.away.tempo), color: "#ff6b6b", label: awayName }]
    : [{ vals: pulse.map((p) => p.home.intensity), color: N.cyan, label: homeName },
       { vals: pulse.map((p) => p.away.intensity), color: "#ff6b6b", label: awayName }];

  const marks = (events || []).filter((e) => ["goal", "red", "tactic"].includes(e.type) || (e.type === "sub" && e.team === "home"));

  const Gauge = ({ label, value, words, t }) => (
    <div style={{ flex: 1, background: N.card, borderRadius: 10, padding: "10px 12px", border: `1px solid ${N.border}` }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
        <span style={{ fontSize: 10, fontWeight: 800, color: N.muted, letterSpacing: 0.5 }}>{label}</span>
        <span style={{ fontSize: 10, fontWeight: 800, color: t.c }}>{t.icon} {t.text}</span>
      </div>
      <div style={{ display: "flex", alignItems: "baseline", gap: 6, marginTop: 4 }}>
        <span style={{ fontSize: 26, fontWeight: 900, color: pulseColor(value) }}>{value}</span>
        <span style={{ fontSize: 12, fontWeight: 800, color: pulseColor(value) }}>{wordFor(words, value)}</span>
      </div>
      <div style={{ height: 5, background: "#0a0e1a", borderRadius: 3, overflow: "hidden", marginTop: 6 }}>
        <div style={{ height: "100%", width: `${value}%`, background: pulseColor(value), borderRadius: 3, transition: "width 0.6s ease" }} />
      </div>
    </div>
  );

  const TeamBar = ({ label, you, them }) => (
    <div style={{ marginBottom: 7 }}>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, fontWeight: 700, marginBottom: 3 }}>
        <span style={{ color: N.cyan }}>{you}</span>
        <span style={{ color: N.muted }}>{label}</span>
        <span style={{ color: "#ff6b6b" }}>{them}</span>
      </div>
      <div style={{ display: "flex", height: 6, borderRadius: 3, overflow: "hidden", background: "#0a0e1a" }}>
        <div style={{ width: `${(you / Math.max(1, you + them)) * 100}%`, background: N.cyan, transition: "width 0.6s ease" }} />
        <div style={{ flex: 1, background: "#ff6b6b" }} />
      </div>
    </div>
  );

  const headline = live ? "Right now" : "Full match";
  const tv = live ? now.tempo : avg("tempo");
  const iv = live ? now.intensity : avg("intensity");

  return (
    <div style={{ background: N.surface, borderRadius: 12, border: `1px solid ${N.border}`, padding: 12, marginBottom: 16 }}>
      <div style={{ fontSize: 10, fontWeight: 800, color: N.muted, marginBottom: 8 }}>{headline.toUpperCase()}{live ? ` · ${Math.round(now.min)}'` : " · AVERAGE"}</div>
      <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
        <Gauge label="TEMPO" value={tv} words={TEMPO_WORDS} t={live ? trend("tempo") : { icon: "", text: "", c: N.muted }} />
        <Gauge label="INTENSITY" value={iv} words={INTENSITY_WORDS} t={live ? trend("intensity") : { icon: "", text: "", c: N.muted }} />
      </div>

      {live && (
        <>
          <div style={{ fontSize: 10, fontWeight: 800, color: N.muted, marginBottom: 6 }}>WHO'S DRIVING IT</div>
          <TeamBar label="Tempo" you={now.home.tempo} them={now.away.tempo} />
          <TeamBar label="Intensity" you={now.home.intensity} them={now.away.intensity} />
          <div style={{ fontSize: 10, fontWeight: 800, color: N.muted, margin: "10px 0 5px" }}>WHY</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 3, marginBottom: 12 }}>
            {reasons.slice(0, 4).map((r, i) => (
              <div key={i} style={{ fontSize: 11, color: N.text }}>• {r}</div>
            ))}
          </div>
        </>
      )}

      {/* Chart mode */}
      <div style={{ display: "flex", gap: 5, marginBottom: 6, flexWrap: "wrap" }}>
        {[["match", "Match"], ["teamTempo", "Tempo by team"], ["teamIntensity", "Intensity by team"]].map(([k, l]) => (
          <button key={k} onClick={() => setMode(k)} style={{
            padding: "5px 9px", fontSize: 10, fontWeight: 800, borderRadius: 5, cursor: "pointer",
            background: mode === k ? `${N.cyan}20` : N.card, border: `1px solid ${mode === k ? N.cyan : N.border}`,
            color: mode === k ? N.cyan : N.muted,
          }}>{l}</button>
        ))}
      </div>

      <svg viewBox={`0 0 ${W} ${H}`} width="100%" style={{ display: "block" }}>
        {[25, 50, 75].map((g) => (
          <line key={g} x1={X0} x2={X1} y1={yOf(g)} y2={yOf(g)} stroke="rgba(255,255,255,0.06)" strokeWidth="1" />
        ))}
        <line x1={xOf(45)} x2={xOf(45)} y1={Y0} y2={Y1} stroke="rgba(255,255,255,0.18)" strokeDasharray="3 3" />
        <text x={xOf(45)} y={Y1 + 10} fill="#64748b" fontSize="7" textAnchor="middle">HT</text>
        {[0, 15, 30, 60, 75, 90].map((m) => (
          <text key={m} x={xOf(m)} y={Y1 + 10} fill="#64748b" fontSize="7" textAnchor="middle">{m}'</text>
        ))}
        {marks.map((e, i) => (
          <line key={`v${i}`} x1={xOf(e.min)} x2={xOf(e.min)} y1={Y0} y2={Y1}
            stroke={e.type === "goal" ? "rgba(255,215,0,0.28)" : e.type === "red" ? "rgba(255,32,64,0.35)" : "rgba(255,255,255,0.08)"} strokeWidth="1" />
        ))}
        {series.map((sr) => (
          <path key={sr.label} d={line(sr.vals)} fill="none" stroke={sr.color} strokeWidth="1.8" strokeLinejoin="round" strokeLinecap="round" />
        ))}
        {live && <circle cx={xOf(now.min)} cy={yOf(smoothSeries(series[0].vals).slice(-1)[0])} r="2.6" fill={series[0].color} />}
        {marks.map((e, i) => (
          <text key={`m${i}`} x={xOf(e.min)} y={Y1 + 22} fontSize="8" textAnchor="middle">
            {e.type === "goal" ? "⚽" : e.type === "red" ? "🟥" : e.type === "sub" ? "🔄" : "🧠"}
          </text>
        ))}
      </svg>

      <div style={{ display: "flex", gap: 12, justifyContent: "center", marginTop: 2, flexWrap: "wrap" }}>
        {series.map((sr) => (
          <span key={sr.label} style={{ fontSize: 10, fontWeight: 700, color: sr.color }}>━ {sr.label}</span>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 6, marginTop: 10 }}>
        {[
          ["Average tempo", `${avg("tempo")} · ${wordFor(TEMPO_WORDS, avg("tempo"))}`],
          ["Average intensity", `${avg("intensity")} · ${wordFor(INTENSITY_WORDS, avg("intensity"))}`],
          ["Fiercest spell", peakI ? `${peakI.from}'–${peakI.from + 5}'` : "—"],
          ["Calmest spell", calmT ? `${calmT.from}'–${calmT.from + 5}'` : "—"],
        ].map(([k, v]) => (
          <div key={k} style={{ background: N.card, borderRadius: 6, padding: "6px 8px" }}>
            <div style={{ fontSize: 9, color: N.muted, fontWeight: 700 }}>{k}</div>
            <div style={{ fontSize: 11, color: N.text, fontWeight: 800 }}>{v}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Set pieces on the live map ──
// Where players stand for a corner, a free kick, a throw-in, a goal kick or
// kick-off. Distances are measured from the goal the team in possession attacks.
const yToward = (attKey, d) => (attKey === "home" ? 3.5 + d : 96.5 - d);
const yFromOwn = (attKey, d) => (attKey === "home" ? 96.5 - d : 3.5 + d);

function setPieceLayout(play, live, base) {
  if (!play) return null;
  const sp = play.setPiece, rs = play.restart, ctx = play.ctx || {};
  if (!sp && !rs) return null;
  const aKey = play.attKey;
  const A = ((aKey === "home" ? live.xi : live.oppXi) || []).filter((p) => !p.sentOff);
  const D = ((aKey === "home" ? live.oppXi : live.xi) || []).filter((p) => !p.sentOff);
  const G = (d) => yToward(aKey, d), O = (d) => yFromOwn(aKey, d);
  const t = {};
  let ball = null, tag = null, hands = false;
  const put = (id, x, y) => { if (id) t[id] = { x: clampN(x, 2, 98), y: clampN(y, 1.5, 98.5) }; };
  const at = (p) => base[p.id] || { x: p.x, y: p.y };
  const gkD = D.find((p) => p.slot === "GK");
  const outA = A.filter((p) => p.slot !== "GK"), outD = D.filter((p) => p.slot !== "GK");
  const nearestTo = (list, x, y, used) => list.filter((p) => !used.has(p.id))
    .map((p) => ({ p, d: Math.hypot(at(p).x - x, at(p).y - y) })).sort((a, b) => a.d - b.d)[0]?.p;

  // Corners and free kicks swung in from wide: the box fills up
  if (ctx.boxIds && (sp === "corner" || sp === "fkcross" || sp === "header")) {
    const s = ctx.side === "left" ? -1 : 1;
    const fromFk = ctx.kind === "fkcross" && ctx.spot;
    const spot = fromFk ? { x: 50 + ctx.spot.lat, y: G(ctx.spot.d) } : { x: s < 0 ? 2.3 : 97.7, y: G(0.4) };
    const spots = [[5 * s, 5], [0, 7], [-5 * s, 6], [2 * s, 10.5], [-3 * s, 12]];
    ctx.boxIds.forEach((id, i) => { const [dx, d] = spots[i % spots.length]; put(id, 50 + dx, G(d)); });
    put(ctx.takerId, spot.x + (fromFk ? 0 : s * 0.8), spot.y + (fromFk ? (aKey === "home" ? 1.6 : -1.6) : 0));
    outA.filter((p) => p.id !== ctx.takerId && !ctx.boxIds.includes(p.id)).forEach((p, i) => {
      if (i < 2) put(p.id, 50 + (i ? 13 : -13), G(19));                     // on the edge for the second ball
      else put(p.id, 30 + ((i - 2) * 20) % 40, G(44));                        // holding back
    });
    if (gkD) put(gkD.id, 50 + s * 1.5, G(1.6));
    const markerOf = {};
    const spare = outD.filter((p) => p.id !== ctx.markerId);
    ctx.boxIds.forEach((id) => { markerOf[id] = id === ctx.targetId ? outD.find((p) => p.id === ctx.markerId) : spare.shift(); });
    ctx.boxIds.forEach((id, i) => {                                           // tight to their man, goal-side
      const m = markerOf[id]; if (!m) return;
      const [dx, d] = spots[i % spots.length];
      put(m.id, 50 + dx - s * 1.0, G(d - 1.2));
    });
    const markedIds = new Set(Object.values(markerOf).filter(Boolean).map((p) => p.id));
    outD.filter((p) => !markedIds.has(p.id)).forEach((p, i, arr) => {
      if (i === 0) put(p.id, 50 + s * 6.5, G(1.8));                          // near post
      else if (i === arr.length - 1 && arr.length > 2) put(p.id, 50 - s * 8, G(36));   // left up for the break
      else put(p.id, 46 + ((i * 5) % 12), G(8 + (i % 2) * 5));                // zonal
    });
    if (sp === "corner" || sp === "fkcross") {
      if (play.stage === "setup") { ball = spot; tag = fromFk ? "FREE KICK" : "CORNER"; }
      if (play.stage === "delivery" && play.result === "claimed" && gkD) put(gkD.id, 50 + s * 2, G(6));   // off his line to claim
    }
    return { t, ball, tag, hands };
  }

  // A free kick in shooting range: taker over the ball, a wall at nine metres
  if (sp === "freekick" && ctx.spot && (play.stage === "setup" || play.outcome)) {
    const spot = { x: 50 + ctx.spot.lat, y: G(ctx.spot.d) };
    const sideOf = ctx.spot.lat < 0 ? -1 : 1;
    put(ctx.takerId, spot.x - sideOf * 1.2, spot.y + (aKey === "home" ? 1.8 : -1.8));
    const post = { x: 50 + sideOf * 4, y: G(0) };
    const vx = post.x - spot.x, vy = post.y - spot.y, L = Math.hypot(vx, vy) || 1;
    const ux = vx / L, uy = vy / L, cx = spot.x + ux * 7.5, cy = spot.y + uy * 7.5;
    const wall = ctx.wallIds || [];
    wall.forEach((id, i) => { const off = (i - (wall.length - 1) / 2) * 1.8; put(id, cx - uy * off, cy + ux * off); });
    if (gkD) put(gkD.id, 50 - sideOf * 2.2, G(1.6));                         // keeper covers the side the wall doesn't
    const runSpots = [[-6, 9], [6, 9], [0, 12], [-10, 14]];
    const freeD = outD.filter((p) => !wall.includes(p.id));
    outA.filter((p) => p.id !== ctx.takerId).forEach((p, i) => {
      if (i < runSpots.length) {
        const [dx, d] = runSpots[i];
        put(p.id, 50 + dx, G(d));
        if (freeD[i]) put(freeD[i].id, 50 + dx + 1, G(d - 1.2));
      } else put(p.id, 30 + ((i * 17) % 40), G(40));
    });
    freeD.slice(runSpots.length).forEach((p, i) => put(p.id, 40 + i * 10, G(30)));
    if (play.stage === "setup") { ball = spot; tag = "FREE KICK"; }
    return { t, ball, tag, hands };
  }

  // A quick free kick: the ball stays with the man who was fouled
  if (sp === "freekick" && play.stage === "quick") return { t, ball, tag: "FREE KICK", hands };

  // Restarts
  if (rs) {
    const h = seedOf(`${play.carrierId}:${rs}:${play.side || ""}`);
    const used = new Set([play.carrierId]);
    if (rs === "throwIn") {
      const sx = play.side === "left" ? 1.6 : 98.4;
      const y = play.zone === "attacking" ? G(22 + (h % 12)) : O(22 + (h % 12));
      put(play.carrierId, sx, y);
      const inward = play.side === "left" ? 1 : -1;
      [[7, -3], [12, 5]].forEach(([dx, dy]) => {                              // two team-mates come short
        const tx = sx + inward * dx, ty = y + dy;
        const mate = nearestTo(outA, tx, ty, used); if (!mate) return;
        used.add(mate.id); put(mate.id, tx, ty);
        const m = nearestTo(outD, tx, ty, used); if (m) { used.add(m.id); put(m.id, tx + inward * 1.2, ty - (aKey === "home" ? 1 : -1) * 1.2); }
      });
      ball = { x: sx, y }; tag = "THROW-IN"; hands = true;
    } else if (rs === "goalKick") {
      const gx = 50 + ((h % 9) - 4);
      put(play.carrierId, gx, O(5));
      const cbs = outA.filter((p) => /CB/.test(p.slot)).slice(0, 2);
      if (!play.long) {
        cbs.forEach((p, i) => put(p.id, i ? 67 : 33, O(9)));                  // centre-backs split to take it short
        outA.filter((p) => /^(LB|LWB)$/.test(p.slot)).forEach((p) => put(p.id, 8, O(22)));
        outA.filter((p) => /^(RB|RWB)$/.test(p.slot)).forEach((p) => put(p.id, 92, O(22)));
      } else {
        outA.filter((p) => /ST|CF|W|CAM/.test(p.slot)).forEach((p, i) => put(p.id, 38 + i * 12, O(50 + (i % 2) * 3)));   // up for the long ball
      }
      ball = { x: gx, y: O(5.3) }; tag = "GOAL KICK";
    } else if (rs === "kickoff") {
      const own = (y) => (aKey === "home" ? Math.max(y, 51.5) : Math.min(y, 48.5));
      const theirs = (y) => (aKey === "home" ? Math.min(y, 48.5) : Math.max(y, 51.5));
      outA.forEach((p) => { const b = at(p); put(p.id, b.x, own(b.y)); });
      D.forEach((p) => {                                                       // their half, outside the centre circle
        let { x, y } = at(p); y = theirs(y);
        const dx = x - 50, dy = (y - 50) * 1.28, d = Math.hypot(dx, dy);
        if (d < 12.5) { const k = 12.5 / (d || 1); x = 50 + dx * k; y = 50 + (dy * k) / 1.28; y = theirs(y); }
        put(p.id, x, y);
      });
      put(play.carrierId, 50, aKey === "home" ? 51 : 49);
      ball = { x: 50, y: 50 }; tag = "KICK-OFF";
    }
    return { t, ball, tag, hands };
  }
  return null;
}

// The ball's journey for a delivery into the box, or a restart
function planDelivery(play, from) {
  const up = play.attKey === "home";
  return {
    from: { ...from }, to: { ...from }, into: null, loft: 1.8, follow: play.carrierId, catchIt: play.result === "claimed",
    windup: 0.3, dur: 0.75, bend: (from.x < 50 ? 1 : -1) * 3.5, bounceDur: 0.45,
    bounce: play.result === "cleared" ? { dx: (from.x < 50 ? 1 : -1) * 9, dy: (up ? 1 : -1) * 19 } : null,
    delivery: true,
  };
}
function planRestart(play, from, pre) {
  const kind = play.restart;
  const long = kind === "goalKick" && play.long;
  return {
    from: { ...from }, pre: pre ? { ...pre } : null, to: { ...from }, into: null, bounce: null,
    loft: long ? 2.3 : kind === "throwIn" ? 0.6 : kind === "keeperBall" ? 0.7 : 0.15,
    follow: null, catchIt: true, windup: kind === "throwIn" ? 0.35 : 0.3,
    dur: long ? 0.8 : kind === "kickoff" ? 0.3 : 0.4, bend: 0, bounceDur: 0, restart: true,
  };
}

// ── Special moments on the live map ──
// Pure helpers (no React) so they can be tested with plain numbers.

const clampN = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

// ── Shooting ──
// Which corner the shooter goes for, and whether he goes high or low. Keyed
// off the shooter and the chance so the run-up and the strike always agree.
function shotAim(play) {
  const h = seedOf(`${play.carrierId}:${Math.round((play.xg ?? 0.1) * 1000)}:aim`);
  const corner = (h % 3) - 1;                        // -1 left post · 0 central · 1 right post
  const high = ((h >>> 3) & 1) === 1;                 // top corner, or low and hard
  const x = 50 + (corner === 0 ? (((h >>> 5) % 3) - 1) * 1.2 : corner * 4.6);
  return { corner, high, x, h };
}

// Where the shot is struck from, read from the chance's xG: a big chance is
// taken from close in, a speculative one from distance, wider angles further out.
function shootingSpot(play) {
  const up = play.attKey === "home";
  const xg = Math.max(0.02, play.xg ?? 0.1);
  const h = seedOf(`${play.carrierId}:${Math.round(xg * 1000)}:spot`);
  // The engine's chance quality sits in a tight band (roughly 0.13–0.25), so
  // it's spread across the pitch by rank: its best chances are struck from
  // close in, its weakest from distance, with a little variety per shot.
  const jitter = (((h >>> 9) % 51) - 25) / 10;          // ±2.5
  const dist = clampN(5 + (Math.log(0.30) - Math.log(xg)) * 16.5 + jitter, 5, 27);
  const side = ((h % 21) - 10) / 10;
  return { x: clampN(50 + side * (4 + dist * 0.55), 12, 88), y: up ? 3.5 + dist : 96.5 - dist, dist };
}

// Plans the flight from the boot to wherever the shot ends up.
function planShot(play, from) {
  const up = play.attKey === "home";
  const line = up ? 3.5 : 96.5;
  const aim = shotAim(play);
  const h = aim.h;
  const power = play.power ?? 55;
  let to, loft, into = null, bounce = null, follow = null, catchIt = false;
  if (play.outcome === "goal") {
    to = { x: aim.x, y: line };                                   // crosses the line in the goal mouth
    into = { x: 50 + (aim.x - 50) * 1.08, y: up ? 1.3 : 98.7 };   // and hits the back of the net
    loft = aim.high ? 1.2 : 0.3;
  } else if (play.outcome === "save") {
    follow = play.keeperId;                                       // meets the keeper's gloves
    to = { x: aim.x, y: line + (up ? 2.2 : -2.2) };
    loft = aim.high ? 1.0 : 0.3;
    catchIt = ((h >>> 6) % 3) === 0;                               // one in three held, the rest parried
    if (!catchIt) bounce = { dx: (((h >>> 8) & 1) ? 1 : -1) * (7 + ((h >>> 9) % 5)), dy: (up ? 1 : -1) * (4 + ((h >>> 11) % 5)) };
  } else if (play.outcome === "miss") {
    if (((h >>> 4) & 1) === 1) { to = { x: aim.x, y: up ? 0.5 : 99.5 }; loft = 2.6; }   // skied over the bar
    else {
      const s = aim.corner === 0 ? ((h & 1) ? 1 : -1) : aim.corner;
      to = { x: 50 + s * (8.5 + ((h >>> 7) % 4)), y: up ? 0.9 : 99.1 }; loft = 0.45;    // wide of the post
    }
  } else {                                                        // blocked
    follow = play.blockerId;
    to = { ...from };
    loft = 0.1;
    bounce = { dx: (((h >>> 2) & 1) ? 1 : -1) * (6 + ((h >>> 5) % 5)), dy: (up ? 1 : -1) * (3 + ((h >>> 8) % 4)) };
  }
  const dist = Math.hypot(to.x - from.x, (to.y - from.y) * 1.28);
  // Timed in real seconds, not match time, so a shot is always watchable.
  // The wind-up is identical for every shot — nothing gives the result away.
  let windup = 0.34;
  let bend = (from.x - 50) * (aim.high ? 0.14 : 0.06);            // curls back in from wide
  if (play.setPiece === "header") { windup = 0.08; loft = Math.min(loft, 0.5); }                    // met first time
  if (play.setPiece === "freekick") { windup = 0.5; loft = Math.max(loft, 1.15); bend *= 2.2; }     // run-up, up and over the wall
  if (play.outcome === "save" && play.held != null) {
    catchIt = !!play.held;
    if (catchIt) bounce = null;
    else if (!bounce) bounce = { dx: (((h >>> 8) & 1) ? 1 : -1) * (7 + ((h >>> 9) % 5)), dy: (up ? 1 : -1) * (4 + ((h >>> 11) % 5)) };
  }
  const dur = clampN(0.3 + dist * 0.02 * (1.3 - power / 200), 0.42, 0.8);   // harder strikers get there quicker
  return { from: { ...from }, to, into, loft, bounce, follow, catchIt, windup, dur, bend, bounceDur: 0.45 };
}

// Where the ball is t seconds after the shooter sets himself, and how high.
function flightAt(f, t0) {
  const lerp = (a, b, k) => a + (b - a) * k;
  const fin = (o) => ({ ...o, x: clampN(o.x, 3, 97), y: clampN(o.y, 0.4, 99.6) });
  // Setting himself: the ball sits at his feet (or is carried to the restart spot)
  if (t0 < (f.windup || 0)) {
    if (f.pre) {
      const k = Math.min(1, t0 / ((f.windup || 0.3) * 0.7));
      return fin({ x: lerp(f.pre.x, f.from.x, k), y: lerp(f.pre.y, f.from.y, k), h: 0, flying: false, stage: "windup" });
    }
    return fin({ x: f.from.x, y: f.from.y, h: 0, flying: false, stage: "windup" });
  }
  const t = t0 - (f.windup || 0);
  if (t < f.dur) {
    const p = Math.max(0, t / f.dur);
    const q = p * (1.15 - 0.15 * p);        // a struck ball barely slows over this distance
    const cx = (f.from.x + f.to.x) / 2 + f.bend, cy = (f.from.y + f.to.y) / 2;
    return fin({
      x: (1 - q) ** 2 * f.from.x + 2 * (1 - q) * q * cx + q * q * f.to.x,
      y: (1 - q) ** 2 * f.from.y + 2 * (1 - q) * q * cy + q * q * f.to.y,
      h: f.loft * 4 * q * (1 - q), flying: true, stage: "flight",
    });
  }
  const t2 = t - f.dur;
  if (f.into) {
    const k = 1 - (1 - Math.min(1, t2 / 0.25)) ** 2;
    return fin({ x: lerp(f.to.x, f.into.x, k), y: lerp(f.to.y, f.into.y, k), h: 0, flying: false, stage: "net" });
  }
  if (f.bounce) {
    const p = Math.min(1, t2 / f.bounceDur), k = 1 - (1 - p) ** 2;
    return fin({ x: lerp(f.to.x, f.to.x + f.bounce.dx, k), y: lerp(f.to.y, f.to.y + f.bounce.dy, k),
      h: 0.35 * 4 * k * (1 - k), flying: p < 1, stage: "rebound" });
  }
  return fin({ x: f.to.x, y: f.to.y, h: 0, flying: false, stage: "held" });
}

// Adjusts where players are heading for a challenge, a turnover or a shot,
// using where they actually are on screen so contact really happens.
function stagePositions(targetPos, cur, play, live) {
  const t = { ...targetPos };
  const layout = live ? setPieceLayout(play, live, targetPos) : null;
  if (layout) Object.entries(layout.t).forEach(([id, p]) => { if (t[id]) t[id] = { ...t[id], ...p }; });
  const sprint = new Set(layout ? Object.keys(layout.t) : []);   // jogging into position for the set piece
  const dive = new Set();
  const at = (id) => cur[id] || t[id];
  let ball = null;
  if (!play) return { t, sprint, dive, ball, layout };

  // A red-carded challenger has already left the eleven — keep him on screen
  // for the foul itself, then he walks off.
  if (play.duel && !t[play.duel.by] && cur[play.duel.by]) t[play.duel.by] = { ...cur[play.duel.by] };

  // A challenge: the man on the ball holds, the challenger closes him down
  if (play.duel && t[play.duel.by] && t[play.carrierId]) {
    const c = at(play.carrierId), ch = at(play.duel.by);
    const dx = ch.x - c.x, dy = ch.y - c.y, d = Math.hypot(dx, dy) || 1;
    t[play.carrierId] = { ...t[play.carrierId], x: c.x, y: c.y };
    t[play.duel.by] = { ...t[play.duel.by], x: c.x + (dx / d) * 2.3, y: c.y + (dy / d) * 1.9 };
    sprint.add(play.duel.by);
  }

  // The ball changes feet where the challenge happened
  if (play.won) {
    [play.carrierId, play.won.from].forEach((id) => {
      const c = cur[id];
      if (c && t[id]) t[id] = { ...t[id], x: c.x, y: c.y };
    });
  }

  // Running onto the chance: the shooter gets to the spot he'll strike from
  if (play.phase === 3 && !play.outcome && play.xg != null && t[play.carrierId]) {
    const spot = shootingSpot(play);
    t[play.carrierId] = { ...t[play.carrierId], x: spot.x, y: spot.y };
    sprint.add(play.carrierId);
  }

  // The strike: the shooter plants, a blocker throws himself in, the keeper dives
  if (play.outcome) {
    const sh = at(play.carrierId);
    if (sh && t[play.carrierId]) t[play.carrierId] = { ...t[play.carrierId], x: sh.x, y: sh.y };
    if (play.outcome === "block" && play.blockerId && t[play.blockerId] && sh) {
      const b = at(play.blockerId);
      const dx = b.x - sh.x, dy = b.y - sh.y, d = Math.hypot(dx, dy) || 1;
      t[play.blockerId] = { ...t[play.blockerId], x: sh.x + (dx / d) * 2.6, y: sh.y + (dy / d) * 2.2 };
      sprint.add(play.blockerId);
    }
    if (play.keeperId && t[play.keeperId]) {
      const kp = t[play.keeperId];
      const up = play.attKey === "home";
      const save = play.outcome === "save";
      const reach = save ? 0.85 : 0.35;                  // a beaten keeper doesn't get across
      t[play.keeperId] = { ...kp, x: clampN(kp.x + (shotAim(play).x - kp.x) * reach, 41, 59),
        y: save ? (up ? 3.5 + 2.2 : 96.5 - 2.2) : kp.y };
      dive.add(play.keeperId);
    }
  }
  return { t, sprint, dive, ball, layout };
}

// A referee gets out of the way of play instead of letting players run
// through him.
function sidestep(r, pos, gap = 2.8) {
  let { x, y } = r;
  for (let pass = 0; pass < 2; pass++) {
    Object.values(pos).forEach((p) => {
      const dx = x - p.x, dy = y - p.y, d = Math.hypot(dx, dy);
      if (d < gap) {
        const ux = d > 0 ? dx / d : 1, uy = d > 0 ? dy / d : 0;
        x = p.x + ux * gap; y = p.y + uy * gap;
      }
    });
  }
  return { x: clampN(x, 5, 95), y: clampN(y, 6, 94) };
}

// Where the officials want to be. The referee jogs a diagonal a little behind
// and to the side of play, and runs in close for a foul; each assistant holds
// his touchline level with the second-last defender (the offside line).
function officialTargets(pos, ball, play, xi, oppXi) {
  const up = play ? play.attKey === "home" : true;
  const foul = play?.duel?.kind === "foul";
  const across = ball.x < 50 ? 1 : -1;
  let rx = clampN(ball.x + across * (foul ? 6 : 13), 6, 94);
  let ry = clampN(ball.y + (up ? 1 : -1) * (foul ? 4 : 10), 7, 93);
  Object.values(pos).forEach((p) => {
    const dx = rx - p.x, dy = ry - p.y, d = Math.hypot(dx, dy);
    if (d > 0 && d < 4) { rx += (dx / d) * (4 - d); ry += (dy / d) * (4 - d); }
  });
  const homeYs = xi.map((p) => pos[p.id]?.y).filter(Number.isFinite).sort((a, b) => b - a);
  const awayYs = oppXi.map((p) => pos[p.id]?.y).filter(Number.isFinite).sort((a, b) => a - b);
  return {
    ref: { x: clampN(rx, 5, 95), y: clampN(ry, 6, 94) },
    refRate: foul ? 3.5 : 1.8,
    ar1: { x: 1.4, y: clampN(homeYs[1] ?? 70, 52, 95) },
    ar2: { x: 98.6, y: clampN(awayYs[1] ?? 30, 5, 48) },
  };
}

// ── Live tactical map ──
// Every player is placed by computeLivePositions (formation, tactic, role,
// focus, the ball), then stagePositions handles the special moments. Players
// are animated every screen frame on a continuous clock so nobody freezes.
function MatchMap({ live, homeName, awayName, speed = 1, paused = false }) {
  const [, setFrameTick] = useState(0);
  const liveRef = useRef(live);
  liveRef.current = live;
  const renderRef = useRef({ pos: {}, ball: null, refs: null });
  const clockRef = useRef(0);
  const showRef = useRef(0);   // real seconds watched (not scaled by match speed) — shots run on this

  useEffect(() => {
    if (paused) return undefined;
    let raf;
    let last = performance.now();
    const loop = (now) => {
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      const L = liveRef.current;
      if (L) {
        clockRef.current += dt * speed;
        showRef.current += dt;
        const target = computeLivePositions({ ...L, clock: clockRef.current });
        const cur = renderRef.current.pos;
        const play = L.play || null;
        const staged = stagePositions(target.pos, cur, play, L);
        const kWalk = 1 - Math.exp(-dt * 2.4 * speed);
        const kRun = 1 - Math.exp(-dt * 5.5 * speed);   // closing down, blocking, running onto a chance
        const kDive = 1 - Math.exp(-dt * 10 * speed);   // a keeper throwing himself across goal
        const next = {};
        Object.entries(staged.t).forEach(([id, tp]) => {
          const c = cur[id];
          const k = staged.dive.has(id) ? kDive : staged.sprint.has(id) ? kRun : kWalk;
          next[id] = c ? { x: c.x + (tp.x - c.x) * k, y: c.y + (tp.y - c.y) * k } : { x: tp.x, y: tp.y };
        });

        // ── The ball ──
        let ball, ballH = 0;
        let flight = renderRef.current.flight;
        let trail = renderRef.current.trail || [];
        const flies = play && (play.outcome || play.stage === "delivery" || play.restart);
        if (flies) {
          // Plan the ball's journey once, from exactly where it is
          if (!flight || flight.frame !== L.frame) {
            const prevBall = renderRef.current.ball || target.ball;
            let plan;
            if (play.outcome) plan = planShot(play, prevBall);
            else if (play.stage === "delivery") plan = planDelivery(play, prevBall);
            else {
              const spot = staged.layout?.ball || next[play.carrierId] || prevBall;
              plan = planRestart(play, spot, prevBall);
              // Played to the nearest team-mate — or up to the front men for a long kick
              const up = play.attKey === "home";
              const mates = ((up ? L.xi : L.oppXi) || [])
                .filter((p) => p.id !== play.carrierId && p.slot !== "GK" && !p.sentOff && staged.t[p.id]);
              const dist = (a) => Math.hypot(staged.t[a.id].x - spot.x, staged.t[a.id].y - spot.y);
              const r = play.long
                ? mates.sort((a, b) => (up ? staged.t[a.id].y - staged.t[b.id].y : staged.t[b.id].y - staged.t[a.id].y))[0]
                : mates.sort((a, b) => dist(a) - dist(b))[0];
              plan.follow = r?.id || null;
              plan.receiverId = r?.id || null;
            }
            flight = { ...plan, frame: L.frame, t0: showRef.current, t0c: clockRef.current };
            trail = [];
          }
          // Routine restarts run on the match clock, so they speed up with the
          // match; shots and deliveries into the box always play out in full.
          const tt = flight.restart ? clockRef.current - flight.t0c : showRef.current - flight.t0;
          // Heading for a head, the gloves, a body or a team-mate's feet: track
          // them until it arrives (and anything held stays with them)
          if (flight.follow && next[flight.follow] && (tt < flight.windup + flight.dur || flight.catchIt)) {
            const fp = next[flight.follow];
            const lead = flight.restart || flight.delivery ? 0 : (play.attKey === "home" ? 1.0 : -1.0);
            flight.to = { x: fp.x, y: fp.y + lead };
          }
          const at = flightAt(flight, tt);
          ball = { x: at.x, y: at.y };
          ballH = at.h;
          trail = at.flying ? [...trail.slice(-6), { x: at.x, y: at.y - at.h * 1.6 }] : trail.slice(1);
        } else {
          flight = null;
          trail = trail.slice(1);
          // At the carrier's feet, a touch in front of him
          const c = target.carrierId && next[target.carrierId];
          let feet = c ? { x: c.x + 1.2, y: c.y + (target.attackingHome ? -1.3 : 1.3) } : target.ball;
          if (staged.layout?.ball) feet = staged.layout.ball;          // placed for the set piece
          const b = renderRef.current.ball;
          const kb = 1 - Math.exp(-dt * (play?.won ? 8 : 6) * speed);
          ball = b ? { x: b.x + (feet.x - b.x) * kb, y: b.y + (feet.y - b.y) * kb } : { ...feet };
        }

        const off = officialTargets(next, ball, play, L.xi || [], L.oppXi || []);
        const r0 = renderRef.current.refs || { ref: off.ref, ar1: off.ar1, ar2: off.ar2 };
        const ease = (a, tg, rate) => {
          const k = 1 - Math.exp(-dt * rate * speed);
          return { x: a.x + (tg.x - a.x) * k, y: a.y + (tg.y - a.y) * k };
        };
        const refs = { ref: ease(r0.ref, off.ref, off.refRate), ar1: ease(r0.ar1, off.ar1, 2.2), ar2: ease(r0.ar2, off.ar2, 2.2) };
        refs.ref = sidestep(refs.ref, next);

        renderRef.current = { pos: next, ball, ballH, flight, trail, meta: target, refs, layout: staged.layout };
        setFrameTick((n) => (n + 1) % 1000000);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [paused, speed]);

  if (!live) return null;
  const play = live.play || null;
  const meta = renderRef.current.meta || computeLivePositions({ ...live, clock: clockRef.current });
  const pos = Object.keys(renderRef.current.pos).length ? renderRef.current.pos : meta.pos;
  const ball = renderRef.current.ball || meta.ball;
  const refs = renderRef.current.refs;
  const { attackingHome, phase, carrierId } = meta;
  const everyone = [...(live.xi || []), ...(live.oppXi || [])];
  const nameOf = (id) => { const p = everyone.find((x) => x.id === id); return p ? (p.label || p.lastName) : "—"; };

  // Is the challenger actually touching the man on the ball yet?
  let contact = null;
  if (play?.duel && pos[play.carrierId] && pos[play.duel.by]) {
    const a = pos[play.carrierId], c = pos[play.duel.by];
    if (Math.hypot(a.x - c.x, a.y - c.y) < 4.2) contact = { x: (a.x + c.x) / 2, y: (a.y + c.y) / 2 };
  }
  const fl0 = renderRef.current.flight;
  const deliveryLanded = !!fl0 && play?.stage === "delivery" && showRef.current - fl0.t0 >= fl0.windup + fl0.dur;
  if (deliveryLanded && play.result !== "claimed") {
    const a = pos[play.ctx?.targetId], b = pos[play.ctx?.markerId];
    if (a && b) contact = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
  }
  const burstColor = play?.duel?.card === "red" ? "#ff2040" : play?.duel?.kind === "foul" ? "#ffa800" : "#ffffff";
  // The shot: strike flash at the boot, impact at gloves or body, net bulging
  const ballH = renderRef.current.ballH || 0;
  const flight = renderRef.current.flight;
  const trail = renderRef.current.trail || [];
  const tt = flight ? (flight.restart ? clockRef.current - flight.t0c : showRef.current - flight.t0) : 0;
  const isShot = !!play?.outcome;
  const layout = renderRef.current.layout;
  const settingUp = isShot && !!flight && tt < flight.windup;             // planting his foot
  const struck = !!flight && tt >= flight.windup;                          // the ball has left him
  const landed = !!flight && tt >= flight.windup + flight.dur;             // the ball has arrived
  const strikeAt = struck && tt < flight.windup + 0.25 && play?.restart !== "throwIn" ? flight.from : null;
  const impactAt = (play?.outcome === "save" || play?.outcome === "block") && landed && tt < flight.windup + flight.dur + 0.3 ? flight.to : null;
  const inNet = play?.outcome === "goal" && landed;
  const shooterPos = flight && pos[play?.carrierId];
  const ballDrawnY = ball.y - ballH * 1.6 - (layout?.hands && !struck ? 1.3 : 0);   // a throw-in is held overhead
  const skied = flight && flight.loft > 1.5;
  const callout = isShot && landed && tt < flight.windup + flight.dur + 1.4 ? ({
    goal: { text: "GOAL!", color: "#ffd600", at: { x: 50, y: play.attKey === "home" ? 10 : 90 } },
    save: { text: flight.catchIt ? "SAVED!" : "PARRIED!", color: "#00e5ff", at: flight.to },
    block: { text: "BLOCKED!", color: "#e2e8f0", at: flight.to },
    miss: { text: skied ? "OVER!" : "WIDE!", color: "#94a3b8", at: { x: clampN(flight.to.x, 12, 88), y: play.attKey === "home" ? 7 : 93 } },
  })[play.outcome] : null;
  const goalUp = inNet && play.attKey === "home";
  const goalDown = inNet && play.attKey === "away";

  let holderId = carrierId;
  if (play?.stage === "delivery") holderId = landed ? carrierId : (!struck ? play.ctx?.takerId : null);
  else if (play?.restart) holderId = landed ? flight?.receiverId : (!struck ? carrierId : null);
  else if (isShot && struck) holderId = null;
  const dot = (pl, isHomeSide) => {
    const p = pos[pl.id];
    if (!p) return null;
    const hasBall = pl.id === holderId;
    const size = hasBall ? 20 : 13;
    return (
      <div key={pl.id} style={{
        position: "absolute", left: `${p.x}%`, top: `${p.y}%`, transform: "translate(-50%, -50%)",
        display: "flex", flexDirection: "column", alignItems: "center", gap: 2, zIndex: hasBall ? 8 : 2,
      }}>
        {hasBall && (
          <div style={{
            position: "absolute", width: 46, height: 46, borderRadius: "50%",
            background: "radial-gradient(circle, rgba(255,214,0,0.38) 0%, rgba(255,214,0,0) 70%)",
            top: "50%", left: "50%", transform: "translate(-50%, -50%)", pointerEvents: "none",
          }} />
        )}
        <div style={{
          position: "relative", width: size, height: size, borderRadius: isHomeSide ? "50%" : 4,
          background: isHomeSide ? "#f8fafc" : "#0f172a",
          border: hasBall ? "3px solid #ffd600" : `2px solid ${isHomeSide ? "#94a3b8" : "#475569"}`,
          boxShadow: hasBall ? "0 0 14px rgba(255,214,0,0.95)" : "0 1px 3px rgba(0,0,0,0.55)",
          opacity: carrierId && !hasBall ? 0.72 : 1, transition: "all 0.5s ease",
        }} />
        {(isHomeSide || hasBall) && (
          <span style={{
            fontSize: hasBall ? 8.5 : 7, fontWeight: hasBall ? 900 : 800,
            color: hasBall ? "#ffd600" : "rgba(255,255,255,0.82)", opacity: carrierId && !hasBall ? 0.65 : 1,
            whiteSpace: "nowrap", textShadow: "0 1px 3px #000",
          }}>{pl.label || pl.lastName}</span>
        )}
      </div>
    );
  };

  const LINE = "2px solid rgba(255,255,255,0.32)";
  const NET_MESH = "repeating-linear-gradient(45deg, rgba(255,255,255,0.32) 0 1px, transparent 1px 4px), repeating-linear-gradient(-45deg, rgba(255,255,255,0.32) 0 1px, transparent 1px 4px)";
  const net = (top, rippling) => (
    <div key={`net-${top ? "t" : "b"}-${rippling ? live.frame : "idle"}`} style={{
      position: "absolute", left: "43.5%", width: "13%",
      top: top ? "0.7%" : "96.5%", height: "2.8%",
      border: "2px solid rgba(255,255,255,0.9)", [top ? "borderBottom" : "borderTop"]: "none",
      backgroundImage: NET_MESH, backgroundColor: "rgba(255,255,255,0.05)", borderRadius: top ? "3px 3px 0 0" : "0 0 3px 3px",
      transformOrigin: top ? "bottom" : "top",
      animation: rippling ? "fmNetRipple 0.9s ease-out" : "none",
      boxShadow: rippling ? "0 0 14px rgba(255,214,0,0.8)" : "none", zIndex: 1,
    }} />
  );
  const post = (x, y) => (
    <div key={`post-${x}-${y}`} style={{ position: "absolute", left: `${x}%`, top: `${y}%`, width: 5, height: 5,
      borderRadius: "50%", background: "#fff", transform: "translate(-50%, -50%)", zIndex: 2 }} />
  );
  const official = (o, main) => o && (
    <div style={{ position: "absolute", left: `${o.x}%`, top: `${o.y}%`, transform: "translate(-50%, -50%)",
      zIndex: 3, display: "flex", flexDirection: "column", alignItems: "center", gap: 1, pointerEvents: "none" }}>
      <div style={{ width: main ? 11 : 8, height: main ? 11 : 8, borderRadius: "50%", background: "#0b0b0b",
        border: `2px solid #f472b6`, boxShadow: "0 1px 3px rgba(0,0,0,0.6)" }} />
      {main && <span style={{ fontSize: 6.5, fontWeight: 900, color: "#f9a8d4", textShadow: "0 1px 2px #000" }}>REF</span>}
    </div>
  );

  // What's happening, in words
  const PHASE_LABEL = ["building from the back", "working it forward", "in the final third", "shooting chance"];
  let caption;
  if (play?.duel) {
    const by = nameOf(play.duel.by), on = nameOf(play.carrierId);
    caption = play.duel.kind === "foul"
      ? `${play.duel.card === "red" ? "🟥" : play.duel.card ? "🟨" : "🚫"} Foul by ${by} on ${on}${play.duel.card === "red" ? " — straight red!" : play.duel.card ? " — booked" : ""}`
      : play.duel.kind === "tackle" ? `🦶 ${by} goes in on ${on}` : `⚡ ${by} closes down ${on}`;
  } else if (play?.setPiece && play.stage === "setup") {
    const tk = nameOf(play.carrierId);
    caption = play.setPiece === "corner" ? `🚩 Corner — ${tk} to deliver`
      : play.setPiece === "fkcross" ? `🎯 Free kick out wide — ${tk} to swing it in`
      : `🎯 Free kick — ${tk} stands over it, ${play.ctx?.wallIds?.length || 4}-man wall`;
  } else if (play?.stage === "delivery") {
    const c = play.ctx || {};
    caption = !deliveryLanded ? `🚩 ${nameOf(c.takerId)} whips it in…`
      : play.result === "header" ? `🎯 ${nameOf(c.targetId)} rises highest!`
      : play.result === "cleared" ? `🧹 ${nameOf(c.markerId)} heads it clear`
      : `🧤 ${nameOf(play.carrierId)} comes and claims it`;
  } else if (play?.setPiece === "freekick" && play.stage === "quick") {
    caption = `⚡ Quick free kick — ${nameOf(play.carrierId)} takes it`;
  } else if (play?.restart) {
    const tk = nameOf(play.carrierId);
    caption = play.restart === "throwIn" ? `↩️ Throw-in — ${tk}`
      : play.restart === "goalKick" ? `🥅 Goal kick — ${tk} ${play.long ? "goes long" : "plays it short"}`
      : play.restart === "keeperBall" ? `🧤 ${tk} gets it moving`
      : `🔄 Kick-off`;
  } else if (play?.won) {
    caption = play.header ? `🦅 ${nameOf(play.carrierId)} wins the header`
      : `✅ ${nameOf(play.carrierId)} wins it off ${nameOf(play.won.from)}`;
  } else if (play?.outcome && !landed) {
    caption = settingUp ? `🎯 ${nameOf(play.carrierId)} sets himself…` : `💥 ${nameOf(play.carrierId)} shoots!`;
  } else if (play?.outcome) {
    const sh = nameOf(play.carrierId);
    caption = play.outcome === "goal" ? `⚽ GOAL — ${sh}!`
      : play.outcome === "save" ? `🧤 ${nameOf(play.keeperId)} saves from ${sh}`
      : play.outcome === "block" ? `🧱 ${nameOf(play.blockerId)} blocks ${sh}'s shot`
      : `💨 ${sh} puts it wide`;
  }
  const carrier = everyone.find((pl) => pl.id === carrierId);
  const carrierHome = carrier ? (live.xi || []).some((pl) => pl.id === carrierId) : attackingHome;

  return (
    <div style={{ marginBottom: 16 }}>
      <style>{`
        @keyframes fmNetRipple { 0% { transform: scaleY(1); } 35% { transform: scaleY(1.55) scaleX(1.06); } 100% { transform: scaleY(1); } }
        @keyframes fmBurst { 0% { transform: translate(-50%,-50%) scale(0.3); opacity: 1; } 100% { transform: translate(-50%,-50%) scale(2); opacity: 0; } }
        @keyframes fmPulse { 0% { transform: translate(-50%,-50%) scale(0.7); opacity: 0.95; } 100% { transform: translate(-50%,-50%) scale(1.7); opacity: 0; } }
        @keyframes fmPop { 0% { transform: translate(-50%,-100%) scale(0.4); opacity: 0; } 55% { transform: translate(-50%,-100%) scale(1.18); opacity: 1; } 100% { transform: translate(-50%,-100%) scale(1); opacity: 1; } }
        @keyframes fmCard { 0% { transform: translate(-50%,-100%) scale(0.2); } 60% { transform: translate(-50%,-100%) scale(1.25); } 100% { transform: translate(-50%,-100%) scale(1); } }
      `}</style>
      <div style={{
        position: "relative", width: "100%", paddingBottom: "128%", borderRadius: 10,
        background: "linear-gradient(175deg, #15803d 0%, #166534 50%, #14532d 100%)",
        border: "1px solid rgba(255,255,255,0.18)", overflow: "hidden",
      }}>
        <div style={{ position: "absolute", inset: 0 }}>
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} style={{ position: "absolute", left: 0, right: 0, top: `${i * 12.5}%`, height: "12.5%",
              background: i % 2 ? "rgba(255,255,255,0.045)" : "transparent" }} />
          ))}
          {/* Markings */}
          <div style={{ position: "absolute", left: "2%", right: "2%", top: "3.5%", bottom: "3.5%", border: LINE, borderRadius: 2 }} />
          <div style={{ position: "absolute", left: "2%", right: "2%", top: "50%", height: 2, background: "rgba(255,255,255,0.32)" }} />
          <div style={{ position: "absolute", left: "50%", top: "50%", width: "22%", paddingBottom: "22%",
            transform: "translate(-50%, -50%)", border: "2px solid rgba(255,255,255,0.28)", borderRadius: "50%" }} />
          <div style={{ position: "absolute", left: "50%", top: "50%", width: 4, height: 4, borderRadius: "50%", background: "rgba(255,255,255,0.5)", transform: "translate(-50%,-50%)" }} />
          <div style={{ position: "absolute", left: "22%", right: "22%", top: "3.5%", height: "13%", border: LINE, borderTop: "none" }} />
          <div style={{ position: "absolute", left: "22%", right: "22%", bottom: "3.5%", height: "13%", border: LINE, borderBottom: "none" }} />
          <div style={{ position: "absolute", left: "37%", right: "37%", top: "3.5%", height: "4.5%", border: LINE, borderTop: "none" }} />
          <div style={{ position: "absolute", left: "37%", right: "37%", bottom: "3.5%", height: "4.5%", border: LINE, borderBottom: "none" }} />
          <div style={{ position: "absolute", left: "50%", top: "12%", width: 3, height: 3, borderRadius: "50%", background: "rgba(255,255,255,0.5)", transform: "translate(-50%,-50%)" }} />
          <div style={{ position: "absolute", left: "50%", top: "88%", width: 3, height: 3, borderRadius: "50%", background: "rgba(255,255,255,0.5)", transform: "translate(-50%,-50%)" }} />

          {/* Goals */}
          {net(true, goalUp)}
          {net(false, goalDown)}
          {post(43.5, 3.5)}{post(56.5, 3.5)}{post(43.5, 96.5)}{post(56.5, 96.5)}

          {/* Officials */}
          {refs && official(refs.ar1, false)}
          {refs && official(refs.ar2, false)}
          {refs && official(refs.ref, true)}

          {(live.oppXi || []).map((pl) => dot(pl, false))}
          {(live.xi || []).map((pl) => dot(pl, true))}

          {/* Contact */}
          {contact && (
            <div key={`burst-${live.frame}`} style={{
              position: "absolute", left: `${contact.x}%`, top: `${contact.y}%`, width: 26, height: 26,
              borderRadius: "50%", border: `3px solid ${burstColor}`, boxShadow: `0 0 12px ${burstColor}`,
              animation: "fmBurst 0.6s ease-out forwards", pointerEvents: "none", zIndex: 10,
            }} />
          )}
          {play?.duel?.card && pos[play.duel.by] && contact && (
            <div key={`card-${live.frame}`} style={{
              position: "absolute", left: `${pos[play.duel.by].x}%`, top: `${pos[play.duel.by].y - 2.5}%`,
              width: 9, height: 13, borderRadius: 2, background: play.duel.card === "red" ? "#ff2040" : "#ffd600",
              border: "1px solid rgba(0,0,0,0.5)", animation: "fmCard 0.4s ease-out forwards", zIndex: 11,
            }} />
          )}

          {/* The set piece */}
          {layout?.tag && layout.ball && !struck && (
            <div key={`sp-${live.frame}`} style={{
              position: "absolute", left: `${layout.ball.x}%`, top: `${clampN(layout.ball.y - 2.4, 4, 96)}%`,
              padding: "2px 6px", borderRadius: 4, background: "rgba(10,14,26,0.85)", border: "1px solid #ffd600",
              color: "#ffd600", fontSize: 8.5, fontWeight: 900, letterSpacing: 0.6, whiteSpace: "nowrap",
              animation: "fmPop 0.3s ease-out forwards", zIndex: 12, pointerEvents: "none",
            }}>{layout.tag}</div>
          )}
          {layout?.tag && !layout.ball && play?.stage === "quick" && pos[play.carrierId] && (
            <div key={`sp-${live.frame}`} style={{
              position: "absolute", left: `${pos[play.carrierId].x}%`, top: `${pos[play.carrierId].y - 2.6}%`,
              padding: "2px 6px", borderRadius: 4, background: "rgba(10,14,26,0.85)", border: "1px solid #ffd600",
              color: "#ffd600", fontSize: 8.5, fontWeight: 900, whiteSpace: "nowrap",
              animation: "fmPop 0.3s ease-out forwards", zIndex: 12, pointerEvents: "none",
            }}>{layout.tag}</div>
          )}

          {/* Setting himself: a pulse round the shooter */}
          {settingUp && shooterPos && (
            <div key={`windup-${flight.frame}`} style={{
              position: "absolute", left: `${shooterPos.x}%`, top: `${shooterPos.y}%`, width: 34, height: 34, borderRadius: "50%",
              border: "3px solid #ff5a36", animation: "fmPulse 0.34s ease-out infinite", pointerEvents: "none", zIndex: 10,
            }} />
          )}
          {isShot && flight && shooterPos && tt < flight.windup + flight.dur + 0.2 && (
            <div key={`shoots-${flight.frame}`} style={{
              position: "absolute", left: `${shooterPos.x}%`, top: `${shooterPos.y - 2.6}%`,
              padding: "2px 6px", borderRadius: 4, background: "#ff3b2f", color: "#fff",
              fontSize: 9, fontWeight: 900, letterSpacing: 0.6, whiteSpace: "nowrap",
              boxShadow: "0 2px 6px rgba(0,0,0,0.5)", animation: "fmPop 0.3s ease-out forwards", zIndex: 12, pointerEvents: "none",
            }}>SHOOTS!</div>
          )}

          {/* The ball's path from the boot */}
          {isShot && struck && !landed && (
            <svg viewBox="0 0 100 100" preserveAspectRatio="none"
              style={{ position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none", zIndex: 8 }}>
              <line x1={flight.from.x} y1={flight.from.y} x2={ball.x} y2={ballDrawnY}
                stroke="rgba(255,224,102,0.35)" strokeWidth="7" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
              <line x1={flight.from.x} y1={flight.from.y} x2={ball.x} y2={ballDrawnY}
                stroke="#fff3b0" strokeWidth="2.2" strokeLinecap="round" strokeDasharray="4 3" vectorEffect="non-scaling-stroke" />
            </svg>
          )}

          {/* What happened, where it happened */}
          {callout && (
            <div key={`callout-${flight.frame}`} style={{
              position: "absolute", left: `${callout.at.x}%`, top: `${clampN(callout.at.y, 6, 94)}%`,
              fontSize: play.outcome === "goal" ? 20 : 13, fontWeight: 900, color: callout.color, letterSpacing: 1,
              textShadow: "0 2px 6px rgba(0,0,0,0.9), 0 0 12px rgba(0,0,0,0.6)", whiteSpace: "nowrap",
              animation: "fmPop 0.35s ease-out forwards", zIndex: 13, pointerEvents: "none",
            }}>{callout.text}</div>
          )}

          {/* The strike */}
          {strikeAt && (
            <div key={`strike-${flight.frame}`} style={{
              position: "absolute", left: `${strikeAt.x}%`, top: `${strikeAt.y}%`, width: 32, height: 32, borderRadius: "50%",
              border: "4px solid #fff7c2", boxShadow: "0 0 18px #ffd600",
              animation: "fmBurst 0.35s ease-out forwards", pointerEvents: "none", zIndex: 10,
            }} />
          )}
          {impactAt && (
            <div key={`impact-${flight.frame}`} style={{
              position: "absolute", left: `${impactAt.x}%`, top: `${impactAt.y}%`, width: 24, height: 24, borderRadius: "50%",
              border: "3px solid #ffffff", boxShadow: "0 0 12px #ffffff",
              animation: "fmBurst 0.45s ease-out forwards", pointerEvents: "none", zIndex: 10,
            }} />
          )}

          {/* Flight trail */}
          {trail.map((tp, i) => (
            <div key={`trail-${i}`} style={{
              position: "absolute", left: `${tp.x}%`, top: `${tp.y}%`, width: 3 + i * 0.8, height: 3 + i * 0.8,
              borderRadius: "50%", background: "#ffe066", opacity: (i + 1) / (trail.length + 2) * 0.7,
              transform: "translate(-50%, -50%)", pointerEvents: "none", zIndex: 8,
            }} />
          ))}

          {/* Ball — lifted and enlarged when it's in the air, with its shadow on the grass */}
          {ballH > 0.05 && (
            <div style={{
              position: "absolute", left: `${ball.x}%`, top: `${ball.y}%`, width: 9, height: 4, borderRadius: "50%",
              background: "rgba(0,0,0,0.35)", opacity: Math.max(0.15, 0.5 - ballH * 0.15),
              transform: "translate(-50%, -50%)", zIndex: 7, pointerEvents: "none",
            }} />
          )}
          <div style={{
            position: "absolute", left: `${ball.x}%`, top: `${ballDrawnY}%`,
            width: 9 + ballH * 4, height: 9 + ballH * 4, borderRadius: "50%",
            background: "radial-gradient(circle at 30% 30%, #fffbe6, #ffd600)", border: "1px solid #7a5c00",
            transform: "translate(-50%, -50%)",
            boxShadow: flight ? "0 0 18px rgba(255,214,0,1)" : "0 0 10px rgba(255,214,0,0.95)",
            zIndex: 9,
          }} />

          <div style={{ position: "absolute", left: 6, top: 6, fontSize: 8, fontWeight: 800, color: "rgba(255,255,255,0.65)" }}>▲ {awayName}</div>
          <div style={{ position: "absolute", left: 6, bottom: 6, fontSize: 8, fontWeight: 800, color: "rgba(255,255,255,0.85)" }}>▼ {homeName}</div>
        </div>
      </div>

      <div style={{
        marginTop: 7, padding: "7px 10px", borderRadius: 7,
        background: carrier ? "rgba(255,214,0,0.08)" : N.card,
        border: `1px solid ${carrier ? "rgba(255,214,0,0.28)" : N.border}`,
        display: "flex", alignItems: "center", justifyContent: "center", gap: 7, textAlign: "center",
      }}>
        {caption ? (
          <span style={{ fontSize: 11, color: N.text, fontWeight: 700 }}>{caption}</span>
        ) : carrier ? (
          <span style={{ fontSize: 11, color: N.muted }}>
            ⚽ <strong style={{ color: "#ffd600", fontWeight: 900 }}>{carrier.label || carrier.lastName}</strong>
            <span style={{ opacity: 0.75 }}> ({carrier.slot}{carrier.role ? ` · ${carrier.role}` : ""})</span>
            {" · "}{carrierHome ? homeName : awayName}{" "}{PHASE_LABEL[phase]}
          </span>
        ) : (
          <span style={{ fontSize: 11, color: N.muted }}>⚽ Kick-off</span>
        )}
      </div>
    </div>
  );
}

// Returns the in-possession coordinates for the XI
function getAttackingShape(squad, formation, behaviour) {
  const base = FORMATIONS[formation].coords;
  const slots = FORMATIONS[formation].positions;
  const b = behaviour || TACTICS.balanced.behaviour;

  // How far the whole block pushes up
  const push = ((b.defLine - 50) / 50) * 5 + ((b.tempo - 50) / 50) * 3;
  // How much the shape stretches or squeezes horizontally
  const widthPull = (b.width - 50) / 50;

  return base.map((c, i) => {
    const player = squad[i];
    const slot = slots[i];
    if (!player) return { ...c };

    const role = player.activeRole || player.role || "";
    const focus = player.focus || "Balanced";
    let x = c.x;
    let y = c.y;

    // Goalkeeper barely moves — just a nudge for a sweeper keeper
    if (slot === "GK") {
      y -= role === "Sweeper Keeper" ? 5 : 1;
      return { x, y };
    }

    // Push the block up the pitch
    y -= push;
    // Role-driven vertical movement
    if (ADVANCING_ROLES.has(role)) y -= 9;
    else if (ANCHORING_ROLES.has(role)) y += 4;
    // Focus fine-tunes it
    y += FOCUS_SHIFT[focus] ?? 0;

    // Horizontal: inverted roles tuck toward the middle
    const fromCentre = x - 50;
    if (INVERTING_ROLES.has(role)) {
      x = 50 + fromCentre * 0.45;
    } else {
      // Width instruction stretches or narrows the shape
      x = 50 + fromCentre * (1 + widthPull * 0.28);
    }

    // Wide attacking roles hug the touchline even harder
    if (["Winger", "Wide Forward", "Wide Midfielder"].includes(role)) {
      x = 50 + fromCentre * 1.12;
    }

    return {
      x: Math.max(5, Math.min(95, x)),
      y: Math.max(6, Math.min(94, y)),
    };
  });
}

const FORMATION_MATCHUPS = (() => {
  const keys = Object.keys(FORMATIONS);
  const styles = {};
  keys.forEach((k) => { styles[k] = FORMATIONS[k].style; });

  // Style advantage matrix
  const ADV = {
    attacking:  { attacking: 0, balanced: -1, midfield: 2, defensive: -2, ultradef: 3, narrow: 1, ultraatk: 0, packed_mid: -2, midblock: -1, bunker: 4, creative: 1 },
    balanced:   { attacking: 1, balanced: 0, midfield: 0, defensive: 1, ultradef: 2, narrow: 0, ultraatk: 2, packed_mid: -1, midblock: 0, bunker: 2, creative: 0 },
    midfield:   { attacking: -2, balanced: 0, midfield: 0, defensive: 1, ultradef: -1, narrow: -1, ultraatk: -2, packed_mid: 1, midblock: 1, bunker: 0, creative: 1 },
    defensive:  { attacking: 2, balanced: -1, midfield: -1, defensive: 0, ultradef: -2, narrow: 1, ultraatk: 3, packed_mid: 0, midblock: 0, bunker: -2, creative: -1 },
    ultradef:   { attacking: -3, balanced: -2, midfield: 1, defensive: 2, ultradef: 0, narrow: 0, ultraatk: -4, packed_mid: 1, midblock: 1, bunker: 0, creative: -2 },
    narrow:     { attacking: -1, balanced: 0, midfield: 1, defensive: -1, ultradef: 0, narrow: 0, ultraatk: -1, packed_mid: 1, midblock: 0, bunker: 1, creative: 2 },
    ultraatk:   { attacking: 0, balanced: -2, midfield: 2, defensive: -3, ultradef: 4, narrow: 1, ultraatk: 0, packed_mid: -3, midblock: -2, bunker: 5, creative: 1 },
    packed_mid: { attacking: 2, balanced: 1, midfield: -1, defensive: 0, ultradef: -1, narrow: -1, ultraatk: 3, packed_mid: 0, midblock: 0, bunker: 1, creative: -1 },
    midblock:   { attacking: 1, balanced: 0, midfield: -1, defensive: 0, ultradef: -1, narrow: 0, ultraatk: 2, packed_mid: 0, midblock: 0, bunker: 0, creative: -1 },
    bunker:     { attacking: -4, balanced: -2, midfield: 0, defensive: 2, ultradef: 0, narrow: -1, ultraatk: -5, packed_mid: -1, midblock: 0, bunker: 0, creative: -3 },
    creative:   { attacking: -1, balanced: 0, midfield: -1, defensive: 1, ultradef: 2, narrow: -2, ultraatk: -1, packed_mid: 1, midblock: 1, bunker: 3, creative: 0 },
  };

  const table = {};
  keys.forEach((a) => {
    table[a] = {};
    keys.forEach((b) => {
      table[a][b] = ADV[styles[a]]?.[styles[b]] ?? 0;
    });
  });
  return table;
})();

/* ═══════════════════════════════════════════════════════════════════════
   TACTICS SYSTEM
   Rock-paper-scissors style counter system.
   ═══════════════════════════════════════════════════════════════════════ */

const TACTICS = {
  gegenpress: {
    name: "Gegenpress", icon: "🔥",
    desc: "Win the ball back instantly. Suffocating, but it burns legs.",
    color: "#ff6b00",
    behaviour: {
      tempo: 88, directness: 62, width: 62, creativeFreedom: 55,
      pressIntensity: 95, defLine: 88, aggression: 82,
      transitionSpeed: 90, patience: 20, counterPress: 95,
    },
    fitnessDrain: 1.5,
    lateGameDecay: 0.85,
  },
  attacking: {
    name: "All-Out Attack", icon: "⚔️",
    desc: "Everyone forward. Chaos, chances, and a wide-open back door.",
    color: "#ff4060",
    behaviour: {
      tempo: 85, directness: 70, width: 78, creativeFreedom: 85,
      pressIntensity: 70, defLine: 82, aggression: 65,
      transitionSpeed: 80, patience: 25, counterPress: 55,
    },
    fitnessDrain: 1.4,
    lateGameDecay: 0.9,
  },
  tikitaka: {
    name: "Tiki-Taka", icon: "🎯",
    desc: "Endless short passes. Suffocate them with the ball, not the press.",
    color: "#a78bfa",
    behaviour: {
      tempo: 45, directness: 15, width: 45, creativeFreedom: 60,
      pressIntensity: 62, defLine: 72, aggression: 40,
      transitionSpeed: 35, patience: 92, counterPress: 70,
    },
    fitnessDrain: 0.9,
    lateGameDecay: 1.0,
  },
  possession: {
    name: "Control", icon: "🎛️",
    desc: "Own the ball, pick your moment. Balanced and patient.",
    color: "#00d4ff",
    behaviour: {
      tempo: 55, directness: 35, width: 58, creativeFreedom: 60,
      pressIntensity: 55, defLine: 62, aggression: 45,
      transitionSpeed: 50, patience: 78, counterPress: 60,
    },
    fitnessDrain: 0.95,
    lateGameDecay: 1.0,
  },
  balanced: {
    name: "Balanced", icon: "⚖️",
    desc: "No extremes. Solid in every phase, dominant in none.",
    color: "#8ab4f8",
    behaviour: {
      tempo: 55, directness: 50, width: 55, creativeFreedom: 50,
      pressIntensity: 50, defLine: 55, aggression: 50,
      transitionSpeed: 55, patience: 50, counterPress: 50,
    },
    fitnessDrain: 1.0,
    lateGameDecay: 1.0,
  },
  wingplay: {
    name: "Wing Play", icon: "🦅",
    desc: "Stretch them wide, whip it in. Lives and dies by the flanks.",
    color: "#00ff88",
    behaviour: {
      tempo: 62, directness: 58, width: 92, creativeFreedom: 55,
      pressIntensity: 52, defLine: 58, aggression: 50,
      transitionSpeed: 62, patience: 48, counterPress: 48,
    },
    fitnessDrain: 1.15,
    lateGameDecay: 0.95,
  },
  counter: {
    name: "Counter-Attack", icon: "⚡",
    desc: "Sit, absorb, then break at speed into the space they leave.",
    color: "#ffd700",
    behaviour: {
      tempo: 70, directness: 78, width: 52, creativeFreedom: 62,
      pressIntensity: 30, defLine: 32, aggression: 45,
      transitionSpeed: 95, patience: 35, counterPress: 25,
    },
    fitnessDrain: 0.85,
    lateGameDecay: 1.05,
  },
  longball: {
    name: "Long Ball", icon: "🎱",
    desc: "Skip the midfield entirely. Ugly, direct, surprisingly effective.",
    color: "#c8d6e0",
    behaviour: {
      tempo: 60, directness: 95, width: 50, creativeFreedom: 30,
      pressIntensity: 42, defLine: 45, aggression: 58,
      transitionSpeed: 72, patience: 15, counterPress: 35,
    },
    fitnessDrain: 0.8,
    lateGameDecay: 1.05,
  },
  defensive: {
    name: "Park the Bus", icon: "🛡️",
    desc: "Two banks of four, no risks. Nearly impossible to break down.",
    color: "#64748b",
    behaviour: {
      tempo: 35, directness: 62, width: 38, creativeFreedom: 20,
      pressIntensity: 18, defLine: 15, aggression: 38,
      transitionSpeed: 40, patience: 45, counterPress: 15,
    },
    fitnessDrain: 0.7,
    lateGameDecay: 1.1,
  },
};

/* ═══════════════════════════════════════════════════════════════════════
   TEAM INSTRUCTIONS — fine-tune the tactic's behaviour
   Each instruction shifts specific behaviour values.
   ═══════════════════════════════════════════════════════════════════════ */

const INSTRUCTION_GROUPS = [
  {
    id: "possession", label: "In Possession", icon: "⚽",
    instructions: [
      { id: "directness", label: "Passing Directness", options: [
        { v: "short", label: "Short", shift: { directness: -22, patience: 12 } },
        { v: "mixed", label: "Mixed", shift: {} },
        { v: "direct", label: "Direct", shift: { directness: 22, patience: -12 } },
      ]},
      { id: "tempo", label: "Tempo", options: [
        { v: "slow", label: "Slow", shift: { tempo: -20, patience: 15 } },
        { v: "normal", label: "Normal", shift: {} },
        { v: "high", label: "High", shift: { tempo: 20, patience: -15 } },
      ]},
      { id: "width", label: "Width", options: [
        { v: "narrow", label: "Narrow", shift: { width: -22 } },
        { v: "standard", label: "Standard", shift: {} },
        { v: "wide", label: "Wide", shift: { width: 22 } },
      ]},
      { id: "freedom", label: "Creative Freedom", options: [
        { v: "disciplined", label: "Disciplined", shift: { creativeFreedom: -22 } },
        { v: "balanced", label: "Balanced", shift: {} },
        { v: "expressive", label: "Expressive", shift: { creativeFreedom: 22 } },
      ]},
      { id: "focus", label: "Attacking Focus", options: [
        { v: "central", label: "Central", shift: { width: -15 } },
        { v: "mixed", label: "Mixed", shift: {} },
        { v: "flanks", label: "Flanks", shift: { width: 18 } },
      ]},
    ],
  },
  {
    id: "transition", label: "In Transition", icon: "🔄",
    instructions: [
      { id: "attTransition", label: "Winning the Ball", options: [
        { v: "counter", label: "Counter", shift: { transitionSpeed: 20, directness: 10 } },
        { v: "hold", label: "Hold Shape", shift: { transitionSpeed: -20, patience: 12 } },
      ]},
      { id: "defTransition", label: "Losing the Ball", options: [
        { v: "counterpress", label: "Counter-Press", shift: { counterPress: 25, pressIntensity: 10 } },
        { v: "regroup", label: "Regroup", shift: { counterPress: -25, defLine: -8 } },
      ]},
    ],
  },
  {
    id: "defence", label: "Out of Possession", icon: "🛡️",
    instructions: [
      { id: "defLine", label: "Defensive Line", options: [
        { v: "deep", label: "Deep", shift: { defLine: -22 } },
        { v: "standard", label: "Standard", shift: {} },
        { v: "high", label: "High", shift: { defLine: 22 } },
      ]},
      { id: "press", label: "Pressing Intensity", options: [
        { v: "low", label: "Low", shift: { pressIntensity: -22 } },
        { v: "medium", label: "Medium", shift: {} },
        { v: "high", label: "High", shift: { pressIntensity: 22 } },
      ]},
      { id: "tackling", label: "Tackling", options: [
        { v: "cautious", label: "Cautious", shift: { aggression: -20 } },
        { v: "normal", label: "Normal", shift: {} },
        { v: "aggressive", label: "Aggressive", shift: { aggression: 22 } },
      ]},
      { id: "marking", label: "Marking", options: [
        { v: "zonal", label: "Zonal", shift: {} },
        { v: "man", label: "Man-to-Man", shift: { aggression: 10, pressIntensity: 8 } },
      ]},
    ],
  },
];

const DEFAULT_INSTRUCTIONS = {
  directness: "mixed", tempo: "normal", width: "standard", freedom: "balanced", focus: "mixed",
  attTransition: "counter", defTransition: "counterpress",
  defLine: "standard", press: "medium", tackling: "normal", marking: "zonal",
};

// Merge a tactic's base behaviour with the player's instruction choices
function resolveBehaviour(tacticKey, instructions) {
  const base = { ...(TACTICS[tacticKey]?.behaviour || TACTICS.balanced.behaviour) };
  const instr = { ...DEFAULT_INSTRUCTIONS, ...(instructions || {}) };

  INSTRUCTION_GROUPS.forEach((group) => {
    group.instructions.forEach((ins) => {
      const chosen = ins.options.find((o) => o.v === instr[ins.id]);
      if (!chosen) return;
      Object.entries(chosen.shift || {}).forEach(([k, v]) => {
        base[k] = Math.max(1, Math.min(100, (base[k] ?? 50) + v));
      });
    });
  });

  return base;
}


/* ═══════════════════════════════════════════════════════════════════════
   PLAYER ROLES
   Assigned based on position + dominant stats.
   Provides a small OVR bonus (+1 to +3) when the role fits the slot.
   ═══════════════════════════════════════════════════════════════════════ */

const ROLE_DEFINITIONS = {
  GK: [
    { role: "Shot Stopper", key: "reactions", label: "Reflexes-focused", desc: "Stays on the line and focuses purely on making saves. Best for teams that defend deep and face lots of shots." },
    { role: "Sweeper Keeper", key: "acceleration", label: "Plays high line", desc: "Comes off the line aggressively to sweep up through balls. Ideal for high-pressing teams that push their defensive line forward." },
    { role: "Goalkeeper", key: "composure", label: "Traditional keeper", desc: "A balanced approach between shot-stopping and distribution. Reliable and predictable in all situations." },
  ],
  CB: [
    { role: "Ball-Playing CB", key: "shortPassing", label: "Builds from back", desc: "Comfortable on the ball and looks to start attacks with accurate passes from deep. Key for possession-based systems." },
    { role: "Stopper", key: "standingTackle", label: "Aggressive tackler", desc: "Steps up aggressively to win the ball and break up opposition attacks before they develop. Physical and dominant." },
    { role: "Leader", key: "composure", label: "Organizes defense", desc: "The defensive organizer who reads the game and positions teammates. Stays calm under pressure and rarely makes mistakes." },
    { role: "Libero", key: "dribbling", label: "Carries ball forward", desc: "An old-school sweeper who drives forward with the ball into midfield. High risk, high reward — creates overloads but leaves gaps." },
    { role: "Aerial Threat", key: "headingAccuracy", label: "Dominates in the air", desc: "Wins everything in the air — defensive headers, set-piece goals, and long-ball duels. A tower at the back and a weapon at corners." },
  ],
  LB: [
    { role: "Attacking Fullback", key: "crossing", label: "Overlapping runs", desc: "Bombs forward constantly to deliver crosses and join attacks. Provides width and stretches the opposition but can leave space behind." },
    { role: "Defensive Fullback", key: "defAwareness", label: "Stays back", desc: "Prioritizes defensive duties and rarely ventures forward. Solid and reliable, perfect when you need to protect a lead." },
    { role: "Inverted Fullback", key: "shortPassing", label: "Tucks into midfield", desc: "Moves inside to act as an extra midfielder when in possession, creating numerical superiority in the center. Modern and tactical." },
    { role: "Wing-Back", key: "stamina", label: "Covers entire flank", desc: "Covers the entire left side from box to box. Requires incredible stamina to defend and attack throughout the match." },
  ],
  RB: [
    { role: "Attacking Fullback", key: "crossing", label: "Overlapping runs", desc: "Bombs forward constantly to deliver crosses and join attacks. Provides width and stretches the opposition but can leave space behind." },
    { role: "Defensive Fullback", key: "defAwareness", label: "Stays back", desc: "Prioritizes defensive duties and rarely ventures forward. Solid and reliable, perfect when you need to protect a lead." },
    { role: "Inverted Fullback", key: "shortPassing", label: "Tucks into midfield", desc: "Moves inside to act as an extra midfielder when in possession, creating numerical superiority in the center. Modern and tactical." },
    { role: "Wing-Back", key: "stamina", label: "Covers entire flank", desc: "Covers the entire right side from box to box. Requires incredible stamina to defend and attack throughout the match." },
  ],
  LWB: [
    { role: "Wing-Back", key: "stamina", label: "Box-to-box wide", desc: "A tireless runner who patrols the entire left flank. Expected to defend like a fullback and attack like a winger." },
    { role: "Complete Wing-Back", key: "crossing", label: "Attack + defend", desc: "Equally comfortable defending and creating chances. Delivers quality crosses and tracks back to make crucial tackles." },
    { role: "Defensive Wing-Back", key: "defAwareness", label: "Safety first", desc: "Sits deeper than a traditional wing-back, focusing on defending while only pushing forward when it's safe." },
  ],
  RWB: [
    { role: "Wing-Back", key: "stamina", label: "Box-to-box wide", desc: "A tireless runner who patrols the entire right flank. Expected to defend like a fullback and attack like a winger." },
    { role: "Complete Wing-Back", key: "crossing", label: "Attack + defend", desc: "Equally comfortable defending and creating chances. Delivers quality crosses and tracks back to make crucial tackles." },
    { role: "Defensive Wing-Back", key: "defAwareness", label: "Safety first", desc: "Sits deeper than a traditional wing-back, focusing on defending while only pushing forward when it's safe." },
  ],
  CDM: [
    { role: "Destroyer", key: "interceptions", label: "Breaks up play", desc: "A pure ball-winner who hunts down opponents and breaks up attacks. Doesn't care about the ball after winning it — just wins it." },
    { role: "Deep Playmaker", key: "longPassing", label: "Dictates tempo", desc: "Controls the game's rhythm from deep. Sprays long diagonal passes and switches play. The quarterback of the team." },
    { role: "Holding Midfielder", key: "defAwareness", label: "Shields the back line", desc: "Sits in front of the defense as a protective screen. Covers for attacking teammates and fills gaps when the team pushes forward." },
    { role: "Anchor", key: "strength", label: "Immovable wall", desc: "Plants himself in front of the defense and doesn't move. Uses strength and positioning to block passing lanes and stop counters." },
    { role: "Half-Back", key: "composure", label: "Drops between CBs", desc: "Drops between the center-backs when building up play, creating a back three. Allows fullbacks to push higher with cover." },
  ],
  CM: [
    { role: "Box-to-Box", key: "stamina", label: "Covers every blade", desc: "The engine of the team. Tackles in their own box and arrives in the opposition box to score. Covers more ground than anyone." },
    { role: "Playmaker", key: "vision", label: "Creates chances", desc: "The creative brain in midfield. Finds killer passes, orchestrates attacks, and makes the team tick with intelligent movement." },
    { role: "Mezzala", key: "dribbling", label: "Drives forward", desc: "A half-winger who drives forward from a central position into wide areas. Carries the ball with purpose and creates chaos." },
    { role: "Carrilero", key: "interceptions", label: "Shuttles side to side", desc: "Moves laterally across the midfield to close down space. A disciplined worker who connects defense and attack without glamour." },
    { role: "Deep-Lying Playmaker", key: "longPassing", label: "Controls from deep", desc: "Drops deep to receive the ball and dictates play from behind the midfield line. The conductor who sets the tempo." },
    { role: "Pressing Midfielder", key: "aggression", label: "High-energy presser", desc: "Presses opponents relentlessly, forcing mistakes high up the pitch. Energetic and aggressive, perfect for counter-pressing systems." },
  ],
  CAM: [
    { role: "Advanced Playmaker", key: "vision", label: "The creative hub", desc: "The team's chief creator, operating between the lines. Picks out passes that nobody else sees and unlocks the tightest defenses." },
    { role: "Shadow Striker", key: "attackPositioning", label: "Arrives late in box", desc: "Plays just behind the striker and makes late runs into the box. Arrives unmarked to score goals that others can't." },
    { role: "Trequartista", key: "dribbling", label: "Free-roaming creator", desc: "Given complete freedom to roam anywhere in the final third. Unpredictable and magical, but requires the team to cover for them." },
    { role: "Enganche", key: "shortPassing", label: "Classic #10 playmaker", desc: "The old-school number 10 who stays central and pulls the strings. Doesn't track back — the team plays through them." },
    { role: "Half-Winger", key: "acceleration", label: "Drifts wide to create", desc: "Starts centrally but drifts wide to create overloads on the flanks. Combines the playmaker and winger roles." },
  ],
  LM: [
    { role: "Wide Midfielder", key: "crossing", label: "Stretches play", desc: "Holds width on the left side and delivers crosses. Provides balance and stretches the opposition's defensive shape." },
    { role: "Wide Playmaker", key: "vision", label: "Creates from the wing", desc: "A creative player who operates from wide areas, cutting inside to find passes rather than just crossing." },
    { role: "Inside Midfielder", key: "shortPassing", label: "Cuts inside", desc: "Starts wide but drifts centrally to add numbers in midfield. Helps control possession through the middle of the park." },
    { role: "Defensive Winger", key: "defAwareness", label: "Tracks back to defend", desc: "Prioritizes defensive work, tracking opposition fullbacks and wingers. Provides width going forward but defense comes first." },
  ],
  RM: [
    { role: "Wide Midfielder", key: "crossing", label: "Stretches play", desc: "Holds width on the right side and delivers crosses. Provides balance and stretches the opposition's defensive shape." },
    { role: "Wide Playmaker", key: "vision", label: "Creates from the wing", desc: "A creative player who operates from wide areas, cutting inside to find passes rather than just crossing." },
    { role: "Inside Midfielder", key: "shortPassing", label: "Cuts inside", desc: "Starts wide but drifts centrally to add numbers in midfield. Helps control possession through the middle of the park." },
    { role: "Defensive Winger", key: "defAwareness", label: "Tracks back to defend", desc: "Prioritizes defensive work, tracking opposition fullbacks and wingers. Provides width going forward but defense comes first." },
  ],
  LW: [
    { role: "Winger", key: "acceleration", label: "Hugs the touchline", desc: "Stays wide on the left touchline, uses pace to beat defenders and delivers crosses into the box. A traditional wide threat." },
    { role: "Inside Forward", key: "finishing", label: "Cuts inside to shoot", desc: "Drifts inside from the left wing onto their stronger foot to shoot or play through balls. More of a goal threat than a crosser." },
    { role: "Inverted Winger", key: "dribbling", label: "Dribbles inward", desc: "Cuts inside from the left to dribble through central areas. Creates space for the overlapping fullback behind them." },
    { role: "Wide Forward", key: "attackPositioning", label: "Stays high and wide", desc: "A forward who operates from the left wing. Stays high up the pitch and looks to get behind the defensive line." },
    { role: "Raumdeuter", key: "composure", label: "Space investigator", desc: "The 'space interpreter' — moves into pockets of space that others ignore. Unconventional movement that confuses defenders." },
  ],
  RW: [
    { role: "Winger", key: "acceleration", label: "Hugs the touchline", desc: "Stays wide on the right touchline, uses pace to beat defenders and delivers crosses into the box. A traditional wide threat." },
    { role: "Inside Forward", key: "finishing", label: "Cuts inside to shoot", desc: "Drifts inside from the right wing onto their stronger foot to shoot or play through balls. More of a goal threat than a crosser." },
    { role: "Inverted Winger", key: "dribbling", label: "Dribbles inward", desc: "Cuts inside from the right to dribble through central areas. Creates space for the overlapping fullback behind them." },
    { role: "Wide Forward", key: "attackPositioning", label: "Stays high and wide", desc: "A forward who operates from the right wing. Stays high up the pitch and looks to get behind the defensive line." },
    { role: "Raumdeuter", key: "composure", label: "Space investigator", desc: "The 'space interpreter' — moves into pockets of space that others ignore. Unconventional movement that confuses defenders." },
  ],
  ST: [
    { role: "Target Man", key: "strength", label: "Holds up play", desc: "A physical striker who receives long balls, holds off defenders, and brings teammates into play. The focal point of direct attacks." },
    { role: "Poacher", key: "finishing", label: "Clinical in the box", desc: "Lives inside the penalty box waiting for chances. Doesn't contribute much outside the box but is deadly when the ball arrives." },
    { role: "False 9", key: "shortPassing", label: "Drops deep to link", desc: "Drops deep from the striker position into midfield, dragging center-backs out of position and creating space for others." },
    { role: "Pace Merchant", key: "sprintSpeed", label: "Runs in behind", desc: "Uses raw speed to run in behind the defensive line. Thrives on through balls and long passes over the top." },
    { role: "Complete Forward", key: "composure", label: "Does everything", desc: "Can do it all — hold up play, run in behind, finish, create. The most versatile striker role, but requires world-class ability." },
    { role: "Advanced Forward", key: "attackPositioning", label: "Always on the shoulder", desc: "Stays on the shoulder of the last defender, constantly looking to make runs. A pure goal-scorer who lives offside." },
    { role: "Pressing Forward", key: "aggression", label: "Presses from the front", desc: "Leads the press from the front, harassing defenders and forcing mistakes. Sets the tone for the entire team's defensive work." },
  ],
  CF: [
    { role: "Complete Forward", key: "composure", label: "Does everything", desc: "A versatile forward who can score, create, and hold up play. Adapts to whatever the team needs in any given moment." },
    { role: "Poacher", key: "finishing", label: "Lives in the box", desc: "A pure goal-scorer who occupies the penalty area and converts chances. Doesn't do much else, but finishes everything." },
    { role: "Deep-Lying Forward", key: "shortPassing", label: "Links midfield to attack", desc: "Drops into the space between midfield and defense to receive the ball and link play. Creates chances for runners beyond." },
    { role: "Trequartista", key: "dribbling", label: "Free-roaming genius", desc: "A creative genius with total freedom. Roams across the final third with the ball, creating magic out of nothing." },
    { role: "Target Man", key: "strength", label: "Wins aerial duels", desc: "Uses physicality to win aerial battles and hold the ball up for onrushing teammates. The team's outlet under pressure." },
  ],
};

function assignRole(player) {
  const defs = ROLE_DEFINITIONS[player.naturalPosition] || [{ role: "Utility", key: "reactions", label: "Versatile" }];
  let bestRole = defs[0];
  let bestVal = player.detailed[defs[0].key] || 0;
  for (const def of defs) {
    const val = player.detailed[def.key] || 0;
    if (val > bestVal) {
      bestVal = val;
      bestRole = def;
    }
  }
  return { role: bestRole.role, roleLabel: bestRole.label };
}

/* ═══════════════════════════════════════════════════════════════════════
   PLAYER FOCUS SYSTEM
   Focus determines how a player contributes in matches.
   ═══════════════════════════════════════════════════════════════════════ */

const FOCUS_OPTIONS = {
  GK: ["Defend", "Build-Up"],
  CB: ["Defend", "Balanced", "Build-Up"],
  LB: ["Defend", "Support", "Attack"],
  RB: ["Defend", "Support", "Attack"],
  LWB: ["Support", "Attack", "Balanced"],
  RWB: ["Support", "Attack", "Balanced"],
  CDM: ["Defend", "Balanced", "Support"],
  CM: ["Balanced", "Attack", "Defend", "Support"],
  CAM: ["Attack", "Balanced", "Support"],
  LM: ["Balanced", "Attack", "Support"],
  RM: ["Balanced", "Attack", "Support"],
  LW: ["Attack", "Balanced", "Support"],
  RW: ["Attack", "Balanced", "Support"],
  ST: ["Attack", "Balanced"],
  CF: ["Attack", "Balanced", "Support"],
};

const FOCUS_COLORS = {
  Attack: "#ff4060",
  Balanced: "#00d4ff",
  Defend: "#00ff88",
  Support: "#ffd700",
  "Build-Up": "#a78bfa",
};

function getDefaultFocus(position) {
  const opts = FOCUS_OPTIONS[position] || ["Balanced"];
  return opts[0];
}

// Bonus for playing in natural role (+1 OVR)
function getRoleBonus(player) {
  if (!player.activeRole || player.activeRole === player.role) return 1;
  return 0;
}

// Available roles for a player based on their current slot position
function getAvailableRoles(slotPosition) {
  return ROLE_DEFINITIONS[slotPosition] || [{ role: "Utility", key: "reactions", label: "Versatile" }];
}

/* ═══════════════════════════════════════════════════════════════════════
   FITNESS SYSTEM
   Players lose fitness when they play. Low fitness = OVR penalty.
   Bench players recover fitness each match.
   ═══════════════════════════════════════════════════════════════════════ */

function getFitnessPenalty(fitness) {
  if (fitness >= 80) return 0;
  if (fitness >= 60) return 2;
  if (fitness >= 40) return 5;
  if (fitness >= 20) return 10;
  return 20;
}

// How much a match actually took out of one player.
// Driven by the minutes he played, his stamina and his age — not a flat roll
// applied to the whole eleven, which treated a 90-minute shift and a 5-minute
// cameo exactly the same.
function matchFitnessChange(player, minutesPlayed, tacticDrain, benchRecovery) {
  const mins = Math.max(0, minutesPlayed || 0);
  if (mins === 0) return benchRecovery;              // never left the bench
  const share = Math.min(1, mins / 90);
  const stamina = player.detailed?.stamina ?? 55;
  const staminaMult = 1 + (60 - stamina) / 110;      // high stamina tires slower
  const age = player.age ?? 25;
  const ageMult = age >= 32 ? 1.12 : age <= 21 ? 0.94 : 1;
  const drain = randInt(14, 24) * share * (tacticDrain ?? 1) * staminaMult * ageMult;
  const rested = benchRecovery * (1 - share) * 0.5;  // partial rest if subbed
  return -Math.round(drain) + Math.round(rested);
}

function getFitnessColor(fitness) {
  if (fitness >= 80) return "#00ff88";
  if (fitness >= 60) return "#00d4ff";
  if (fitness >= 40) return "#ffa800";
  return "#ff4060";
}

/* ═══════════════════════════════════════════════════════════════════════
   CHEMISTRY SYSTEM
   Calculated from nationality links between adjacent players.
   Higher chemistry = bonus to effective team OVR.
   ═══════════════════════════════════════════════════════════════════════ */

function calculateChemistry(squad, formation) {
  if (squad.length < 11) return { total: 0, bonus: 0, links: 0 };

  const coords = FORMATIONS[formation].coords;
  let links = 0;
  let positionFit = 0;

  // Count nationality links between nearby players
  for (let i = 0; i < squad.length; i++) {
    // Position fit: player in natural or alt position
    const slotPos = FORMATIONS[formation].positions[i];
    if (squad[i].naturalPosition === slotPos) {
      positionFit += 2;
    } else if (squad[i].altPositions?.includes(slotPos)) {
      positionFit += 1;
    }

    for (let j = i + 1; j < squad.length; j++) {
      // Calculate distance between players on pitch
      const dx = coords[i].x - coords[j].x;
      const dy = coords[i].y - coords[j].y;
      const dist = Math.sqrt(dx * dx + dy * dy);

      // Only count links between nearby players (within ~35 units)
      if (dist < 35) {
        if (squad[i].nationality === squad[j].nationality) {
          links += 2; // Strong link = same nationality
        } else {
          links += 0.5; // Weak link = just being neighbors
        }
      }
    }
  }

  // Chemistry out of 100
  const rawChem = Math.min(100, Math.round((links * 4) + (positionFit * 3)));
  // Bonus to team OVR: 0 to +8
  const bonus = Math.round((rawChem / 100) * 8);

  return { total: rawChem, bonus, links: Math.round(links) };
}

/* ═══════════════════════════════════════════════════════════════════════
   DATA POOLS
   ═══════════════════════════════════════════════════════════════════════ */

const FIRST_NAMES = ["Marco", "Luis", "Kaito", "André", "Nabil", "Viktor", "Dante", "Emile", "Soren", "Rafa", "Javi", "Tomás", "Kenji", "Oumar", "Luka", "Enzo", "Mateo", "Yuri", "Abel", "Dario", "Felix", "Hugo", "Ivan", "Oscar", "Axel", "Bruno", "Carlos", "Diego"];
const LAST_NAMES = ["Ferreira", "Nakamura", "Diallo", "Petrov", "Moreno", "Lindqvist", "Aziz", "Volkov", "Kowalski", "Tanaka", "Mbeki", "Santos", "Reyes", "Johansson", "Okafor", "Silva", "Ribeiro", "Park", "Chen", "Torres", "Ruiz", "Costa", "Mendez", "Herrera", "Alves", "Gomez", "Vargas", "Cruz"];
const NATIONALITIES = ["Brazil", "Japan", "Senegal", "Russia", "Spain", "Sweden", "Morocco", "Poland", "Nigeria", "Portugal", "South Korea", "China", "Mexico", "Argentina", "Colombia", "France", "Germany", "Netherlands", "Belgium", "Chile"];
const DEFAULT_CLUBS = ["FC Novalux", "Stellar United", "Ironforge City", "Phoenix Athletic", "Apex Wanderers", "Vanguard FC", "Eclipse Town", "Obsidian Rangers"];
const OPPONENT_NAMES = ["Thunderstrike FC", "Royal Eagles", "Shadow Wolves", "Iron City", "Golden Lions", "Storm United", "Dark Knights", "Crimson Tide", "Blue Dragons", "Silver Hawks", "Phantom Athletic", "Blaze Town", "Arctic United", "Emerald Rangers", "Fury FC"];
const ALL_POSITIONS = ["GK", "CB", "LB", "RB", "LWB", "RWB", "CDM", "CM", "CAM", "LM", "RM", "LW", "RW", "ST", "CF"];

/* ═══════════════════════════════════════════════════════════════════════
   UTILITIES
   ═══════════════════════════════════════════════════════════════════════ */

function randInt(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }
function pickRandom(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function clampStat(base, spread) { return Math.max(15, Math.min(99, randInt(base - spread, base + spread))); }

/* ═══════════════════════════════════════════════════════════════════════
   POSITION SYSTEM
   ═══════════════════════════════════════════════════════════════════════ */

const POSSIBLE_ALTS = { GK: [], CB: ["CDM", "RB", "LB"], LB: ["LWB", "LM", "CB"], RB: ["RWB", "RM", "CB"], LWB: ["LB", "LM"], RWB: ["RB", "RM"], CDM: ["CM", "CB"], CM: ["CDM", "CAM", "LM", "RM"], CAM: ["CM", "CF", "ST"], LM: ["LW", "CM"], RM: ["RW", "CM"], LW: ["LM", "ST", "RW"], RW: ["RM", "ST", "LW"], ST: ["CF", "LW", "RW", "CAM"], CF: ["ST", "CAM"] };
const YELLOW_PAIRS = new Set(["CB-CDM", "CB-LB", "CB-RB", "LB-LWB", "LB-LM", "LB-CB", "RB-RWB", "RB-RM", "RB-CB", "LWB-LB", "LWB-LM", "RWB-RB", "RWB-RM", "CDM-CM", "CDM-CB", "CM-CDM", "CM-CAM", "CM-LM", "CM-RM", "CAM-CM", "CAM-CF", "CAM-ST", "LM-LW", "LM-CM", "LM-LB", "LM-LWB", "RM-RW", "RM-CM", "RM-RB", "RM-RWB", "LW-LM", "LW-ST", "LW-CAM", "RW-RM", "RW-ST", "RW-CAM", "ST-CF", "ST-CAM", "ST-LW", "ST-RW", "CF-ST", "CF-CAM"]);
const GROUP_INDEX = { GK: 0, CB: 1, LB: 1, RB: 1, LWB: 1, RWB: 1, CDM: 2, CM: 3, LM: 3, RM: 3, CAM: 4, LW: 5, RW: 5, CF: 5, ST: 5 };

function getPositionPenalty(naturalPos, altPositions, slotPos) {
  if (slotPos === naturalPos) return { penalty: 0, status: "natural" };
  if (altPositions.includes(slotPos)) return { penalty: 0, status: "alt" };
  if (YELLOW_PAIRS.has(`${naturalPos}-${slotPos}`)) return { penalty: 2, status: "yellow" };
  if (naturalPos === "GK" || slotPos === "GK") return { penalty: 22, status: "red" };
  const dist = Math.abs((GROUP_INDEX[naturalPos] ?? 3) - (GROUP_INDEX[slotPos] ?? 3));
  return { penalty: Math.min(5 + dist * 4, 25), status: "red" };
}

function getEffectiveOvr(player, slotPos) {
  if (player.injuredFor > 0) return 0; // Injured players can't play
  const { penalty } = getPositionPenalty(player.naturalPosition, player.altPositions || [], slotPos);
  const fitPenalty = getFitnessPenalty(player.fitness ?? 100);
  const roleBonus = getRoleBonus(player);
  return Math.max(1, player.ovr - penalty - fitPenalty + roleBonus);
}

function getSlotStatus(player, slotPos) {
  return getPositionPenalty(player.naturalPosition, player.altPositions || [], slotPos);
}

/* ═══════════════════════════════════════════════════════════════════════
   TIERS & COLORS
   ═══════════════════════════════════════════════════════════════════════ */

function getTier(ovr) { if (ovr >= 90) return "special"; if (ovr >= 75) return "gold"; if (ovr >= 65) return "silver"; return "bronze"; }

const TIER_STYLES = {
  bronze: { bg: "linear-gradient(165deg, #8B5E3C 0%, #CD8B4E 30%, #A0653C 60%, #7A4B2D 100%)", accent: "#CD8B4E", text: "#3D2208", statLabel: "#6B4226", border: "#CD8B4E", shine: "rgba(205,139,78,0.25)", headerBg: "linear-gradient(90deg, #7A4B2D, #CD8B4E, #7A4B2D)" },
  silver: { bg: "linear-gradient(165deg, #8A9BAE 0%, #C8D6E0 30%, #9AACBE 60%, #6E8399 100%)", accent: "#C8D6E0", text: "#2A3540", statLabel: "#4A5E6E", border: "#B0C4D4", shine: "rgba(200,214,224,0.3)", headerBg: "linear-gradient(90deg, #6E8399, #C8D6E0, #6E8399)" },
  gold: { bg: "linear-gradient(165deg, #9B7B2E 0%, #F5D864 30%, #D4A826 60%, #8B6914 100%)", accent: "#F5D864", text: "#3D2E00", statLabel: "#6B5500", border: "#F5D864", shine: "rgba(245,216,100,0.3)", headerBg: "linear-gradient(90deg, #8B6914, #F5D864, #8B6914)" },
  special: { bg: "linear-gradient(165deg, #0a0020 0%, #1a0040 20%, #0d0035 50%, #0a0028 100%)", accent: "#00e5ff", text: "#e0f0ff", statLabel: "#80c0ff", border: "#00e5ff", shine: "rgba(0,229,255,0.15)", headerBg: "linear-gradient(90deg, #ff2ecb, #00e5ff, #ff2ecb)" },
};

const N = { bg: "#0a0e1a", surface: "#111827", card: "#1a2236", border: "#1e2d4a", cyan: "#00e5ff", magenta: "#ff2ecb", gold: "#ffd700", green: "#00ff88", text: "#e2e8f0", muted: "#64748b", pitchLine: "rgba(255,255,255,0.25)" };
function statColor(v) { if (v >= 60) return "#00ffc8"; if (v >= 45) return "#00d4ff"; if (v >= 35) return "#ffa800"; return "#ff4060"; }

const STAT_CATEGORIES = [
  { name: "Pace", color: N.cyan, icon: "⚡", keys: [["Acceleration", "acceleration"], ["Sprint Speed", "sprintSpeed"]] },
  { name: "Shooting", color: N.magenta, icon: "🎯", keys: [["Positioning", "attackPositioning"], ["Finishing", "finishing"], ["Volleys", "volleys"], ["Shot Power", "shotPower"], ["Long Shots", "longShots"], ["Penalties", "penalties"]] },
  { name: "Passing", color: N.green, icon: "📐", keys: [["Vision", "vision"], ["Crossing", "crossing"], ["FK Accuracy", "fkAccuracy"], ["Short Pass", "shortPassing"], ["Long Pass", "longPassing"], ["Curve", "curve"]] },
  { name: "Dribbling", color: N.gold, icon: "✨", keys: [["Agility", "agility"], ["Balance", "balance"], ["Reactions", "reactions"], ["Composure", "composure"], ["Ball Control", "ballControl"], ["Dribbling", "dribbling"]] },
  { name: "Defending", color: "#ff6b6b", icon: "🛡️", keys: [["Interceptions", "interceptions"], ["Heading Acc.", "headingAccuracy"], ["Def. Awareness", "defAwareness"], ["Stand Tackle", "standingTackle"], ["Slide Tackle", "slidingTackle"]] },
  { name: "Physical", color: "#a78bfa", icon: "💪", keys: [["Jumping", "jumping"], ["Stamina", "stamina"], ["Strength", "strength"], ["Aggression", "aggression"]] },
];

/* ═══════════════════════════════════════════════════════════════════════
   PLAYER GENERATION
   ═══════════════════════════════════════════════════════════════════════ */

function generateDetailedStats(ovr, position) {
  const isDef = ["CB", "LB", "RB", "LWB", "RWB", "CDM"].includes(position);
  const isMid = ["CM", "CAM", "LM", "RM"].includes(position);
  const isAtt = ["ST", "LW", "RW", "CF"].includes(position);
  const isWide = ["LB", "RB", "LWB", "RWB", "LM", "RM", "LW", "RW"].includes(position);
  const b = ovr;
  return {
    acceleration: clampStat(b, 10), sprintSpeed: clampStat(b, 10),
    attackPositioning: clampStat(isAtt ? b + 4 : isDef ? b - 8 : b, 10),
    finishing: clampStat(isAtt ? b + 6 : isDef ? b - 10 : b - 2, 12),
    volleys: clampStat(b - 2, 12), shotPower: clampStat(b, 10),
    longShots: clampStat(isMid ? b + 2 : b - 3, 10), penalties: clampStat(b, 12),
    vision: clampStat(isMid ? b + 4 : b - 2, 10),
    crossing: clampStat(isWide ? b + 4 : b - 4, 10),
    fkAccuracy: clampStat(b - 4, 14), shortPassing: clampStat(isMid ? b + 3 : b, 8),
    longPassing: clampStat(isMid || isDef ? b + 2 : b - 3, 10), curve: clampStat(b - 2, 12),
    agility: clampStat(isAtt ? b + 3 : isDef ? b - 4 : b, 10), balance: clampStat(b, 10),
    reactions: clampStat(b + 2, 8), composure: clampStat(b, 10),
    ballControl: clampStat(isAtt || isMid ? b + 3 : b - 4, 8),
    dribbling: clampStat(isAtt ? b + 5 : isDef ? b - 8 : b, 10),
    interceptions: clampStat(isDef ? b + 5 : isAtt ? b - 10 : b - 3, 10),
    headingAccuracy: clampStat(isDef || isAtt ? b + 2 : b - 4, 12),
    defAwareness: clampStat(isDef ? b + 6 : isAtt ? b - 12 : b - 4, 10),
    standingTackle: clampStat(isDef ? b + 5 : isAtt ? b - 12 : b - 3, 10),
    slidingTackle: clampStat(isDef ? b + 4 : isAtt ? b - 14 : b - 5, 10),
    jumping: clampStat(b, 12), stamina: clampStat(b + 2, 8),
    strength: clampStat(isDef ? b + 3 : b - 2, 10), aggression: clampStat(isDef ? b + 2 : b - 2, 12),
  };
}

function computeFaceStats(d) {
  return {
    pac: Math.round((d.acceleration + d.sprintSpeed) / 2),
    sho: Math.round((d.attackPositioning + d.finishing + d.volleys + d.shotPower + d.longShots + d.penalties) / 6),
    pas: Math.round((d.vision + d.crossing + d.fkAccuracy + d.shortPassing + d.longPassing + d.curve) / 6),
    dri: Math.round((d.agility + d.balance + d.reactions + d.composure + d.ballControl + d.dribbling) / 6),
    def: Math.round((d.interceptions + d.headingAccuracy + d.defAwareness + d.standingTackle + d.slidingTackle) / 5),
    phy: Math.round((d.jumping + d.stamina + d.strength + d.aggression) / 4),
  };
}

function generatePlayer(position, ratingRange) {
  const ovr = randInt(ratingRange[0], ratingRange[1]);
  const detailed = generateDetailedStats(ovr, position);
  const faceStats = computeFaceStats(detailed);
  const possibleAlts = POSSIBLE_ALTS[position] || [];
  let altCount = 0;
  const roll = Math.random();
  if (roll > 0.6) altCount = 1;
  if (roll > 0.8 && possibleAlts.length >= 2) altCount = 2;
  const shuffledAlts = [...possibleAlts].sort(() => Math.random() - 0.5);

  const player = {
    id: crypto.randomUUID(),
    firstName: pickRandom(FIRST_NAMES), lastName: pickRandom(LAST_NAMES),
    naturalPosition: position, position: position, ovr: ovr,
    preferredFoot: Math.random() > 0.3 ? "Right" : "Left",
    nationality: pickRandom(NATIONALITIES), age: randInt(17, 34),
    height: randInt(165, 198), weight: randInt(62, 92),
    altPositions: shuffledAlts.slice(0, altCount),
    fitness: 100,
    ...faceStats, detailed: detailed,
  };

  const { role, roleLabel } = assignRole(player);
  player.role = role;
  player.roleLabel = roleLabel;
  player.activeRole = role;
  player.focus = getDefaultFocus(position);
  player.potential = generatePotential(ovr, player.age);

  return player;
}

function generateSquad(formation, ratingRange = [32, 56]) {
  const usedNames = new Set();
  return FORMATIONS[formation].positions.map((pos) => {
    let player;
    do { player = generatePlayer(pos, ratingRange); } while (usedNames.has(player.firstName + player.lastName));
    usedNames.add(player.firstName + player.lastName);
    return player;
  });
}

function generateBench() {
  return ["GK", "CB", "CM", "LW", "ST", "RB", "CDM"].map((pos) => generatePlayer(pos, [30, 50]));
}

/* ═══════════════════════════════════════════════════════════════════════
   SCOUT SYSTEM (replaces Packs)
   ═══════════════════════════════════════════════════════════════════════ */

/* ═══════════════════════════════════════════════════════════════════════
   SELLING PLAYERS
   Clubs bid on what they actually need, and only what they can afford.
   ═══════════════════════════════════════════════════════════════════════ */

// What a player is worth on the open market
function playerMarketValue(player) {
  const ovr = player.ovr;
  const pot = player.potential ?? ovr;
  const age = player.age ?? 25;

  // Ability is the base — value climbs steeply at the top end
  let value = Math.pow(Math.max(1, ovr - 20), 1.85) * 0.34;

  // Unfulfilled potential is worth paying for, but only while they're young
  const potGap = Math.max(0, pot - ovr);
  const youthMultiplier = age <= 20 ? 1.0 : age <= 23 ? 0.7 : age <= 26 ? 0.35 : 0.1;
  value += potGap * 10 * youthMultiplier;

  // Age curve — peak resale value around 24-27
  let ageMod;
  if (age <= 19) ageMod = 1.15;
  else if (age <= 23) ageMod = 1.25;
  else if (age <= 27) ageMod = 1.10;
  else if (age <= 30) ageMod = 0.80;
  else if (age <= 33) ageMod = 0.45;
  else ageMod = 0.22;
  value *= ageMod;

  // Injured players are a gamble
  if (player.injuredFor > 0) value *= 0.72;

  return Math.max(15, Math.round(value));
}

// Does this club actually want this player?
function clubInterest(club, player) {
  // They won't sign someone far below their level
  const gap = player.ovr - club.ovr;
  if (gap < -12) return 0;

  let interest = 0.5;

  // Squad need: how thin are they in this position?
  const inPosition = club.squad.filter((p) =>
    p.naturalPosition === player.naturalPosition ||
    (p.altPositions || []).includes(player.naturalPosition)
  ).length;
  if (inPosition <= 1) interest += 0.35;
  else if (inPosition === 2) interest += 0.15;
  else if (inPosition >= 4) interest -= 0.25;

  // An upgrade on what they have is attractive
  if (gap > 4) interest += 0.3;
  else if (gap > 0) interest += 0.15;
  else if (gap < -6) interest -= 0.25;

  // Ambitious managers chase potential; youth-focused ones chase young players
  const pot = player.potential ?? player.ovr;
  if (club.manager) {
    if (club.manager.management.youth > 14 && player.age <= 22) interest += 0.25;
    if (club.manager.personality.ambition > 15 && pot - player.ovr > 8) interest += 0.15;
    if (club.manager.personality.risk < 8 && player.age > 30) interest -= 0.2;
  }

  return Math.max(0, Math.min(1, interest));
}

// A club's rough transfer budget
function clubBudget(club) {
  return Math.round(Math.pow(club.reputation, 1.7) * 1.1);
}

// Generate incoming offers for a player you've listed
function generateOffers(player, world, playerClubId, askingPrice) {
  const value = playerMarketValue(player);
  const offers = [];

  world.forEach((club) => {
    if (club.id === playerClubId) return;
    const interest = clubInterest(club, player);
    if (interest < 0.45) return;
    if (Math.random() > interest * 0.55) return;

    const budget = clubBudget(club);
    if (budget < value * 0.5) return;

    // Opening bids are deliberately below what they'd actually pay —
    // there has to be room to haggle.
    const wealthFactor = Math.min(1.4, budget / Math.max(1, value * 1.6));
    let bid = value * (0.48 + interest * 0.30) * (0.85 + wealthFactor * 0.25);
    bid *= 0.92 + Math.random() * 0.18;
    bid = Math.min(bid, budget);

    // If you named a price, some clubs will meet it rather than walk away
    if (askingPrice && bid >= askingPrice * 0.8 && bid < askingPrice && budget >= askingPrice) {
      if (Math.random() < interest) bid = askingPrice;
    }

    offers.push({
      id: crypto.randomUUID(),
      clubId: club.id,
      clubName: club.name,
      clubReputation: club.reputation,
      clubDivision: club.division,
      amount: Math.max(10, Math.round(bid)),
      interest: Math.round(interest * 100),
      // Higher-reputation clubs are more likely to walk if you stall
      patience: club.reputation > 70 ? 2 : 3,
    });
  });

  return offers.sort((a, b) => b.amount - a.amount).slice(0, 4);
}

// What a club is ultimately prepared to pay for a player
function clubCeiling(offer, player) {
  const value = playerMarketValue(player);
  const keenness = (offer.interest || 50) / 100;
  const budget = Math.round(Math.pow(offer.clubReputation, 1.7) * 1.1);
  // Very keen, wealthy clubs will go well past the going rate
  const ceiling = value * (0.95 + keenness * 0.55);
  // Always leave at least a little headroom above their opening bid
  return Math.min(Math.max(Math.round(ceiling), Math.round(offer.amount * 1.12)), budget);
}

// The buying club responds to your counter-offer
function evaluateCounter(offer, player, counterAmount, round) {
  const ceiling = clubCeiling(offer, player);

  if (counterAmount <= offer.amount) {
    return { verdict: "accept", amount: counterAmount };
  }
  if (counterAmount <= ceiling) {
    // Within reach — but they'll usually try to shave a little first
    const haggleChance = round === 1 ? 0.55 : round === 2 ? 0.3 : 0;
    if (Math.random() < haggleChance) {
      const midpoint = Math.round((offer.amount + counterAmount) / 2);
      return { verdict: "counter", amount: Math.min(midpoint, ceiling) };
    }
    return { verdict: "accept", amount: counterAmount };
  }
  // Above their ceiling
  const overreach = counterAmount / ceiling;
  if (overreach > 1.55 || round >= 4) {
    return { verdict: "walk", amount: 0 };
  }
  return { verdict: "counter", amount: ceiling };
}

// How the player feels about a move
function playerReactionToSale(player, offer, yourReputation) {
  const step = offer.clubReputation - yourReputation;
  if (step > 15) return { mood: "eager", text: "desperate to make the step up", morale: 0 };
  if (step > 4) return { mood: "keen", text: "keen on the move", morale: -1 };
  if (step > -8) return { mood: "neutral", text: "willing to talk", morale: -2 };
  return { mood: "reluctant", text: "reluctant to drop down", morale: -4 };
}

/* ═══════════════════════════════════════════════════════════════════════
   SCOUTING 2.0
   Scouts are staff with real attributes. They run assignments against the
   actual world — every player on the market is somebody's squad member.
   Reports start vague and sharpen the longer a scout watches a player.
   ═══════════════════════════════════════════════════════════════════════ */

const SCOUT_FIRST_NAMES = ["Diego", "Anna", "Marcus", "Yuki", "Omar", "Elena", "Pierre", "Nia", "Viktor", "Sofia", "Jamal", "Ingrid", "Rui", "Katya", "Samir", "Lena"];
const SCOUT_LAST_NAMES = ["Bianchi", "Novak", "Silva", "Tanaka", "Haddad", "Kovac", "Dubois", "Okonkwo", "Petrov", "Lindberg", "Reyes", "Muller", "Costa", "Volkov", "Nasser", "Bergman"];

const SCOUT_REGIONS = ["Europe", "South America", "Africa", "Asia", "North America", "Oceania"];

const SCOUT_TIERS = [
  { stars: 1, name: "Amateur Scout", hireCost: 150, wage: 3, skill: 6, color: "#cd8b4e", desc: "Raw and inexperienced. Reports are rough." },
  { stars: 2, name: "Regional Scout", hireCost: 400, wage: 6, skill: 9, color: "#c8d6e0", desc: "Reliable in his own patch." },
  { stars: 3, name: "National Scout", hireCost: 900, wage: 12, skill: 13, color: "#f5d864", desc: "Sharp eye, good contacts." },
  { stars: 4, name: "Continental Scout", hireCost: 2000, wage: 20, skill: 16, color: "#00e5ff", desc: "Reads a player quickly and accurately." },
  { stars: 5, name: "World-Class Scout", hireCost: 4500, wage: 35, skill: 19, color: "#ff2ecb", desc: "Sees things nobody else does." },
];

// Roll an attribute on the 1-20 scale around a centre point
function rollAttr(centre, spread) {
  return Math.max(1, Math.min(20, Math.round(centre) + randInt(-spread, spread)));
}

function generateScout(tier) {
  const t = SCOUT_TIERS.find((s) => s.stars === tier) || SCOUT_TIERS[0];
  const s = t.skill;
  const knownRegions = [];
  const regionCount = Math.max(1, Math.min(SCOUT_REGIONS.length, Math.round(tier * 1.2)));
  const shuffled = [...SCOUT_REGIONS].sort(() => Math.random() - 0.5);
  for (let i = 0; i < regionCount; i++) knownRegions.push(shuffled[i]);

  return {
    id: crypto.randomUUID(),
    name: `${pickRandom(SCOUT_FIRST_NAMES)} ${pickRandom(SCOUT_LAST_NAMES)}`,
    stars: tier,
    tierName: t.name,
    wage: t.wage,
    color: t.color,
    // Core attributes (1-20)
    judgingAbility: rollAttr(s, 3),
    judgingPotential: rollAttr(s - 1, 4),
    tacticalKnowledge: rollAttr(s - 2, 4),
    adaptability: rollAttr(s - 1, 4),
    knownRegions,
    assignment: null,   // { type, params, progress, found: [] }
  };
}

// How well a scout knows what he's looking at, for a given player
function scoutAccuracy(scout, player, progress) {
  const regionKnown = scout.knownRegions.includes(playerRegion(player.nationality));
  const base = (scout.judgingAbility / 20) * 0.55 + (scout.adaptability / 20) * 0.15;
  const regionBonus = regionKnown ? 0.18 : 0;
  const progressBonus = Math.min(0.35, (progress || 0) * 0.09);
  return Math.max(0.15, Math.min(0.98, base + regionBonus + progressBonus));
}

function scoutPotentialAccuracy(scout, player, progress) {
  const regionKnown = scout.knownRegions.includes(playerRegion(player.nationality));
  const base = (scout.judgingPotential / 20) * 0.5;
  const regionBonus = regionKnown ? 0.15 : 0;
  const progressBonus = Math.min(0.35, (progress || 0) * 0.10);
  // Young players are harder to read
  const agePenalty = player.age <= 20 ? 0.12 : player.age <= 23 ? 0.06 : 0;
  return Math.max(0.10, Math.min(0.95, base + regionBonus + progressBonus - agePenalty));
}

const NATION_REGION = {
  Brazil: "South America", Argentina: "South America", Colombia: "South America", Chile: "South America",
  Japan: "Asia", "South Korea": "Asia", China: "Asia",
  Senegal: "Africa", Nigeria: "Africa", Morocco: "Africa",
  Russia: "Europe", Spain: "Europe", Sweden: "Europe", Poland: "Europe", Portugal: "Europe",
  France: "Europe", Germany: "Europe", Netherlands: "Europe", Belgium: "Europe",
  Mexico: "North America",
};
function playerRegion(nationality) {
  return NATION_REGION[nationality] || "Europe";
}

// Turn a true value into a scouted range — the less accurate, the wider the band
function fuzzRange(trueValue, accuracy) {
  const band = Math.round((1 - accuracy) * 22);
  if (band <= 1) return { exact: true, value: trueValue, lo: trueValue, hi: trueValue };
  const centreShift = randInt(-Math.ceil(band / 2), Math.ceil(band / 2));
  const lo = Math.max(1, Math.min(99, trueValue + centreShift - band));
  const hi = Math.max(1, Math.min(99, trueValue + centreShift + band));
  return { exact: false, value: null, lo, hi };
}

function starsFromRange(lo, hi) {
  const mid = (lo + hi) / 2;
  return Math.max(0.5, Math.min(5, Math.round((mid / 20) * 2) / 2));
}

// Build the report a given scout would write about a given player
function buildScoutReport(scout, player, progress) {
  const abilityAcc = scoutAccuracy(scout, player, progress);
  const potentialAcc = scoutPotentialAccuracy(scout, player, progress);
  const ability = fuzzRange(player.ovr, abilityAcc);
  const potential = fuzzRange(player.potential ?? player.ovr, potentialAcc);

  // Tactical knowledge decides whether the scout can judge the player's best role
  const roleConfident = scout.tacticalKnowledge >= 12 || (progress || 0) >= 3;

  return {
    scoutId: scout.id,
    scoutName: scout.name,
    progress: progress || 0,
    abilityAcc, potentialAcc,
    ability, potential,
    abilityStars: starsFromRange(ability.lo, ability.hi),
    potentialStars: starsFromRange(potential.lo, potential.hi),
    role: roleConfident ? player.role : null,
    confidence: progress >= 4 ? "Complete" : progress >= 2 ? "Good" : progress >= 1 ? "Basic" : "Initial",
  };
}

/* ── Scout assignments ── */

const ASSIGNMENT_TYPES = [
  {
    id: "region", label: "Scout a region", icon: "🌍",
    describe: (p) => `Scouting ${p.region}`,
    match: (player, p) => playerRegion(player.nationality) === p.region,
  },
  {
    id: "position", label: "Find a position", icon: "🎯",
    describe: (p) => `Looking for ${p.position}s`,
    match: (player, p) => player.naturalPosition === p.position || (player.altPositions || []).includes(p.position),
  },
  {
    id: "youth", label: "Find young talent", icon: "🌱",
    describe: (p) => `Hunting U${p.maxAge} prospects`,
    match: (player, p) => player.age <= p.maxAge,
  },
  {
    id: "attribute", label: "Find an attribute", icon: "⚡",
    describe: (p) => `Seeking ${p.attrLabel} ${p.min}+`,
    match: (player, p) => (player.detailed?.[p.attr] ?? 0) >= p.min,
  },
];

const ASSIGNMENT_ATTRS = [
  { attr: "sprintSpeed", label: "Pace" },
  { attr: "finishing", label: "Finishing" },
  { attr: "vision", label: "Vision" },
  { attr: "defAwareness", label: "Defending" },
  { attr: "strength", label: "Strength" },
  { attr: "dribbling", label: "Dribbling" },
];

// Run one scouting cycle for a scout — called after each match
function advanceScouting(scout, candidatePool) {
  if (!scout.assignment) return scout;
  const a = scout.assignment;
  const typeDef = ASSIGNMENT_TYPES.find((t) => t.id === a.type);
  if (!typeDef) return scout;

  const found = [...(a.found || [])];
  // Deepen knowledge of players already being watched
  found.forEach((f) => { f.progress = Math.min(5, f.progress + 1); });

  // Scouts with better adaptability work faster and cover more ground
  const workRate = 1 + Math.floor(scout.adaptability / 8);
  const matches = candidatePool.filter((p) =>
    typeDef.match(p, a.params) && !found.some((f) => f.playerId === p.id)
  );

  for (let i = 0; i < workRate && matches.length > 0; i++) {
    // Better judges find better players; weaker scouts turn up more duds
    const skillPull = scout.judgingAbility / 20;
    const sorted = [...matches].sort((x, y) =>
      (y.ovr * skillPull + Math.random() * 40 * (1 - skillPull)) -
      (x.ovr * skillPull + Math.random() * 40 * (1 - skillPull))
    );
    const pick = sorted[0];
    if (!pick) break;
    matches.splice(matches.indexOf(pick), 1);
    found.push({ playerId: pick.id, progress: 0 });
  }

  return { ...scout, assignment: { ...a, cycles: (a.cycles || 0) + 1, found: found.slice(0, 30) } };
}


/* ═══════════════════════════════════════════════════════════════════════
   TRANSFER MARKET — Search pool, negotiation, pending signings
   ═══════════════════════════════════════════════════════════════════════ */

const WORLD_PLAYER_COUNT = 300;



// Generate the entire world of players once — persistent database
// Every player on the market is somebody's squad member.
// This builds the transfer pool from the actual clubs in the world.
function buildTransferPool(world, playerClubId) {
  const pool = [];
  world.forEach((club) => {
    if (club.id === playerClubId) return;
    // Bigger clubs guard their best players; smaller clubs will sell anyone
    const openness = 1 - (club.reputation / 160);
    club.squad.forEach((p, idx) => {
      // Squad players are more available than key starters
      const depthFactor = idx >= 11 ? 1.25 : 1.0;
      if (Math.random() < openness * depthFactor) {
        pool.push({ ...p, currentClub: club.name, clubId: club.id, clubReputation: club.reputation });
      }
    });
  });
  return pool;
}

// Agent's demands scale with player quality and potential
function getAgentDemands(player, prestige) {
  const base = getPlayerSalary(player);
  const potGap = Math.max(0, (player.potential || player.ovr) - player.ovr);
  const greed = 1 + (player.ovr - 40) / 100 + potGap / 60;
  const prestigeDiscount = Math.max(0.75, 1 - prestige / 250);

  const salary = Math.max(2, Math.round(base * greed * 1.35 * prestigeDiscount));
  const clause = Math.max(50, Math.round(player.ovr * 18 * greed * prestigeDiscount));
  const signingFee = Math.max(20, Math.round(player.ovr * 6 * greed * prestigeDiscount));

  return { salary, clause, signingFee };
}

// Evaluate an offer. Returns "accept" | "reject"
function evaluateOffer(demands, offer, prestige) {
  const salaryRatio = offer.salary / demands.salary;
  const clauseRatio = offer.clause / demands.clause;
  const prestigeBoost = prestige / 400;

  const score = salaryRatio * 0.65 + clauseRatio * 0.35 + prestigeBoost;

  if (score >= 0.97) return "accept";
  return "reject";
}

/* ═══════════════════════════════════════════════════════════════════════
   POTENTIAL & AGE PROGRESSION
   Players have a potential ceiling. Young players grow, old ones decline.
   ═══════════════════════════════════════════════════════════════════════ */

function generatePotential(ovr, age) {
  if (age <= 20) return Math.min(99, ovr + randInt(5, 20));
  if (age <= 24) return Math.min(99, ovr + randInt(2, 12));
  if (age <= 29) return Math.min(99, ovr + randInt(0, 4));
  return Math.max(ovr - randInt(0, 3), 30);
}

function progressPlayerAge(player) {
  const p = { ...player };
  p.age += 1;

  if (p.age <= 23 && p.ovr < (p.potential || p.ovr)) {
    // Young player: grow toward potential
    const growth = randInt(1, 3);
    p.ovr = Math.min(p.potential || p.ovr, p.ovr + growth);
  } else if (p.age >= 24 && p.age <= 29) {
    // Prime: small chance to grow if below potential
    if (p.ovr < (p.potential || p.ovr) && Math.random() < 0.4) {
      p.ovr = Math.min(p.potential || p.ovr, p.ovr + 1);
    }
  } else if (p.age >= 30 && p.age <= 33) {
    // Aging: gradual decline
    p.ovr = Math.max(30, p.ovr - randInt(1, 2));
    p.potential = Math.max(p.ovr, (p.potential || p.ovr) - 1);
  } else if (p.age >= 34) {
    // Old: faster decline
    p.ovr = Math.max(25, p.ovr - randInt(2, 4));
    p.potential = Math.max(p.ovr, (p.potential || p.ovr) - 2);
  }

  // Regenerate detailed stats for new OVR
  p.detailed = generateDetailedStats(p.ovr, p.naturalPosition);
  const face = computeFaceStats(p.detailed);
  Object.assign(p, face);

  return p;
}

function getPotentialLabel(ovr, potential) {
  const diff = (potential || ovr) - ovr;
  if (diff >= 15) return { label: "Exceptional", color: "#ff2ecb", icon: "🌟" };
  if (diff >= 8) return { label: "Exciting", color: "#ffd700", icon: "📈" };
  if (diff >= 3) return { label: "Promising", color: "#00ff88", icon: "📊" };
  if (diff >= 0) return { label: "At Peak", color: "#00d4ff", icon: "⏸️" };
  return { label: "Declining", color: "#ff4060", icon: "📉" };
}

const REST_COST = 40; // Cost to run a recovery session

/* ═══════════════════════════════════════════════════════════════════════
   RANDOM EVENTS SYSTEM
   Events trigger randomly between matches.
   Each has a positive or negative effect on your squad.
   ═══════════════════════════════════════════════════════════════════════ */

const RANDOM_EVENTS = [
  // ── Negative Events ──
  {
    type: "negative", icon: "🏥", title: "Training Injury",
    needsPlayer: true, targetFilter: null,
    getText: (p) => `${p.firstName} ${p.lastName} got injured during a training drill! Will miss the next 2 matches.`,
    apply: (state, player) => {
      const newSquad = state.squad.map((p) => p.id === player.id ? { ...p, injuredFor: 2, fitness: 0 } : p);
      const newBench = state.bench.map((p) => p.id === player.id ? { ...p, injuredFor: 2, fitness: 0 } : p);
      return { ...state, squad: newSquad, bench: newBench };
    },
  },
  {
    type: "negative", icon: "🏥", title: "Serious Injury",
    needsPlayer: true, targetFilter: null,
    getText: (p) => `${p.firstName} ${p.lastName} suffered a serious injury and will be out for 4 matches!`,
    apply: (state, player) => {
      const newSquad = state.squad.map((p) => p.id === player.id ? { ...p, injuredFor: 4, fitness: 0 } : p);
      const newBench = state.bench.map((p) => p.id === player.id ? { ...p, injuredFor: 4, fitness: 0 } : p);
      return { ...state, squad: newSquad, bench: newBench };
    },
  },
  {
    type: "negative", icon: "👋", title: "Player Departure",
    needsPlayer: true, targetFilter: (p) => p.ovr <= 55,
    getText: (p) => `${p.firstName} ${p.lastName} has left your squad citing lack of game time!`,
    apply: (state, player) => {
      const newSquad = state.squad.filter((p) => p.id !== player.id);
      const newBench = state.bench.filter((p) => p.id !== player.id);
      // If removed from starting XI, generate a replacement
      if (newSquad.length < 11) {
        newSquad.push(generatePlayer(player.naturalPosition, [25, 40]));
      }
      return { ...state, squad: newSquad, bench: newBench };
    },
  },
  {
    type: "negative", icon: "🎆", title: "Firework Fiasco",
    needsPlayer: false,
    getText: () => "A firework show at the team hotel kept everyone up all night! The whole squad is exhausted.",
    apply: (state) => ({
      ...state,
      squad: state.squad.map((p) => ({ ...p, fitness: Math.max(0, (p.fitness ?? 100) - 20) })),
      bench: state.bench.map((p) => ({ ...p, fitness: Math.max(0, (p.fitness ?? 100) - 15) })),
    }),
  },
  {
    type: "negative", icon: "🤢", title: "Food Poisoning",
    needsPlayer: false,
    getText: () => "Bad catering after the match! Half the squad is feeling terrible. Fitness dropped for everyone.",
    apply: (state) => ({
      ...state,
      squad: state.squad.map((p) => ({ ...p, fitness: Math.max(0, (p.fitness ?? 100) - 18) })),
    }),
  },
  {
    type: "negative", icon: "🚌", title: "Bus Breakdown",
    needsPlayer: false,
    getText: () => "The team bus broke down 10km from the stadium. Players had to jog the rest of the way!",
    apply: (state) => ({
      ...state,
      squad: state.squad.map((p) => ({ ...p, fitness: Math.max(0, (p.fitness ?? 100) - 12) })),
    }),
  },
  {
    type: "negative", icon: "🌧️", title: "Flooded Training Pitch",
    needsPlayer: false,
    getText: () => "Heavy rain flooded the training pitch. No training this week — players lost sharpness.",
    apply: (state) => ({
      ...state,
      squad: state.squad.map((p) => ({ ...p, fitness: Math.max(0, (p.fitness ?? 100) - 8) })),
      bench: state.bench.map((p) => ({ ...p, fitness: Math.max(0, (p.fitness ?? 100) - 8) })),
    }),
  },

  // ── Positive Events ──
  {
    type: "positive", icon: "💰", title: "Sponsor Deal",
    needsPlayer: false,
    getText: () => "A new sponsor signed a deal with your club! Cash bonus incoming!",
    apply: (state) => ({ ...state, money: state.money + 200 }),
  },
  {
    type: "positive", icon: "🏕️", title: "Recovery Camp",
    needsPlayer: false,
    getText: () => "The team went on a wellness retreat! All players recovered significant fitness.",
    apply: (state) => ({
      ...state,
      squad: state.squad.map((p) => ({ ...p, fitness: Math.min(100, (p.fitness ?? 100) + 35) })),
      bench: state.bench.map((p) => ({ ...p, fitness: Math.min(100, (p.fitness ?? 100) + 35) })),
    }),
  },
  {
    type: "positive", icon: "🌟", title: "Youth Academy Graduate",
    needsPlayer: false,
    getText: (p) => `${p.firstName} ${p.lastName} (${p.naturalPosition}, OVR ${p.ovr}) graduated from your youth academy!`,
    apply: (state, player) => ({ ...state, bench: [...state.bench, player] }),
    generatePlayer: true,
    playerRange: [50, 72],
  },
  {
    type: "positive", icon: "📈", title: "Player Breakthrough",
    needsPlayer: true, targetFilter: (p) => !p.injuredFor,
    getText: (p) => `${p.firstName} ${p.lastName} had an incredible training week! Permanent +3 OVR boost!`,
    apply: (state, player) => {
      const boost = (p) => {
        if (p.id !== player.id) return p;
        const newOvr = p.ovr + 3;
        const newDetailed = generateDetailedStats(newOvr, p.naturalPosition);
        const newFace = computeFaceStats(newDetailed);
        return { ...p, ovr: newOvr, detailed: newDetailed, ...newFace };
      };
      return { ...state, squad: state.squad.map(boost), bench: state.bench.map(boost) };
    },
  },
  {
    type: "positive", icon: "🎉", title: "Fan Fundraiser",
    needsPlayer: false,
    getText: () => "The supporters organized a fundraiser for the club! Every dollar counts!",
    apply: (state) => ({ ...state, money: state.money + 120 }),
  },
  {
    type: "positive", icon: "💪", title: "Fitness Guru Visit",
    needsPlayer: false,
    getText: () => "A world-class fitness coach visited! Your starting XI is fully recharged!",
    apply: (state) => ({
      ...state,
      squad: state.squad.map((p) => ({ ...p, fitness: 100 })),
    }),
  },
  {
    type: "positive", icon: "🎁", title: "Mystery Benefactor",
    needsPlayer: false,
    getText: () => "An anonymous benefactor donated a large sum to the club!",
    apply: (state) => ({ ...state, money: state.money + 300 }),
  },

  // ── Additional Negative Events ──
  {
    type: "negative", icon: "💥", title: "Dressing Room Argument",
    needsPlayer: false,
    getText: () => "Two of your players had a huge shouting match in the changing room! The whole squad feels the tension.",
    apply: (state) => ({ ...state, morale: Math.max(0, (state.morale ?? 60) - 10) }),
  },
  {
    type: "negative", icon: "📰", title: "Bad Press",
    needsPlayer: false,
    getText: () => "The local paper wrote a scathing article calling your team 'a mess'. Morale took a knock.",
    apply: (state) => ({ ...state, morale: Math.max(0, (state.morale ?? 60) - 8) }),
  },
  {
    type: "negative", icon: "🤕", title: "Minor Knock",
    needsPlayer: true, targetFilter: (p) => !p.injuredFor,
    getText: (p) => `${p.firstName} ${p.lastName} picked up a minor knock in training and will miss one match.`,
    apply: (state, player) => ({
      ...state,
      squad: state.squad.map((p) => p.id === player.id ? { ...p, injuredFor: 1, fitness: Math.max(0, (p.fitness ?? 100) - 30) } : p),
      bench: state.bench.map((p) => p.id === player.id ? { ...p, injuredFor: 1, fitness: Math.max(0, (p.fitness ?? 100) - 30) } : p),
    }),
  },
  {
    type: "negative", icon: "🗞️", title: "Contract Rebel",
    needsPlayer: true, targetFilter: (p) => p.ovr >= 65,
    getText: (p) => `${p.firstName} ${p.lastName} demanded a bigger paycheck in a public interview! The squad feels awkward.`,
    apply: (state) => ({ ...state, morale: Math.max(0, (state.morale ?? 60) - 6) }),
  },
  {
    type: "negative", icon: "🌨️", title: "Freak Weather",
    needsPlayer: false,
    getText: () => "A brutal cold snap hit town! A few players caught a bug and their fitness dropped.",
    apply: (state) => {
      const pickIds = [...state.squad, ...state.bench].sort(() => Math.random() - 0.5).slice(0, 3).map((p) => p.id);
      return {
        ...state,
        squad: state.squad.map((p) => pickIds.includes(p.id) ? { ...p, fitness: Math.max(0, (p.fitness ?? 100) - 22) } : p),
        bench: state.bench.map((p) => pickIds.includes(p.id) ? { ...p, fitness: Math.max(0, (p.fitness ?? 100) - 22) } : p),
      };
    },
  },

  // ── Additional Positive Events ──
  {
    type: "positive", icon: "🎳", title: "Team Bonding Trip",
    needsPlayer: false,
    getText: () => "You took the squad bowling! Everyone had a blast — morale is soaring.",
    apply: (state) => ({ ...state, morale: Math.min(100, (state.morale ?? 60) + 12) }),
  },
  {
    type: "positive", icon: "🎥", title: "Documentary Deal",
    needsPlayer: false,
    getText: () => "A streaming service wants to film a documentary about your club! Nice signing bonus and a morale bump.",
    apply: (state) => ({ ...state, money: state.money + 180, morale: Math.min(100, (state.morale ?? 60) + 5) }),
  },
  {
    type: "positive", icon: "🏟️", title: "Sold-Out Stadium",
    needsPlayer: false,
    getText: () => "Every single seat sold for the next home match! The fans are ready to bring the noise.",
    apply: (state) => ({ ...state, money: state.money + 90, morale: Math.min(100, (state.morale ?? 60) + 6) }),
  },
  {
    type: "positive", icon: "🎵", title: "New Fan Chant",
    needsPlayer: false,
    getText: () => "The ultras invented a brand new chant for your team. The players adore it — morale is up!",
    apply: (state) => ({ ...state, morale: Math.min(100, (state.morale ?? 60) + 8) }),
  },
  {
    type: "positive", icon: "🕵️", title: "Free Agent Discovery",
    needsPlayer: false,
    getText: (p) => `Your scouts spotted ${p.firstName} ${p.lastName} (${p.naturalPosition}, OVR ${p.ovr}) at a pickup match. Signed for free!`,
    apply: (state, player) => ({ ...state, bench: [...state.bench, player] }),
    generatePlayer: true,
    playerRange: [55, 70],
  },
  {
    type: "positive", icon: "🏆", title: "Player of the Month",
    needsPlayer: true, targetFilter: (p) => !p.injuredFor && p.ovr >= 55,
    getText: (p) => `${p.firstName} ${p.lastName} won Player of the Month! Permanent +2 OVR boost and the whole squad is buzzing.`,
    apply: (state, player) => {
      const boost = (p) => {
        if (p.id !== player.id) return p;
        const newOvr = Math.min(99, p.ovr + 2);
        const newDetailed = generateDetailedStats(newOvr, p.naturalPosition);
        const newFace = computeFaceStats(newDetailed);
        return { ...p, ovr: newOvr, detailed: newDetailed, ...newFace };
      };
      return {
        ...state,
        squad: state.squad.map(boost),
        bench: state.bench.map(boost),
        morale: Math.min(100, (state.morale ?? 60) + 8),
      };
    },
  },
];

function pickRandomEvent(squad, bench) {
  // 50% chance of an event happening
  if (Math.random() > 0.5) return null;

  const event = pickRandom(RANDOM_EVENTS);
  let targetPlayer = null;

  if (event.needsPlayer) {
    const allPlayers = [...squad, ...bench];
    const eligible = event.targetFilter ? allPlayers.filter(event.targetFilter) : allPlayers;
    if (eligible.length === 0) return null;
    targetPlayer = pickRandom(eligible);
  }

  if (event.generatePlayer) {
    targetPlayer = generatePlayer(pickRandom(ALL_POSITIONS), event.playerRange);
  }

  return { event, targetPlayer };
}

/* ═══════════════════════════════════════════════════════════════════════
   TRAINING SYSTEM
   Upgradeable training facilities that affect recovery and performance.
   ═══════════════════════════════════════════════════════════════════════ */

const TRAINING_LEVELS = [
  { name: "Basic", benchRecovery: 10, matchBonus: 0, moraleBoost: 0, cost: 0, color: N.muted },
  { name: "Standard", benchRecovery: 18, matchBonus: 1, moraleBoost: 2, cost: 200, color: "#00d4ff" },
  { name: "Advanced", benchRecovery: 28, matchBonus: 2, moraleBoost: 4, cost: 450, color: N.gold },
  { name: "Elite", benchRecovery: 40, matchBonus: 3, moraleBoost: 6, cost: 800, color: N.green },
];

/* ═══════════════════════════════════════════════════════════════════════
   SALARY SYSTEM
   Each player has a salary based on OVR. Total paid per match.
   ═══════════════════════════════════════════════════════════════════════ */

function getPlayerSalary(player) {
  // Low-rated players cost pennies, elite players cost serious money
  return Math.max(1, Math.round(player.ovr * 0.08));
}

function getTotalSalary(squad) {
  return squad.reduce((sum, p) => sum + getPlayerSalary(p), 0);
}

/* ═══════════════════════════════════════════════════════════════════════
   MORALE SYSTEM
   Morale (0-100) affects match performance and player happiness.
   ═══════════════════════════════════════════════════════════════════════ */

function getMoraleLabel(morale) {
  if (morale >= 85) return "Ecstatic";
  if (morale >= 70) return "Happy";
  if (morale >= 50) return "Content";
  if (morale >= 30) return "Unhappy";
  if (morale >= 15) return "Frustrated";
  return "Furious";
}

function getMoraleColor(morale) {
  if (morale >= 70) return N.green;
  if (morale >= 50) return "#00d4ff";
  if (morale >= 30) return N.gold;
  return "#ff4060";
}

function getMoraleMatchBonus(morale) {
  if (morale >= 85) return 3;
  if (morale >= 70) return 1;
  if (morale >= 50) return 0;
  if (morale >= 30) return -2;
  if (morale >= 15) return -5;
  return -10;
}

// Morale events that trigger based on conditions
function checkMoraleEvents(morale, chemistry, canAffordSalary, squad, bench) {
  const events = [];

  // Low morale → player wants to leave
  if (morale < 30 && Math.random() < 0.4) {
    const unhappy = pickRandom(squad.filter((p) => !p.injuredFor));
    if (unhappy) {
      events.push({
        event: {
          type: "negative", icon: "😤", title: "Player Unhappy",
          needsPlayer: false,
          getText: () => `${unhappy.firstName} ${unhappy.lastName} is fed up with the team morale and is demanding a transfer!`,
          apply: (state) => {
            const ns = state.squad.filter((p) => p.id !== unhappy.id);
            if (ns.length < 11) ns.push(generatePlayer(unhappy.naturalPosition, [25, 40]));
            return { ...state, squad: ns };
          },
        },
        targetPlayer: unhappy,
      });
    }
  }

  // Bad chemistry → player wants to leave
  if (chemistry < 30 && Math.random() < 0.3) {
    const lonely = pickRandom(squad);
    if (lonely) {
      events.push({
        event: {
          type: "negative", icon: "💔", title: "Chemistry Crisis",
          needsPlayer: false,
          getText: () => `${lonely.firstName} ${lonely.lastName} feels isolated due to poor team chemistry and wants out!`,
          apply: (state) => {
            const ns = state.squad.filter((p) => p.id !== lonely.id);
            if (ns.length < 11) ns.push(generatePlayer(lonely.naturalPosition, [25, 40]));
            return { ...state, squad: ns };
          },
        },
        targetPlayer: lonely,
      });
    }
  }

  // Can't afford salary → player leaves
  if (!canAffordSalary && Math.random() < 0.5) {
    const expensive = [...squad].sort((a, b) => b.ovr - a.ovr)[0];
    if (expensive) {
      events.push({
        event: {
          type: "negative", icon: "💸", title: "Salary Dispute",
          needsPlayer: false,
          getText: () => `${expensive.firstName} ${expensive.lastName} hasn't been paid and is leaving the club!`,
          apply: (state) => {
            const ns = state.squad.filter((p) => p.id !== expensive.id);
            if (ns.length < 11) ns.push(generatePlayer(expensive.naturalPosition, [25, 40]));
            return { ...state, squad: ns };
          },
        },
        targetPlayer: expensive,
      });
    }
  }

  return events.length > 0 ? events[0] : null;
}

/* ═══════════════════════════════════════════════════════════════════════
   SIMPLE BAR CHART COMPONENT
   ═══════════════════════════════════════════════════════════════════════ */

function BarChart({ items }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      {items.map((item) => (
        <div key={item.label}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 3 }}>
            <span style={{ fontSize: 11, color: N.muted, fontWeight: 600 }}>{item.label}</span>
            <span style={{ fontSize: 11, fontWeight: 800, color: item.color || N.text }}>{item.valueLabel || item.value}</span>
          </div>
          <div style={{ width: "100%", height: 8, background: "#1a2236", borderRadius: 4, overflow: "hidden" }}>
            <div style={{
              width: `${Math.min(100, (item.value / item.max) * 100)}%`,
              height: "100%",
              background: item.color || N.cyan,
              borderRadius: 4,
              transition: "width 0.4s ease",
            }} />
          </div>
        </div>
      ))}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════
   LEAGUE SYSTEM — Divisions, Promotion, Relegation
   ═══════════════════════════════════════════════════════════════════════ */

const LEAGUE_DIVISIONS = [
  { tier: 4, name: "Division 4", ovrRange: [25, 44], reward: 80, color: "#cd8b4e", icon: "🥉" },
  { tier: 3, name: "Division 3", ovrRange: [38, 56], reward: 120, color: "#c8d6e0", icon: "🥈" },
  { tier: 2, name: "Division 2", ovrRange: [50, 68], reward: 180, color: "#f5d864", icon: "🥇" },
  { tier: 1, name: "Division 1", ovrRange: [64, 84], reward: 280, color: "#00e5ff", icon: "👑" },
];

const LEAGUE_TEAM_NAMES = [
  "Thunderstrike FC", "Royal Eagles", "Shadow Wolves", "Iron City", "Golden Lions",
  "Storm United", "Dark Knights", "Crimson Tide", "Blue Dragons", "Silver Hawks",
  "Phantom Athletic", "Blaze Town", "Arctic United", "Emerald Rangers", "Fury FC",
  "Neon Rovers", "Granite City", "Sapphire Town", "Volcanic FC", "Frost United",
  "Copper Athletic", "Jade Wanderers", "Onyx Rangers", "Amber Town", "Cobalt City",
];

const DIFFICULTY_COLORS = { easy: N.green, medium: N.gold, hard: "#ff6b6b", extreme: N.magenta };
const DIFFICULTY_LABELS = { easy: "Easy", medium: "Medium", hard: "Hard", extreme: "Extreme" };

function getDivision(tier) {
  return LEAGUE_DIVISIONS.find((d) => d.tier === tier) || LEAGUE_DIVISIONS[0];
}

// Build a season from the real clubs in your division.
// Every club plays every other club once — a genuine round-robin.
function generateLeagueSeason(world, playerClubId, divisionTier) {
  const clubs = world.filter((c) => c.division === divisionTier);
  const ids = clubs.map((c) => c.id);
  const rounds = roundRobin(ids);

  // Your fixtures, in matchday order
  const matches = [];
  const otherFixtures = [];

  rounds.forEach((round, rIdx) => {
    const yourFix = round.find((f) => f.home === playerClubId || f.away === playerClubId);
    const rest = round.filter((f) => f.home !== playerClubId && f.away !== playerClubId);
    otherFixtures.push(rest);

    if (yourFix) {
      const oppId = yourFix.home === playerClubId ? yourFix.away : yourFix.home;
      const opp = clubs.find((c) => c.id === oppId);
      if (!opp) return;
      const oppOvr = clubOvr(opp);
      const diff = oppOvr >= 68 ? "extreme" : oppOvr >= 55 ? "hard" : oppOvr >= 42 ? "medium" : "easy";
      const div = getDivision(divisionTier);
      matches.push({
        id: matches.length,
        matchDay: rIdx + 1,
        opponentId: opp.id,
        opponent: opp.name,
        isHome: yourFix.home === playerClubId,
        difficulty: diff,
        formation: opp.formation,
        oppSquad: opp.squad,
        oppOvr,
        oppManager: opp.manager,
        reward: div.reward + Math.round((opp.reputation - 40) * 1.5),
        result: null,
      });
    }
  });

  const table = clubs.map((c) => blankRow({ ...c, isPlayer: c.id === playerClubId }));
  return { matches, table, otherFixtures, divisionTier };
}

// Simulate other teams' results for one match day
// Play the other real fixtures for a given matchday and update the table
function playOtherFixtures(world, season, matchDayIndex, table) {
  const fixtures = season.otherFixtures?.[matchDayIndex] || [];
  const updated = table.map((r) => ({ ...r, form: [...r.form] }));
  const results = [];

  fixtures.forEach((f) => {
    const home = world.find((c) => c.id === f.home);
    const away = world.find((c) => c.id === f.away);
    if (!home || !away) return;
    const r = quickSimulate(home, away);
    applyResult(updated, f.home, f.away, r.homeGoals, r.awayGoals);
    results.push({ home: home.name, away: away.name, hg: r.homeGoals, ag: r.awayGoals });
  });

  return { table: updated, results };
}

function getLeaguePosition(table) {
  if (!table || table.length === 0) return 5;
  const sorted = [...table].sort((a, b) => b.points - a.points || (b.gf - b.ga) - (a.gf - a.ga) || b.gf - a.gf);
  const idx = sorted.findIndex((t) => t.isYou);
  return idx >= 0 ? idx + 1 : 5;
}

function getPromotionStatus(position, totalTeams, currentTier) {
  if (position <= 3 && currentTier > 1) return "promoted";
  if (position <= 3 && currentTier === 1) return "champions";
  if (position > totalTeams - 3 && currentTier < 4) return "relegated";
  if (position > totalTeams - 3 && currentTier === 4) return "fired";
  return "safe";
}

/* ═══════════════════════════════════════════════════════════════════════
   CLUB LEAGUE (Champions League style knockout tournament)
   Triggers every 3 seasons. QF → SF → Final. Lose = eliminated.
/* ═══════════════════════════════════════════════════════════════════════
   COMPETITIONS — built from the real club database
   Qualification → Draw → Groups (everyone plays everyone) → Knockout
   ═══════════════════════════════════════════════════════════════════════ */

const COMPETITION_DEFS = {
  national_cup: {
    title: "National Cup", icon: "🥈", color: "#c8d6e0",
    format: "knockout", entrants: 8, minDivision: 4,
    rounds: [
      { name: "Quarter-Final", short: "QF", reward: 200, consolation: 70 },
      { name: "Semi-Final", short: "SF", reward: 350, consolation: 120 },
      { name: "🏆 Cup Final", short: "F", reward: 800, consolation: 250 },
    ],
  },
  club_league: {
    title: "Club League", icon: "🏆", color: "#ffd700",
    format: "group_knockout", entrants: 16, minDivision: 2,
    groupSize: 4,
    groupReward: 180, groupConsolation: 60,
    rounds: [
      { name: "Quarter-Final", short: "QF", reward: 500, consolation: 200 },
      { name: "Semi-Final", short: "SF", reward: 900, consolation: 400 },
      { name: "🏆 Grand Final", short: "F", reward: 2500, consolation: 800 },
    ],
  },
  world_championship: {
    title: "World Club Championship", icon: "🌍", color: "#00e5ff",
    format: "group_knockout", entrants: 16, minDivision: 1,
    groupSize: 4,
    groupReward: 300, groupConsolation: 100,
    rounds: [
      { name: "Quarter-Final", short: "QF", reward: 900, consolation: 350 },
      { name: "Semi-Final", short: "SF", reward: 1500, consolation: 600 },
      { name: "🌍 World Final", short: "WF", reward: 5000, consolation: 1500 },
    ],
  },
};

function getSeasonCompetition(seasonNum) {
  if (seasonNum % 5 === 0) return "world_championship";
  if (seasonNum % 3 === 0) return "club_league";
  return "national_cup";
}

// Which clubs earned a place? Reputation and division decide, and you
// always get in so the player never sits a competition out.
function qualifyClubs(world, playerClubId, compKey) {
  const def = COMPETITION_DEFS[compKey];
  const you = world.find((c) => c.id === playerClubId);
  const strength = (c) => c.reputation + clubOvr(c);
  const others = world.filter((c) => c.id !== playerClubId);

  // Clubs from the qualifying divisions go in first, strongest first. If they
  // can't fill the draw on their own (Division 1 has only ten clubs, the
  // World Club Championship needs sixteen) the best of the rest are invited,
  // so the field is always the full size and every group is complete.
  const primary = others.filter((c) => c.division <= def.minDivision).sort((a, b) => strength(b) - strength(a));
  const reserve = others.filter((c) => c.division > def.minDivision).sort((a, b) => strength(b) - strength(a));
  const field = [...primary, ...reserve].slice(0, def.entrants - 1);
  if (you) field.push(you);

  // Shuffle so the draw isn't seeded by strength alone
  return field.sort(() => Math.random() - 0.5);
}

// Straight knockout bracket from a shuffled field
function drawKnockout(field, def, playerClubId) {
  const rounds = [];
  let alive = [...field];
  let roundIdx = 0;

  while (alive.length > 1 && roundIdx < def.rounds.length) {
    const info = def.rounds[roundIdx];
    const ties = [];
    for (let i = 0; i < alive.length; i += 2) {
      if (alive[i + 1]) ties.push({ homeId: alive[i].id, awayId: alive[i + 1].id });
    }
    rounds.push({ ...info, ties, results: [] });
    // Provisional winners get filled in as the competition is played
    alive = alive.filter((_, i) => i % 2 === 0);
    roundIdx++;
  }
  return rounds;
}

function generateCompetition(world, playerClubId, seasonNum) {
  const compKey = getSeasonCompetition(seasonNum);
  const def = COMPETITION_DEFS[compKey];
  const field = qualifyClubs(world, playerClubId, compKey);

  if (def.format === "knockout") {
    const bracket = drawKnockout(field, def, playerClubId);
    return {
      type: compKey, title: def.title, icon: def.icon, color: def.color,
      format: "knockout", field: field.map((c) => c.id),
      bracket, stage: "knockout", knockoutRound: 0,
      eliminated: false, champion: false,
    };
  }

  // Group stage: split the field into groups of four
  const groups = [];
  const perGroup = def.groupSize;
  const groupCount = Math.floor(field.length / perGroup);
  const seats = groupCount * perGroup;
  const youAt = field.findIndex((c) => c.id === playerClubId);
  if (seats > 0 && youAt >= seats) [field[youAt], field[seats - 1]] = [field[seats - 1], field[youAt]];
  for (let g = 0; g < groupCount; g++) {
    const members = field.slice(g * perGroup, (g + 1) * perGroup);
    const ids = members.map((m) => m.id);
    groups.push({
      letter: String.fromCharCode(65 + g),
      clubIds: ids,
      fixtures: roundRobin(ids),
      table: members.map((m) => blankRow({ ...m, isPlayer: m.id === playerClubId })),
      matchDay: 0,
    });
  }

  return {
    type: compKey, title: def.title, icon: def.icon, color: def.color,
    format: "group_knockout", field: field.map((c) => c.id),
    groups, stage: "group", groupMatchDay: 0,
    bracket: [], knockoutRound: 0,
    eliminated: false, champion: false,
  };
}

// Find the player's fixture for the current group matchday
function playerGroupFixture(comp, playerClubId) {
  if (!comp || comp.format !== "group_knockout") return null;
  const group = comp.groups.find((g) => g.clubIds.includes(playerClubId));
  if (!group) return null;
  const round = group.fixtures[comp.groupMatchDay];
  if (!round) return null;
  const fix = round.find((f) => f.home === playerClubId || f.away === playerClubId);
  if (!fix) return null;
  return { group, fixture: fix, oppId: fix.home === playerClubId ? fix.away : fix.home };
}

// Find the player's tie in the current knockout round
function playerKnockoutTie(comp, playerClubId) {
  if (!comp || !comp.bracket.length) return null;
  const round = comp.bracket[comp.knockoutRound];
  if (!round) return null;
  const tie = round.ties.find((t) => t.homeId === playerClubId || t.awayId === playerClubId);
  if (!tie) return null;
  return { round, tie, oppId: tie.homeId === playerClubId ? tie.awayId : tie.homeId };
}

// Build the knockout bracket from group qualifiers (top 2 of each group)
function buildKnockoutFromGroups(comp, world, def) {
  const qualifiers = [];
  comp.groups.forEach((g) => {
    const sorted = sortTable(g.table);
    sorted.slice(0, 2).forEach((row, idx) => {
      const club = world.find((c) => c.id === row.clubId);
      if (club) qualifiers.push({ club, groupLetter: g.letter, position: idx + 1 });
    });
  });

  // Seed it properly: group winners face runners-up from other groups
  const winners = qualifiers.filter((q) => q.position === 1).map((q) => q.club);
  const runners = qualifiers.filter((q) => q.position === 2).map((q) => q.club);
  const ordered = [];
  winners.forEach((w, i) => {
    ordered.push(w);
    // Pair with a runner-up from a different group
    const opp = runners[(i + 1) % runners.length];
    if (opp) ordered.push(opp);
  });

  return drawKnockout(ordered, def, null);
}

/* ═══════════════════════════════════════════════════════════════════════
   MANAGER DNA
   Every club is run by a manager whose attributes decide how they set up,
   who they sign, and how they react when a match is slipping away.
   ═══════════════════════════════════════════════════════════════════════ */

const MANAGER_FIRST = ["Alessandro", "Diego", "Klaus", "Henrik", "Rafael", "Marcin", "Yusuf", "Tomás", "Bruno", "Anders", "Cesare", "Gerhard", "Nuno", "Pavel", "Sergi", "Lars", "Mateus", "Georgi", "Kenji", "Idris"];
const MANAGER_LAST = ["Conti", "Reyes", "Brandt", "Sørensen", "Moreira", "Lewandowski", "Demir", "Cabral", "Salgado", "Nilsen", "Rossi", "Vogel", "Almeida", "Novak", "Puyal", "Eriksen", "Batista", "Ivanov", "Hoshino", "Traoré"];

function d20(centre, spread) {
  return Math.max(1, Math.min(20, Math.round(centre + (Math.random() - 0.5) * 2 * spread)));
}

function generateManager(reputation) {
  // Higher reputation clubs attract more distinctive, more capable managers
  const quality = reputation / 100; // 0-1
  const centre = 8 + quality * 7;

  const tactical = {
    possession: d20(centre, 6),
    pressing: d20(centre, 6),
    counter: d20(centre, 6),
    direct: d20(centre, 6),
    width: d20(centre, 5),
    caution: d20(centre, 6),
  };

  const management = {
    discipline: d20(centre, 5),
    motivation: d20(centre, 5),
    youthDevelopment: d20(centre, 6),
  };

  const personality = {
    ambition: d20(centre, 6),
    patience: d20(centre, 6),
    riskTaking: d20(centre, 6),
  };

  return {
    name: `${pickRandom(MANAGER_FIRST)} ${pickRandom(MANAGER_LAST)}`,
    tactical, management, personality,
  };
}

// Describe a manager's philosophy in one line
function managerPhilosophy(m) {
  const t = m.tactical;
  const top = Object.entries({
    possession: t.possession, pressing: t.pressing,
    counter: t.counter, direct: t.direct, caution: t.caution,
  }).sort((a, b) => b[1] - a[1])[0][0];
  const labels = {
    possession: "Possession purist", pressing: "Relentless presser",
    counter: "Counter-attacking specialist", direct: "Direct and vertical",
    caution: "Defensive organiser",
  };
  const temper = m.personality.riskTaking >= 15 ? "gambler"
    : m.personality.riskTaking <= 7 ? "pragmatist" : "balanced";
  return `${labels[top]} · ${temper}`;
}

// A manager's DNA decides which tactic they actually pick.
// gameState lets them react: chasing a game, protecting a lead, or level.
function managerPickTactic(manager, gameState) {
  const t = manager.tactical;
  const p = manager.personality;
  const state = gameState || { scoreDiff: 0, minute: 0 };

  // Base affinity for each tactic, straight from tactical DNA
  const score = {
    tikitaka: t.possession * 1.5 - t.direct * 0.6,
    possession: t.possession * 1.2 + t.caution * 0.3,
    gegenpress: t.pressing * 1.5 - t.caution * 0.5,
    counter: t.counter * 1.5 - t.possession * 0.4,
    longball: t.direct * 1.5 - t.possession * 0.6,
    wingplay: t.width * 1.4,
    attacking: p.riskTaking * 0.9 + t.pressing * 0.4 - t.caution * 0.6,
    defensive: t.caution * 1.5 - p.riskTaking * 0.5,
    balanced: 9,
  };

  // React to the game state — this is where personality shows
  const chasing = state.scoreDiff < 0;
  const leading = state.scoreDiff > 0;
  const late = state.minute >= 60;

  if (chasing && late) {
    // Impatient, risk-taking managers throw caution away
    const desperation = (p.riskTaking + (20 - p.patience)) / 40; // 0-1
    score.attacking += 14 * desperation;
    score.gegenpress += 10 * desperation;
    score.wingplay += 5 * desperation;
    score.defensive -= 18;
    score.counter -= 6;
  } else if (leading && late) {
    // Cautious managers shut up shop; ambitious ones keep going
    const conservatism = ((20 - p.riskTaking) + p.patience) / 40;
    score.defensive += 13 * conservatism;
    score.counter += 8 * conservatism;
    score.attacking -= 10 * conservatism;
    score.gegenpress -= 6 * conservatism;
  }

  return Object.entries(score).sort((a, b) => b[1] - a[1])[0][0];
}

// Managers also tune instructions from their DNA
function managerInstructions(manager) {
  const t = manager.tactical;
  const p = manager.personality;
  return {
    directness: t.direct >= 14 ? "direct" : t.possession >= 14 ? "short" : "mixed",
    tempo: t.pressing >= 15 ? "high" : t.possession >= 15 ? "slow" : "normal",
    width: t.width >= 14 ? "wide" : t.width <= 7 ? "narrow" : "standard",
    freedom: p.riskTaking >= 15 ? "expressive" : p.riskTaking <= 7 ? "disciplined" : "balanced",
    focus: t.width >= 15 ? "flanks" : t.possession >= 15 ? "central" : "mixed",
    attTransition: t.counter >= 13 ? "counter" : "hold",
    defTransition: t.pressing >= 13 ? "counterpress" : "regroup",
    defLine: t.pressing >= 14 ? "high" : t.caution >= 14 ? "deep" : "standard",
    press: t.pressing >= 14 ? "high" : t.pressing <= 7 ? "low" : "medium",
    tackling: manager.management.discipline <= 7 ? "aggressive" : manager.management.discipline >= 15 ? "cautious" : "normal",
    marking: t.pressing >= 15 ? "man" : "zonal",
  };
}

/* ═══════════════════════════════════════════════════════════════════════
   PERSISTENT FOOTBALL WORLD
   40 clubs that exist permanently, each with a squad, manager and history.
   Competitions draw from this pool — nothing is invented on the fly.
   ═══════════════════════════════════════════════════════════════════════ */

const CLUB_NAME_POOL = [
  // Division 1 calibre
  "Real Astral", "FC Cosmos", "Olympique Neon", "Inter Stellar", "Bayern Blitz",
  "AC Phantom", "Porto Fury", "Celtic Thunder", "Dynamo Volt", "Sporting Flux",
  // Division 2
  "Ajax Circuit", "Benfica Blaze", "Shakhtar Spark", "Red Star Nebula", "PSV Pulse",
  "Galatasaray Nova", "Lyon Prism", "Sevilla Solar", "Napoli Vortex", "Leipzig Surge",
  // Division 3
  "Thunderstrike FC", "Royal Eagles", "Shadow Wolves", "Iron City", "Golden Lions",
  "Storm United", "Dark Knights", "Crimson Tide", "Blue Dragons", "Silver Hawks",
  // Division 4
  "Phantom Athletic", "Blaze Town", "Arctic United", "Emerald Rangers", "Fury FC",
  "Neon Rovers", "Granite City", "Sapphire Town", "Volcanic FC", "Frost United",
];

const CLUBS_PER_DIVISION = 10;

function generateClub(name, divisionTier, index) {
  const div = getDivision(divisionTier);
  // Within a division, clubs vary — some are giants, some are strugglers
  const strengthRoll = 1 - (index / CLUBS_PER_DIVISION); // 1.0 down to 0.1
  const span = div.ovrRange[1] - div.ovrRange[0];
  const lo = Math.round(div.ovrRange[0] + span * strengthRoll * 0.45);
  const hi = Math.round(lo + span * 0.55);

  // Reputation drives manager quality and transfer pull
  const reputation = Math.round((4 - divisionTier) * 22 + strengthRoll * 20 + randInt(-5, 5));
  const formation = pickRandom(FORMATION_KEYS);
  const manager = generateManager(reputation);
  const squad = generateSquad(formation, [lo, Math.min(99, hi)]);

  return {
    id: crypto.randomUUID(),
    name,
    division: divisionTier,
    reputation: Math.max(5, reputation),
    formation,
    manager,
    squad,
    isPlayer: false,
    // Trophy history builds over time
    trophies: [],
  };
}

function generateWorld() {
  const clubs = [];
  for (let tier = 1; tier <= 4; tier++) {
    const offset = (tier - 1) * CLUBS_PER_DIVISION;
    for (let i = 0; i < CLUBS_PER_DIVISION; i++) {
      const name = CLUB_NAME_POOL[offset + i];
      if (!name) continue;
      clubs.push(generateClub(name, tier, i));
    }
  }
  return clubs;
}

// Average OVR of a club's XI
function clubOvr(club) {
  if (!club.squad || !club.squad.length) return 50;
  return Math.round(club.squad.reduce((s, p) => s + p.ovr, 0) / club.squad.length);
}

// Build the simulation-ready side for a club, with its manager in charge
function clubToSide(club, gameState) {
  const tacticKey = club.isPlayer ? club.tacticKey : managerPickTactic(club.manager, gameState);
  const instr = club.isPlayer ? club.instructions : managerInstructions(club.manager);
  return {
    name: club.name,
    squad: club.squad,
    slotPositions: FORMATIONS[club.formation].positions,
    behaviour: resolveBehaviour(tacticKey, instr),
    tacticKey,
    bonus: club.bonus || 0,
  };
}

/* ═══════════════════════════════════════════════════════════════════════
   FIXTURE GENERATION — proper round-robin so every club plays every club
   ═══════════════════════════════════════════════════════════════════════ */

// Circle method: n teams, n-1 rounds, everyone plays everyone once
function roundRobin(teamIds) {
  const ids = [...teamIds];
  if (ids.length % 2 !== 0) ids.push(null); // bye
  const n = ids.length;
  const rounds = [];
  const arr = [...ids];

  for (let r = 0; r < n - 1; r++) {
    const pairs = [];
    for (let i = 0; i < n / 2; i++) {
      const a = arr[i];
      const b = arr[n - 1 - i];
      if (a !== null && b !== null) {
        // Alternate home/away for fairness
        pairs.push(r % 2 === 0 ? { home: a, away: b } : { home: b, away: a });
      }
    }
    rounds.push(pairs);
    // Rotate all but the first
    arr.splice(1, 0, arr.pop());
  }
  return rounds;
}

// Fast result simulation for matches the player isn't involved in.
// Uses the same team profiles and manager tactics, just skips event text.
function quickSimulate(homeClub, awayClub) {
  const hSide = clubToSide(homeClub, { scoreDiff: 0, minute: 0 });
  const aSide = clubToSide(awayClub, { scoreDiff: 0, minute: 0 });
  const H = buildTeamProfile(hSide.squad, hSide.slotPositions, hSide.behaviour, hSide.bonus + 2);
  const A = buildTeamProfile(aSide.squad, aSide.slotPositions, aSide.behaviour, aSide.bonus);

  // Expected goals from the same phase logic, collapsed into one calculation
  function expectedGoals(ATT, DEF) {
    const build = contest(ATT.buildup, DEF.pressing * 0.95, 0.026, 0.80, 0.38);
    const prog = contest(ATT.progression, DEF.defBlock * 0.92, 0.026, 0.74, 0.44);
    const entry = contest(ATT.finalThird, DEF.defBlock, 0.026, 0.60, 0.48);
    const create = contest(ATT.chanceQuality, DEF.defBlock * 1.02, 0.024, 0.47, 0.44);
    const chances = POSSESSIONS_PER_MATCH * 0.5 * build * prog * entry * create;
    const breakChance = Math.pow(ATT.b.transitionSpeed / 100, 1.6) * 0.25;
    const breaks = POSSESSIONS_PER_MATCH * 0.5 * (1 - build * prog) * breakChance * 0.55;
    const avgXg = 0.11 * (0.86 + (ATT.b.patience / 100) * 0.28);
    return (chances + breaks) * avgXg * 1.05;
  }

  const hXg = expectedGoals(H, A);
  const aXg = expectedGoals(A, H);

  // Poisson draw around expected goals
  function poisson(lambda) {
    const L = Math.exp(-Math.max(0.05, Math.min(6, lambda)));
    let k = 0, p = 1;
    do { k++; p *= Math.random(); } while (p > L);
    return k - 1;
  }

  return {
    homeGoals: Math.min(8, poisson(hXg)),
    awayGoals: Math.min(8, poisson(aXg)),
    homeXg: Number(hXg.toFixed(2)),
    awayXg: Number(aXg.toFixed(2)),
  };
}

// Empty league row
function blankRow(club) {
  return {
    clubId: club.id, name: club.name, isYou: !!club.isPlayer,
    played: 0, won: 0, drawn: 0, lost: 0, gf: 0, ga: 0, points: 0, form: [],
  };
}

// Apply a result to two table rows
function applyResult(table, homeId, awayId, hg, ag) {
  const h = table.find((r) => r.clubId === homeId);
  const a = table.find((r) => r.clubId === awayId);
  if (!h || !a) return;
  h.played++; a.played++;
  h.gf += hg; h.ga += ag;
  a.gf += ag; a.ga += hg;
  if (hg > ag) {
    h.won++; h.points += 3; h.form = [...h.form, "W"].slice(-5);
    a.lost++; a.form = [...a.form, "L"].slice(-5);
  } else if (hg < ag) {
    a.won++; a.points += 3; a.form = [...a.form, "W"].slice(-5);
    h.lost++; h.form = [...h.form, "L"].slice(-5);
  } else {
    h.drawn++; h.points += 1; h.form = [...h.form, "D"].slice(-5);
    a.drawn++; a.points += 1; a.form = [...a.form, "D"].slice(-5);
  }
}

function sortTable(table) {
  return [...table].sort((a, b) =>
    b.points - a.points || (b.gf - b.ga) - (a.gf - a.ga) || b.gf - a.gf || a.name.localeCompare(b.name));
}

/* ═══════════════════════════════════════════════════════════════════════
   TROPHY CASE & ACHIEVEMENTS
   Trophies from competitions, medals from milestones.
   Prestige score attracts better transfer arrivals.
   ═══════════════════════════════════════════════════════════════════════ */

const TROPHY_PRESTIGE = { national_cup: 5, club_league: 10, world_championship: 15 };

function calculatePrestige(trophies) {
  let p = 0;
  trophies.forEach((t) => { p += TROPHY_PRESTIGE[t.type] || 5; });
  return p;
}

function getPrestigeLabel(prestige) {
  if (prestige >= 80) return { label: "Legendary", color: "#ff2ecb" };
  if (prestige >= 50) return { label: "World Class", color: "#ffd700" };
  if (prestige >= 30) return { label: "Continental", color: "#00e5ff" };
  if (prestige >= 15) return { label: "National", color: "#00ff88" };
  if (prestige >= 5) return { label: "Local", color: "#ffa800" };
  return { label: "Unknown", color: "#64748b" };
}

function getPrestigeArrivalBonus(prestige) {
  return Math.min(20, Math.floor(prestige / 4));
}

/* ═══════════════════════════════════════════════════════════════════════
   MATCH SIMULATION ENGINE (90% Strategy, 10% Luck)
   ═══════════════════════════════════════════════════════════════════════ */

/* ═══════════════════════════════════════════════════════════════════════
   MATCH ENGINE v2 — Phase-based simulation
   Build-up → Progression → Final third → Chance → Shot → Goalkeeper
   Every phase reads real player attributes.
   ═══════════════════════════════════════════════════════════════════════ */

const POSSESSIONS_PER_MATCH = 108; // ~54 each in a balanced game
// Match minutes one possession takes at the reference tempo. Faster tempo
// packs more possessions into a minute; slower tempo fewer.
const BASE_STEP = 89 / POSSESSIONS_PER_MATCH;
const TEMPO_REF = 66;   // the measured average match tempo, so a typical game keeps its usual rhythm
const LOAD_BASE = 0.654; // calibrated so a team at average intensity tires at the usual rate

// Average a stat across a group of players, weighted by how much that phase involves them
function statAvg(players, keys) {
  if (!players.length) return 45;
  let total = 0;
  players.forEach((p) => {
    const d = p.detailed || {};
    let s = 0;
    keys.forEach((k) => { s += d[k] ?? 45; });
    total += s / keys.length;
  });
  return total / players.length;
}

// Split the XI into phase groups based on slot position
function groupSquad(squad, slotPositions) {
  const g = { gk: [], def: [], dm: [], mid: [], wide: [], att: [] };
  squad.forEach((p, i) => {
    const pos = slotPositions[i] || p.naturalPosition;
    if (pos === "GK") g.gk.push(p);
    else if (["CB"].includes(pos)) g.def.push(p);
    else if (["LB", "RB", "LWB", "RWB"].includes(pos)) { g.def.push(p); g.wide.push(p); }
    else if (["CDM"].includes(pos)) g.dm.push(p);
    else if (["CM", "CAM"].includes(pos)) g.mid.push(p);
    else if (["LM", "RM", "LW", "RW"].includes(pos)) { g.wide.push(p); g.att.push(p); }
    else g.att.push(p);
  });
  if (!g.gk.length) g.gk = [squad[0]].filter(Boolean);
  if (!g.dm.length) g.dm = g.mid.length ? [g.mid[0]] : g.def.slice(0, 1);
  if (!g.mid.length) g.mid = g.dm.length ? g.dm : g.att.slice(0, 1);
  if (!g.att.length) g.att = g.mid.slice(0, 1);
  if (!g.def.length) g.def = g.dm.slice(0, 1);
  return g;
}

// Fitness/morale-adjusted multiplier for a group
function conditionMult(players) {
  if (!players.length) return 1;
  const avgFit = players.reduce((s, p) => s + (p.fitness ?? 100), 0) / players.length;
  return 0.72 + (avgFit / 100) * 0.28; // 100% fit = 1.0, 0% fit = 0.72
}

// Build a full team profile from players + resolved behaviour
function buildTeamProfile(squad, slotPositions, behaviour, bonuses) {
  const g = groupSquad(squad, slotPositions);
  const b = behaviour;
  const bonus = bonuses || 0;

  // Raw attribute pools
  const gkQuality = statAvg(g.gk, ["reactions", "composure", "jumping", "strength"]);
  const cbQuality = statAvg(g.def, ["defAwareness", "standingTackle", "headingAccuracy", "strength"]);
  const buildPass = statAvg([...g.gk, ...g.def, ...g.dm], ["shortPassing", "composure", "vision"]);
  const progress = statAvg([...g.dm, ...g.mid], ["longPassing", "shortPassing", "vision", "ballControl"]);
  const carry = statAvg([...g.mid, ...g.wide], ["dribbling", "agility", "acceleration", "balance"]);
  const creation = statAvg([...g.mid, ...g.wide, ...g.att], ["vision", "crossing", "curve", "shortPassing"]);
  const finishing = statAvg(g.att, ["finishing", "attackPositioning", "composure", "shotPower"]);
  const pressWork = statAvg([...g.mid, ...g.att, ...g.wide], ["stamina", "aggression", "interceptions", "acceleration"]);
  const defBlock = statAvg([...g.def, ...g.dm], ["defAwareness", "interceptions", "standingTackle", "slidingTackle"]);
  const pace = statAvg([...g.att, ...g.wide], ["sprintSpeed", "acceleration"]);
  const aerial = statAvg([...g.att, ...g.def], ["headingAccuracy", "jumping", "strength"]);

  const fitMult = conditionMult(squad);

  // Behaviour weighting — tactics decide which attributes actually matter
  const shortBias = (100 - b.directness) / 100;   // 1 = pure short passing
  const directBias = b.directness / 100;
  const pressBias = b.pressIntensity / 100;
  const widthBias = b.width / 100;
  const patienceBias = b.patience / 100;

  // Playing short-handed has to be punished explicitly. Every pool above is an
  // AVERAGE, so simply deleting a sent-off player can even raise a group's
  // average — a red card would otherwise make a team stronger.
  const manpower = Math.pow(Math.min(1, squad.length / 11), 1.6);

  return {
    groups: g,
    // Phase strengths (0-100ish)
    buildup: (buildPass * (0.5 + shortBias * 0.5) + cbQuality * 0.2 + gkQuality * 0.1) * fitMult * manpower + bonus,
    progression: (progress * (0.50 + shortBias * 0.22) + carry * (0.24 + widthBias * 0.18) + aerial * directBias * 0.46) * fitMult * manpower + bonus,
    finalThird: (creation * (0.55 + patienceBias * 0.2) + carry * 0.25 + pace * (0.2 + (1 - patienceBias) * 0.25)) * fitMult * manpower + bonus,
    chanceQuality: (creation * 0.5 + finishing * 0.3 + aerial * directBias * 0.25),
    finishing: finishing * fitMult * manpower + bonus,
    // Defensive phases
    pressing: (pressWork * pressBias + defBlock * 0.35) * fitMult * manpower + bonus,
    defBlock: (defBlock * (0.6 + (1 - b.defLine / 100) * 0.3) + cbQuality * 0.4) * fitMult * manpower + bonus,
    gkQuality: gkQuality * (0.85 + fitMult * 0.15),
    aerial,
    pace,
    // Behaviour passthrough
    b,
    fitMult,
    manpower,
    onPitch: squad.length,
  };
}

// Logistic helper — converts an advantage into a 0-1 probability
function contest(attack, defence, steepness = 0.035, base = 0.5, spread = 0.75) {
  const diff = attack - defence;
  const swing = (1 / (1 + Math.exp(-diff * steepness)) - 0.5) * spread;
  return Math.max(0.06, Math.min(0.95, base + swing));
}

function pickWeighted(players, keys) {
  if (!players.length) return null;
  const weights = players.map((p) => {
    const d = p.detailed || {};
    let s = 0;
    keys.forEach((k) => { s += d[k] ?? 45; });
    return Math.pow(Math.max(1, s / keys.length), 2.2);
  });
  const total = weights.reduce((a, b) => a + b, 0);
  let r = Math.random() * total;
  for (let i = 0; i < players.length; i++) {
    r -= weights[i];
    if (r <= 0) return players[i];
  }
  return players[players.length - 1];
}

function blankStats() {
  return { goals: 0, assists: 0, shots: 0, shotsOnTarget: 0, xg: 0, keyPasses: 0, passes: 0, passesCompleted: 0, tackles: 0, interceptions: 0, saves: 0, duelsWon: 0, rating: 6.0 };
}

// Accumulate match stats from only the events revealed so far,
// so the viewer sees the game build rather than the final figures.
// How long to hold on an event before revealing the next one.
// Every chance gets the same suspense — a pause must not give the goal away.
const CHANCE_EVENTS = new Set(["goal", "save", "miss", "block"]);
function eventRevealDelay(evt) {
  if (!evt) return 400;
  if (evt.type === "whistle") return 950;
  if (CHANCE_EVENTS.has(evt.type)) return 900 + Math.floor(Math.random() * 500);
  return 320 + Math.floor(Math.random() * 220);
}

// Runs a whole match start to finish with no interruptions. Quick sims, cup
// ties and AI-vs-AI fixtures all still use this and behave exactly as before.
function simulateMatchV2(home, away) {
  const g = runMatch(home, away);
  let r = g.next();
  while (!r.done) r = g.next();
  return r.value;
}

function liveMatchStats(result, visibleCount, isLive) {
  if (!result) return null;
  if (!isLive) return result.matchStats;

  const shown = result.events.slice(0, visibleCount);
  const s = {
    homeShots: 0, awayShots: 0, homeSOT: 0, awaySOT: 0,
    homeXg: 0, awayXg: 0, homeCorners: 0, awayCorners: 0,
    homeGoals: 0, awayGoals: 0,
  };

  shown.forEach((e) => {
    if (e.type === "goal") {
      if (e.team === "home") s.homeGoals++; else if (e.team === "away") s.awayGoals++;
    }
    const d = e.sd;
    if (!d) return;
    const home = d.team === "home";
    if (d.shot) { if (home) s.homeShots += d.shot; else s.awayShots += d.shot; }
    if (d.sot) { if (home) s.homeSOT += d.sot; else s.awaySOT += d.sot; }
    if (d.xg) { if (home) s.homeXg += d.xg; else s.awayXg += d.xg; }
    if (d.corner) { if (home) s.homeCorners += d.corner; else s.awayCorners += d.corner; }
  });

  s.homeXg = Number(s.homeXg.toFixed(2));
  s.awayXg = Number(s.awayXg.toFixed(2));

  // Possession as it stood at the current minute
  const minute = shown.length ? shown[shown.length - 1].min : 0;
  let poss = 50;
  const tl = result.possTimeline || [];
  for (let i = 0; i < tl.length; i++) {
    if (tl[i].min <= minute) poss = tl[i].homePct; else break;
  }
  s.possession = poss;
  s.minute = minute;
  return s;
}

// A modest, realistic edge for playing at home: crowd, familiarity, no travel.
// Feeds through the existing `bonus` channel into buildTeamProfile.
const HOME_ADVANTAGE = 3;

const MAX_SUBS = 5;
// Set pieces now add goals of their own, so open-play finishing is trimmed to
// keep the overall scoring rate where it was tuned.
const OPEN_PLAY_FINISH = 0.94;
const SUB_WINDOWS = [46, 58, 66, 74, 82];

// Events that mean the ball is out of play. Real substitutions and tactical
// switches only happen at a stoppage — turnovers and tackles mean play flows on.
const DEAD_BALL_TYPES = new Set(["goal", "corner", "freekick", "yellow", "red", "miss", "save", "whistle", "sub", "tactic"]);

// Runs the match one possession at a time. The caller drives it with .next(),
// and can hand in a manager's order at any pause point; the order is held until
// the ball is actually dead.
function* runMatch(home, away) {
  // home/away = { squad, slotPositions, behaviour, bonus, name, bench }
  // Each side is now MUTABLE: players can be sent off or substituted, and the
  // team profile is rebuilt whenever the eleven on the pitch changes.
  const sides = {
    home: { src: home, xi: [...home.squad], slots: [...home.slotPositions],
            bench: [...(home.bench || [])], subsUsed: 0, sentOff: [], subs: [],
            formationKey: home.formationKey || null, shapeChanges: [],
            coords: [...(FORMATIONS[home.formationKey]?.coords || [])] },
    away: { src: away, xi: [...away.squad], slots: [...away.slotPositions],
            bench: [...(away.bench || [])], subsUsed: 0, sentOff: [], subs: [],
            formationKey: away.formationKey || null, shapeChanges: [],
            coords: [...(FORMATIONS[away.formationKey]?.coords || [])] },
  };

  // How well one shape matches up against the other. Positive means your
  // structure troubles theirs; it flows in through the same bonus channel as
  // chemistry and home advantage, and is re-read whenever a shape changes.
  function matchupEdge(key) {
    const mine = sides[key].formationKey;
    const theirs = sides[key === "home" ? "away" : "home"].formationKey;
    if (!mine || !theirs) return 0;
    return FORMATION_MATCHUPS[mine]?.[theirs] ?? 0;
  }

  // Where a given slot sits in a shape, so a player who changes role during
  // the match is drawn in the area he actually moves to.
  function coordForSlot(formationKey, slot, fallback) {
    const shape = FORMATIONS[formationKey];
    if (!shape) return fallback;
    const i = shape.positions.indexOf(slot);
    return i === -1 ? fallback : shape.coords[i];
  }

  // The target slot is usually already occupied by the player who plays there,
  // so shift the new arrival sideways rather than standing him on a team-mate.
  function freeCoord(S, base, skipIdx) {
    if (!base) return base;
    const taken = (x, y) => S.coords.some((c, i) =>
      i !== skipIdx && c && Math.abs(c.x - x) < 6 && Math.abs(c.y - y) < 5);
    if (!taken(base.x, base.y)) return base;
    for (const dx of [14, -14, 24, -24, 32, -32]) {
      const x = Math.max(8, Math.min(92, base.x + dx));
      if (!taken(x, base.y)) return { x, y: base.y };
    }
    for (const dy of [8, -8]) {
      const y = Math.max(6, Math.min(94, base.y + dy));
      if (!taken(base.x, y)) return { x: base.x, y };
    }
    return base;
  }

  function profileFor(key) {
    const S = sides[key];
    return buildTeamProfile(S.xi, S.slots, S.src.behaviour, S.src.bonus + matchupEdge(key));
  }

  let H, A;
  function rebuild(key) {
    // A shape change alters the matchup for BOTH teams, so refresh the pair.
    H = profileFor("home");
    A = profileFor("away");
  }
  rebuild();

  // Reshape a side into a new formation, fitting the players already on the
  // pitch to the new slots by who suits each one best. The keeper stays put.
  function changeShape(key, formationKey, minute, note) {
    const S = sides[key];
    const shape = FORMATIONS[formationKey];
    if (!shape || S.formationKey === formationKey) return false;
    const newSlots = shape.positions.slice(0, S.xi.length);
    if (!newSlots.length) return false;

    const pool = [...S.xi];
    const assigned = [];
    newSlots.forEach((slot) => {
      let bestIdx = 0, bestScore = -Infinity;
      pool.forEach((pl, i) => {
        // Keepers belong in goal and nowhere else
        const isGk = pl.naturalPosition === "GK";
        let score = getEffectiveOvr(pl, slot);
        if (slot === "GK") score += isGk ? 1000 : -1000;
        else if (isGk) score -= 1000;
        if (score > bestScore) { bestScore = score; bestIdx = i; }
      });
      assigned.push(pool.splice(bestIdx, 1)[0]);
    });

    S.xi = assigned;
    S.slots = newSlots;
    S.coords = shape.coords.slice(0, assigned.length);
    S.formationKey = formationKey;
    S.shapeChanges.push({ min: Math.round(minute), to: formationKey });
    events.push({ min: claimMinute(minute), type: "tactic", team: key, icon: "📐",
      text: `${note || "Shape change"} — switching to ${formationKey}`,
      color: key === "home" ? "#00e5ff" : "#ff6b6b" });
    rebuild();
    return true;
  }

  // ── Possession split ──
  // Recomputed every possession so a red card or a substitution actually
  // shifts who controls the game, instead of being fixed at kick-off.
  function currentPossShare() {
    const hPoss = H.buildup * (0.55 + H.b.patience / 200) + H.progression * 0.4 - A.pressing * 0.35;
    const aPoss = A.buildup * (0.55 + A.b.patience / 200) + A.progression * 0.4 - H.pressing * 0.35;
    return Math.max(0.28, Math.min(0.72, hPoss / Math.max(1, hPoss + aPoss)));
  }

  // ── Per-player stat tracking (benches included — they may come on) ──
  const stats = {};
  [...home.squad, ...away.squad, ...(home.bench || []), ...(away.bench || [])]
    .forEach((p) => { if (p) stats[p.id] = blankStats(); });

  // ── Minute tracking ──
  // The foundation everything else rests on: fatigue, ratings and development
  // all need to know how long each player was actually on the pitch.
  const minutes = {};
  const enteredAt = {};
  const load = {};          // physical work done on the pitch, scaled by intensity
  Object.keys(stats).forEach((id) => { minutes[id] = 0; });
  [...sides.home.xi, ...sides.away.xi].forEach((p) => { enteredAt[p.id] = 0; });

  function leavePitch(player, minute) {
    const start = enteredAt[player.id] ?? 0;
    minutes[player.id] = (minutes[player.id] || 0) + Math.max(0, Math.round(minute - start));
    delete enteredAt[player.id];
  }

  // How fresh a player looks right now: starting fitness minus what this
  // match has taken out of him, with stamina deciding how fast he empties.
  function liveCondition(player, minute) {
    // How much running he's actually done: time on the pitch, weighted by how
    // intense the match has been while he's been out there.
    const on = load[player.id] ?? (minute - (enteredAt[player.id] ?? minute));
    const stamina = player.detailed?.stamina ?? 55;
    return (player.fitness ?? 100) - on * (0.58 * (1 + (60 - stamina) / 130));
  }

  function bestReplacement(S, slot) {
    const pool = S.bench.filter((p) => p && !p.injuredFor);
    if (!pool.length) return null;
    return pool.slice().sort((a, b) =>
      (getEffectiveOvr(b, slot) + (b.fitness ?? 100) * 0.06) -
      (getEffectiveOvr(a, slot) + (a.fitness ?? 100) * 0.06)
    )[0];
  }

  function makeSub(key, outPlayer, wantedSlot, minute, reason) {
    const S = sides[key];
    if (S.subsUsed >= MAX_SUBS || !S.bench.length || !outPlayer) return false;
    const idx = S.xi.findIndex((p) => p.id === outPlayer.id);
    if (idx === -1) return false;
    const slot = wantedSlot || S.slots[idx];
    const inPlayer = bestReplacement(S, slot);
    if (!inPlayer) return false;

    S.bench = S.bench.filter((p) => p.id !== inPlayer.id);
    S.xi[idx] = inPlayer;
    S.coords[idx] = freeCoord(S, coordForSlot(S.formationKey, slot, S.coords[idx]), idx);
    S.slots[idx] = slot;
    leavePitch(outPlayer, minute);
    enteredAt[inPlayer.id] = minute;
    S.subsUsed++;
    S.subs.push({ min: Math.round(minute), offName: outPlayer.lastName, onName: inPlayer.lastName, reason });
    rebuild(key);

    events.push({ min: claimMinute(minute), type: "sub", team: key, icon: "🔄",
      text: `${inPlayer.lastName} replaces ${outPlayer.lastName} — ${reason}`,
      color: key === "home" ? "#00e5ff" : "#ff6b6b" });
    return true;
  }

  // A red card now physically removes the player from the eleven
  function sendOff(key, player, minute) {
    const S = sides[key];
    const idx = S.xi.findIndex((p) => p.id === player.id);
    if (idx === -1) return;
    if (S.slots[idx] === "GK") return;   // keep a keeper on the pitch
    if (S.xi.length <= 8) return;        // don't simulate an abandoned match
    const gone = { min: Math.round(minute), name: player.lastName, id: player.id,
      player, slot: S.slots[idx], coord: S.coords[idx] };
    S.xi.splice(idx, 1);
    S.slots.splice(idx, 1);
    S.coords.splice(idx, 1);
    S.sentOff.push(gone);
    leavePitch(player, minute);
    rebuild(key);
  }

  // Shapes an AI manager reaches for when the game demands something different
  const CHASING_SHAPES = ["3-4-3", "4-3-3", "3-4-2-1"];
  const HOLDING_SHAPES = ["5-4-1", "5-3-2", "4-1-4-1"];

  // AI managers reshape, not just re-personnel. A side chasing a goal pushes
  // bodies forward; a side protecting a lead packs the back.
  function considerShape(key, minute, goalsFor, goalsAgainst) {
    const S = sides[key];
    if (!S.formationKey) return;
    if (S.shapeChanges.length >= 2) return;      // managers don't fiddle endlessly
    const diff = goalsFor - goalsAgainst;

    if (minute >= 65 && diff < 0) {
      const pick = CHASING_SHAPES.find((f) => f !== S.formationKey);
      if (pick) changeShape(key, pick, minute, "Throwing bodies forward");
      return;
    }
    if (minute >= 76 && diff === 1) {
      const pick = HOLDING_SHAPES.find((f) => f !== S.formationKey);
      if (pick) changeShape(key, pick, minute, "Shutting up shop");
    }
  }

  // The manager actually intervenes: tiredness first, then the scoreline
  function considerSubs(key, minute, goalsFor, goalsAgainst) {
    const S = sides[key];
    if (S.subsUsed >= MAX_SUBS || !S.bench.length) return;

    const outfield = S.xi.map((p, i) => ({ p, slot: S.slots[i] })).filter((x) => x.slot !== "GK");
    if (!outfield.length) return;

    // Tactical intent comes first when the scoreline demands it, but only once
    // each per match — otherwise tiredness subs would swallow every window.
    if (minute >= 62 && goalsFor < goalsAgainst && !S.usedChase) {
      const back = outfield.find((x) => ["CB", "CDM", "LB", "RB", "LWB", "RWB"].includes(x.slot));
      if (back && makeSub(key, back.p, "ST", minute, "chasing the game")) { S.usedChase = true; return; }
    }

    if (minute >= 74 && goalsFor - goalsAgainst === 1 && !S.usedHold) {
      const fwd = outfield.find((x) => ["ST", "CF", "LW", "RW", "CAM"].includes(x.slot));
      if (fwd && makeSub(key, fwd.p, "CDM", minute, "seeing it out")) { S.usedHold = true; return; }
    }

    // Otherwise: whoever is running on empty
    const tired = outfield
      .map((x) => ({ ...x, c: liveCondition(x.p, minute) }))
      .sort((a, b) => a.c - b.c)[0];
    if (tired && tired.c < 60 && makeSub(key, tired.p, tired.slot, minute, "tiring")) return;
  }

  // ── The manager's own changes ──
  // Applied only when the ball is dead. Subs are explicit (you name who comes
  // off and who comes on); a tactic switch swaps the side's behaviour.
  function applyManagerOrder(order, minute) {
    const key = order.side || "home";
    const S = sides[key];
    let changed = false;

    (order.subs || []).forEach(({ outId, inId }) => {
      if (S.subsUsed >= MAX_SUBS) return;
      const idx = S.xi.findIndex((p) => p.id === outId);
      const bIdx = S.bench.findIndex((p) => p.id === inId);
      if (idx === -1 || bIdx === -1) return;
      const outP = S.xi[idx];
      const inP = S.bench[bIdx];
      if (inP.injuredFor) return;

      S.bench.splice(bIdx, 1);
      S.xi[idx] = inP;
      leavePitch(outP, minute);
      enteredAt[inP.id] = minute;
      S.subsUsed++;
      S.subs.push({ min: Math.round(minute), offName: outP.lastName, onName: inP.lastName, reason: "your call" });
      events.push({ min: claimMinute(minute), type: "sub", team: key, icon: "🔄",
        text: `${inP.lastName} comes on for ${outP.lastName}`,
        color: key === "home" ? "#00e5ff" : "#ff6b6b" });
      changed = true;
    });

    if (order.formation && order.formation !== S.formationKey) {
      if (changeShape(key, order.formation, minute, "Manager reshapes")) changed = true;
    }

    if (order.behaviour) {
      S.src = { ...S.src, behaviour: order.behaviour, tacticKey: order.tacticKey ?? S.src.tacticKey };
      events.push({ min: claimMinute(minute), type: "tactic", team: key, icon: "🧠",
        text: `Tactical switch — now playing ${order.tacticName || order.tacticKey}`,
        color: key === "home" ? "#00e5ff" : "#ff6b6b" });
      changed = true;
    }

    if (changed) rebuild(key);
  }

  const windowsUsed = new Set();

  const events = [];
  const possTimeline = [];  // { min, homePct } sampled through the match
  let homePossCount = 0, totalPossCount = 0;
  let homeGoals = 0, awayGoals = 0;
  let homeShots = 0, awayShots = 0;
  let homeSOT = 0, awaySOT = 0;
  let homeXg = 0, awayXg = 0;
  let homeCorners = 0, awayCorners = 0;
  let homeFouls = 0, awayFouls = 0;

  const usedMinutes = new Set();
  function claimMinute(target) {
    let m = Math.max(1, Math.min(90, Math.round(target)));
    let guard = 0;
    while (usedMinutes.has(m) && guard < 120) { m = m % 90 + 1; guard++; }
    usedMinutes.add(m);
    return m;
  }

  // ── TRANSITION: a fast break after winning the ball ──
  // BRK = team breaking, VIC = team that just lost it, danger scales with where it was won
  function tryTransition(BRK, VIC, breakerIsHome, minute, danger) {
    // Chance of launching a break at all — driven by transition speed and directness
    const launch = Math.pow(BRK.b.transitionSpeed / 100, 1.6) * 0.25 + (BRK.b.directness / 100) * 0.04;
    if (Math.random() > launch * danger) return;

    // Space behind the victim's defence: a high line and slow regrouping is fatal
    const spaceBehind = (VIC.b.defLine / 100) * 0.55 + (1 - VIC.b.counterPress / 100) * 0.30;
    // The victim's recovery: deep blocks and counter-pressing snuff breaks out
    const recovery = contest(VIC.defBlock * (0.75 + (1 - VIC.b.defLine / 100) * 0.4), BRK.pace, 0.028, 0.50, 0.45);
    if (Math.random() < recovery * (1 - spaceBehind * 0.55)) return;

    const shooter = pickWeighted(BRK.groups.att.length ? BRK.groups.att : BRK.groups.mid,
      ["sprintSpeed", "attackPositioning", "finishing"]);
    if (!shooter) return;
    const creator = pickWeighted([...BRK.groups.mid, ...BRK.groups.wide], ["vision", "longPassing"]);

    const sd = shooter.detailed || {};
    // Breaks are high-quality chances: fewer defenders back
    let xg = 0.10 + spaceBehind * 0.14 + ((sd.attackPositioning ?? 50) / 100) * 0.09;
    xg *= 0.85 + danger * 0.30;
    xg = Math.max(0.04, Math.min(0.75, xg));

    stats[shooter.id].shots += 1;
    stats[shooter.id].xg += xg;
    if (breakerIsHome) { homeShots++; homeXg += xg; } else { awayShots++; awayXg += xg; }
    if (creator && creator.id !== shooter.id) stats[creator.id].keyPasses += 1;

    const finishSkill = ((sd.finishing ?? 50) * 0.5 + (sd.composure ?? 50) * 0.25 + (sd.shotPower ?? 50) * 0.25);
    const onTargetProb = Math.max(0.20, Math.min(0.90, 0.30 + (finishSkill - 40) / 130));
    const colour = breakerIsHome ? "#00e5ff" : "#ff6b6b";
    const tKey = breakerIsHome ? "home" : "away";
    const keeperOf = VIC.groups.gk[0];
    if (creator && creator.id !== shooter.id) playSeq.push({ attKey: tKey, phase: 2, carrierId: creator.id, counter: true });
    playSeq.push({ attKey: tKey, phase: 3, carrierId: shooter.id, xg, power: sd.shotPower ?? 55, counter: true });

    if (Math.random() > onTargetProb) {
      playSeq.push({ attKey: tKey, phase: 3, carrierId: shooter.id, xg, power: sd.shotPower ?? 55, outcome: "miss", counter: true });
      restart = { team: otherKey(tKey), kind: "goalKick" };
      events.push({ min: claimMinute(minute), type: "miss", team: tKey, icon: "💨",
        text: `Counter! ${shooter.lastName} breaks clear but shoots wide (${xg.toFixed(2)} xG)`, color: "#64748b",
        sd: { team: tKey, shot: 1, sot: 0, xg } });
      return;
    }
    if (breakerIsHome) homeSOT++; else awaySOT++;
    stats[shooter.id].shotsOnTarget += 1;

    const keeper = VIC.groups.gk[0];
    const kd = keeper?.detailed || {};
    const gkSkill = ((kd.reactions ?? 50) * 0.5 + (kd.composure ?? 50) * 0.25 + (kd.jumping ?? 50) * 0.25);
    let convertProb = (xg / Math.max(0.05, onTargetProb)) * (0.66 + (finishSkill - gkSkill) / 240) * OPEN_PLAY_FINISH;
    convertProb = Math.max(0.04, Math.min(0.85, convertProb));

    if (Math.random() < convertProb) {
      if (breakerIsHome) homeGoals++; else awayGoals++;
      restart = { team: otherKey(tKey), kind: "kickoff" };
      stats[shooter.id].goals += 1;
      if (creator && creator.id !== shooter.id) stats[creator.id].assists += 1;
      playSeq.push({ attKey: tKey, phase: 3, carrierId: shooter.id, xg, power: sd.shotPower ?? 55, outcome: "goal", keeperId: keeperOf?.id, counter: true });
      events.push({ min: claimMinute(minute), type: "goal", team: tKey, icon: "⚡",
        text: `GOAL ON THE COUNTER! ${shooter.firstName} ${shooter.lastName} punishes them${creator && creator.id !== shooter.id ? ` — ${creator.lastName} the pass` : ""} (${xg.toFixed(2)} xG)`,
        color: colour, sd: { team: tKey, shot: 1, sot: 1, xg } });
    } else {
      if (keeper) stats[keeper.id].saves += 1;
      const heldC = Math.random() < 0.45;
      playSeq.push({ attKey: tKey, phase: 3, carrierId: shooter.id, xg, power: sd.shotPower ?? 55, outcome: "save", keeperId: keeperOf?.id, counter: true, held: heldC });
      if (heldC) restart = { team: otherKey(tKey), kind: "keeperBall" };
      else if (Math.random() < 0.45) takeCorner(tKey, minute);
      events.push({ min: claimMinute(minute), type: "save", team: tKey, icon: "🧤",
        text: `${keeper ? keeper.lastName : "The keeper"} denies ${shooter.lastName} on the break (${xg.toFixed(2)} xG)`, color: colour,
        sd: { team: tKey, shot: 1, sot: 1, xg } });
    }
  }

  // ── Simulate possessions ──
  // ── Tempo & intensity ──
  // Tempo is how fast the match is being played; intensity is how hard it is
  // being fought. The tactics set each team's baseline, then the game itself
  // moves them: the opening exchanges, a team chasing the game or managing a
  // lead, the response to a goal, a red card, tired legs, and flashpoints
  // like fouls and cards. Both feed back into play: tempo sets how many
  // possessions fit into a minute, intensity how often fouls happen and how
  // quickly players tire.
  const pulse = [];
  const lastScored = { home: null, away: null };
  const lastConceded = { home: null, away: null };
  let heat = 0;
  let foulsSeen = 0;
  let curIntensity = 55;
  let nextStep = BASE_STEP;
  const waveSeed = Math.random() * 1000;

  // Values near the top are compressed rather than cut off, so even a frantic
  // pressing match still visibly rises and falls instead of pinning at 100.
  function softCap(v) {
    const top = v <= 84 ? v : 84 + 14 * (1 - Math.exp(-(v - 84) / 14));
    return Math.max(5, top);
  }

  function sidePulse(key, minute, gf, ga) {
    const S = sides[key];
    const b = S.src.behaviour || {};
    const drivers = [];
    // Tactics set the baseline, mapped into the middle of the range so there's
    // room above and below for the game to move it.
    let tempo = 18 + 0.72 * (0.5 * (b.tempo ?? 50) + 0.3 * (b.transitionSpeed ?? 50) + 0.2 * (100 - (b.patience ?? 50)));
    let intensity = 18 + 0.72 * (0.5 * (b.pressIntensity ?? 50) + 0.3 * (b.aggression ?? 50) + 0.2 * (b.counterPress ?? 50));
    const diff = gf - ga;
    if (minute < 12) {
      const k = (12 - minute) / 12; tempo += 7 * k; intensity += 8 * k;
      if (k > 0.35) drivers.push("opening");
    }
    if (diff < 0 && minute > 55) {
      const k = Math.min(1, (minute - 55) / 30) * Math.min(2, -diff);
      tempo += 9 * k; intensity += 10 * k; drivers.push("chasing");
    }
    if (diff > 0 && minute > 60) {
      const k = Math.min(1, (minute - 60) / 25); tempo -= 10 * k; intensity -= 4 * k;
      if (k > 0.2) drivers.push("managing");
    }
    if (lastConceded[key] != null && minute - lastConceded[key] < 7) {
      const k = 1 - (minute - lastConceded[key]) / 7; tempo += 8 * k; intensity += 10 * k;
      drivers.push("responding");
    }
    if (lastScored[key] != null && minute - lastScored[key] < 4) {
      const k = 1 - (minute - lastScored[key]) / 4; tempo -= 5 * k; drivers.push("settling");
    }
    const down = 11 - S.xi.length;
    if (down > 0) { tempo -= 6 * down; intensity -= 5 * down; drivers.push("shorthanded"); }
    const outfield = S.xi.filter((p, i) => S.slots[i] !== "GK");
    const cond = outfield.length ? outfield.reduce((a, p) => a + liveCondition(p, minute), 0) / outfield.length : 100;
    if (cond < 72) {
      const f = 72 - cond; intensity -= f * 0.7; tempo -= f * 0.35;
      if (cond < 60) drivers.push("tiring");
    }
    if (minute > 40 && minute < 46) { tempo += 3; intensity += 4; }
    if (minute > 84) { tempo += 3; intensity += 4; drivers.push("finalpush"); }
    return { tempo: softCap(tempo), intensity: softCap(intensity), drivers, cond: Math.round(cond) };
  }

  // ── Set pieces ──
  // Dead balls decide who restarts, and corners and free kicks are taken
  // properly: the specialist delivers, the best in the air attack it, the
  // keeper and defenders contest it — all from the players' own attributes.
  let restart = null;                  // { team, kind, zone?, side? } — who restarts the next possession
  const otherKey = (k) => (k === "home" ? "away" : "home");
  const attrOf = (p, k) => p?.detailed?.[k] ?? 50;
  const aerialOf = (p) => attrOf(p, "headingAccuracy") * 0.45 + attrOf(p, "jumping") * 0.3 + attrOf(p, "strength") * 0.25;
  const outfieldOf = (key) => { const S = sides[key]; return S.xi.filter((p, i) => S.slots[i] !== "GK"); };
  const keeperFor = (key) => { const S = sides[key]; const i = S.slots.indexOf("GK"); return i >= 0 ? S.xi[i] : null; };
  const slotOf = (key, p) => sides[key].slots[sides[key].xi.indexOf(p)] || "";
  const bestBy = (list, f) => list.reduce((b, p) => (!b || f(p) > f(b) ? p : b), null);
  const sideRoll = () => (Math.random() < 0.5 ? "left" : "right");

  // A shot from a set piece — a header from a delivery or a direct free kick —
  // resolved on the same principles as open play, with the right skill for it.
  function setPieceShot(attKey, shooter, xg, kind, minute, ctx, assister) {
    const isH = attKey === "home";
    const defKey = otherKey(attKey);
    const colour = isH ? "#00e5ff" : "#ff6b6b";
    const skill = kind === "header"
      ? attrOf(shooter, "headingAccuracy") * 0.6 + attrOf(shooter, "jumping") * 0.2 + attrOf(shooter, "composure") * 0.2
      : attrOf(shooter, "fkAccuracy") * 0.55 + attrOf(shooter, "curve") * 0.25 + attrOf(shooter, "shotPower") * 0.2;
    stats[shooter.id].shots += 1;
    stats[shooter.id].xg += xg;
    if (isH) { homeShots++; homeXg += xg; } else { awayShots++; awayXg += xg; }
    const frame = { attKey, phase: 3, carrierId: shooter.id, xg, power: attrOf(shooter, "shotPower"), setPiece: kind, ctx };
    const onTarget = Math.max(0.15, Math.min(0.8, 0.22 + (skill - 40) / 140));
    if (Math.random() > onTarget) {
      if (Math.random() < (kind === "freekick" ? 0.45 : 0.25)) {
        const wall = kind === "freekick" && ctx?.wallIds?.length ? ctx.wallIds : null;
        const blocker = wall
          ? sides[defKey].xi.find((p) => p.id === wall[Math.floor(Math.random() * wall.length)])
          : pickWeighted(outfieldOf(defKey), ["defAwareness", "jumping"]);
        if (blocker) stats[blocker.id].duelsWon += 1;
        playSeq.push({ ...frame, outcome: "block", blockerId: blocker?.id });
        events.push({ min: claimMinute(minute), type: "block", team: attKey, icon: "🧱",
          text: kind === "freekick" ? `${shooter.lastName}'s free kick smacks into the wall` : `${shooter.lastName}'s header is blocked`,
          color: colour, sd: { team: attKey, shot: 1, sot: 0, xg } });
        return Math.random() < 0.35 ? "corner" : "loose";
      }
      playSeq.push({ ...frame, outcome: "miss" });
      events.push({ min: claimMinute(minute), type: "miss", team: attKey, icon: "💨",
        text: kind === "freekick" ? `${shooter.lastName}'s free kick flies past the post` : `${shooter.lastName} heads it wide`,
        color: "#64748b", sd: { team: attKey, shot: 1, sot: 0, xg } });
      return "miss";
    }
    stats[shooter.id].shotsOnTarget += 1;
    if (isH) homeSOT++; else awaySOT++;
    const keeper = keeperFor(defKey);
    const gkSkill = attrOf(keeper, "reactions") * 0.5 + attrOf(keeper, "composure") * 0.25 + attrOf(keeper, "jumping") * 0.25;
    const convert = Math.max(0.04, Math.min(0.85, (xg / onTarget) * (0.66 + (skill - gkSkill) / 240)));
    if (Math.random() < convert) {
      if (isH) homeGoals++; else awayGoals++;
      stats[shooter.id].goals += 1;
      if (assister && assister.id !== shooter.id) stats[assister.id].assists += 1;
      playSeq.push({ ...frame, outcome: "goal", keeperId: keeper?.id });
      events.push({ min: claimMinute(minute), type: "goal", team: attKey, icon: "⚽", setPiece: kind,
        text: kind === "freekick"
          ? `GOAL! ${shooter.firstName} ${shooter.lastName} curls the free kick in! (${xg.toFixed(2)} xG)`
          : `GOAL! ${shooter.firstName} ${shooter.lastName} heads it in${assister && assister.id !== shooter.id ? ` from ${assister.lastName}'s delivery` : ""} (${xg.toFixed(2)} xG)`,
        color: colour, sd: { team: attKey, shot: 1, sot: 1, xg } });
      return "goal";
    }
    if (keeper) stats[keeper.id].saves += 1;
    const held = Math.random() < (kind === "header" ? 0.55 : 0.4);
    playSeq.push({ ...frame, outcome: "save", keeperId: keeper?.id, held });
    events.push({ min: claimMinute(minute), type: "save", team: attKey, icon: "🧤",
      text: `${keeper ? keeper.lastName : "The keeper"} ${held ? "holds" : "tips away"} ${shooter.lastName}'s ${kind === "freekick" ? "free kick" : "header"} (${xg.toFixed(2)} xG)`,
      color: colour, sd: { team: attKey, shot: 1, sot: 1, xg } });
    if (held) return "held";
    return Math.random() < 0.45 ? "corner" : "loose";
  }

  // What follows a shot: kick-off, a goal kick, the keeper's ball, or a corner
  function afterShot(result, attKey, minute, depth = 0) {
    const defKey = otherKey(attKey);
    if (result === "goal") restart = { team: defKey, kind: "kickoff" };
    else if (result === "miss") restart = { team: defKey, kind: "goalKick" };
    else if (result === "held") restart = { team: defKey, kind: "keeperBall" };
    else if (result === "corner" && depth < 1) takeCorner(attKey, minute, depth + 1);
  }

  // A corner — or a free kick swung in from wide. The best crosser delivers,
  // the best in the air attack it, the keeper may come and claim it, and the
  // defence's best header contests it.
  function takeCorner(attKey, minute, depth = 0, fromFk = null) {
    const defKey = otherKey(attKey);
    const isH = attKey === "home";
    const out = outfieldOf(attKey), dOut = outfieldOf(defKey);
    if (out.length < 2 || !dOut.length) return;
    const kind = fromFk ? "fkcross" : "corner";
    if (!fromFk) { if (isH) homeCorners++; else awayCorners++; }
    const taker = fromFk?.taker || bestBy(out, (p) => attrOf(p, "crossing") * 0.6 + attrOf(p, "curve") * 0.4);
    const box = out.filter((p) => p.id !== taker.id).sort((a, b) => aerialOf(b) - aerialOf(a)).slice(0, 5);
    if (!box.length) return;
    const target = pickWeighted(box, ["headingAccuracy", "jumping", "strength"]) || box[0];
    const marker = pickWeighted([...dOut].sort((a, b) => aerialOf(b) - aerialOf(a)).slice(0, 4), ["headingAccuracy", "jumping", "strength"]) || dOut[0];
    const keeper = keeperFor(defKey);
    const side = fromFk ? (fromFk.lat < 0 ? "left" : "right") : sideRoll();
    const delivery = attrOf(taker, "crossing") * 0.6 + attrOf(taker, "curve") * 0.4;
    const ctx = { kind, side, takerId: taker.id, targetId: target.id, markerId: marker.id, keeperId: keeper?.id,
      boxIds: box.map((p) => p.id), spot: fromFk ? { d: fromFk.d, lat: fromFk.lat } : null };
    playSeq.push({ attKey, phase: 2, setPiece: kind, stage: "setup", carrierId: taker.id, ctx });
    if (!fromFk) events.push({ min: claimMinute(minute), type: "corner", team: attKey, icon: "🚩",
      text: `Corner — ${taker.lastName} to deliver`, color: isH ? "#00e5ff" : "#ff6b6b", sd: { team: attKey, corner: 1 } });

    // The keeper comes for it
    const gkReach = keeper ? attrOf(keeper, "jumping") * 0.5 + attrOf(keeper, "reactions") * 0.5 : 40;
    if (keeper && Math.random() < Math.max(0.04, Math.min(0.24, 0.11 + (gkReach - delivery) / 300))) {
      playSeq.push({ attKey, phase: 2, setPiece: kind, stage: "delivery", result: "claimed", carrierId: keeper.id, ctx });
      restart = { team: defKey, kind: "keeperBall" };
      return;
    }
    // In the air: attacker against marker, helped by the quality of the ball in
    const edge = (aerialOf(target) - aerialOf(marker)) / 16 + (delivery - 60) / 45;
    if (Math.random() > Math.max(0.15, Math.min(0.75, 0.42 + edge * 0.12))) {
      stats[marker.id].duelsWon += 1;
      playSeq.push({ attKey, phase: 2, setPiece: kind, stage: "delivery", result: "cleared", carrierId: marker.id, ctx });
      if (Math.random() < 0.3) restart = { team: attKey, kind: "throwIn", zone: "attacking", side: sideRoll() };
      return;
    }
    stats[target.id].duelsWon += 1;
    playSeq.push({ attKey, phase: 2, setPiece: kind, stage: "delivery", result: "header", carrierId: target.id, ctx });
    const xg = Math.max(0.03, Math.min(0.22, 0.07 + (aerialOf(target) - 60) / 380 + (delivery - 60) / 600));
    afterShot(setPieceShot(attKey, target, xg, "header", minute, ctx, taker), attKey, minute, depth);
  }

  let clock = 1;
  let ballDead = true;          // kick-off counts as a stoppage
  let lastSeen = 0;
  let pendingOrder = null;
  // Every stage the ball passed through during the last passage of play, in
  // order, so the watcher can follow the move instead of seeing only where it
  // ended up. phase: 0 build-up · 1 progression · 2 final third · 3 shooting
  let playSeq = [];

  for (let seq = 0; clock < 90 && seq < 400; seq++, clock += nextStep) {
    const minute = clock;

    // Work out whether play stopped during the previous possession
    const sinceLast = events.slice(lastSeen);
    lastSeen = events.length;
    // No stopping event means play simply flowed on (a turnover, a tackle,
    // a move that broke down) — so the ball is live and orders must wait.
    ballDead = sinceLast.some((e) => DEAD_BALL_TYPES.has(e.type)) || restart !== null;

    // What just happened raises the temperature; it cools off over time
    heat *= 0.82;
    sinceLast.forEach((e) => {
      if (e.type === "goal") {
        heat += 8;
        lastScored[e.team] = minute;
        lastConceded[e.team === "home" ? "away" : "home"] = minute;
      } else if (e.type === "red") heat += 14;
      else if (e.type === "yellow") heat += 7;
      else if (e.type === "miss" || e.type === "save") heat += 2;
      else if (e.type === "tackle" || e.type === "turnover") heat += 1.5;
    });
    const foulsNow = homeFouls + awayFouls;
    heat += (foulsNow - foulsSeen) * 3;
    foulsSeen = foulsNow;

    // Read the match's tempo and intensity right now
    const ph = sidePulse("home", minute, homeGoals, awayGoals);
    const pa = sidePulse("away", minute, awayGoals, homeGoals);
    const waveT = 4.5 * Math.sin(minute / 6.5 + waveSeed) + 2.5 * Math.sin(minute / 2.7 + waveSeed * 1.7);
    const waveI = 4 * Math.sin(minute / 5.3 + waveSeed * 0.6) + 2.5 * Math.sin(minute / 2.2 + waveSeed * 2.3);
    const tempoNow = softCap(0.5 * (ph.tempo + pa.tempo) + waveT);
    const intensityNow = softCap(0.5 * (ph.intensity + pa.intensity) + waveI + heat);
    curIntensity = intensityNow;
    pulse.push({
      min: Math.round(minute * 10) / 10,
      tempo: Math.round(tempoNow), intensity: Math.round(intensityNow), heat: Math.round(heat),
      home: { tempo: Math.round(ph.tempo), intensity: Math.round(ph.intensity), cond: ph.cond, drivers: ph.drivers },
      away: { tempo: Math.round(pa.tempo), intensity: Math.round(pa.intensity), cond: pa.cond, drivers: pa.drivers },
    });

    // ── Pause point ── the caller sees the live state and may send an order
    const incoming = yield {
      minute: Math.round(minute), seq, events, homeGoals, awayGoals, ballDead,
      sides, minutes, enteredAt, liveCondition, playSeq, pulse,
    };
    playSeq = [];   // start collecting this possession's move
    if (incoming) pendingOrder = incoming;
    if (pendingOrder && ballDead) {
      applyManagerOrder(pendingOrder, minute);
      pendingOrder = null;
      ballDead = false;
    }

    // Managers get their chance to change the game before this possession
    SUB_WINDOWS.forEach((w) => {
      if (minute >= w && !windowsUsed.has(w)) {
        windowsUsed.add(w);
        considerShape("home", minute, homeGoals, awayGoals);
        considerShape("away", minute, awayGoals, homeGoals);
        considerSubs("home", minute, homeGoals, awayGoals);
        considerSubs("away", minute, awayGoals, homeGoals);
      }
    });

    const lastPulse = pulse[pulse.length - 1];
    nextStep = BASE_STEP * Math.max(0.6, Math.min(1.4, 1 + (TEMPO_REF - lastPulse.tempo) / 110));
    // Each team tires at its own work rate: a side pressing all over the pitch
    // empties its legs faster than one sitting in a low block.
    const loadRate = (i) => LOAD_BASE + i / 180;
    sides.home.xi.forEach((p) => { load[p.id] = (load[p.id] || 0) + nextStep * loadRate(lastPulse.home.intensity); });
    sides.away.xi.forEach((p) => { load[p.id] = (load[p.id] || 0) + nextStep * loadRate(lastPulse.away.intensity); });

    const rs = restart;
    restart = null;
    const isHome = rs ? rs.team === "home" : Math.random() < currentPossShare();
    totalPossCount++;
    if (isHome) homePossCount++;
    // Sample the running possession figure a few times a match
    if (seq % 6 === 0) {
      possTimeline.push({
        min: Math.round(minute),
        homePct: Math.round((homePossCount / Math.max(1, totalPossCount)) * 100),
      });
    }

    const ATT = isHome ? H : A;
    const DEF = isHome ? A : H;
    const attTeam = isHome ? home : away;
    const attKey = isHome ? "home" : "away";
    const colour = isHome ? "#00e5ff" : "#ff6b6b";

    // Late-game fatigue from the tactic
    const lateFactor = minute > 65
      ? 1 - (1 - (TACTICS[attTeam.tacticKey]?.lateGameDecay ?? 1)) * ((minute - 65) / 25)
      : 1;

    // ── The restart ── throw-in, goal kick, the keeper's release, kick-off
    let skipBuild = false;
    if (rs) {
      const defKey = otherKey(attKey);
      const outf = outfieldOf(attKey);
      let takerId = null, long = false;
      if (rs.kind === "goalKick" || rs.kind === "keeperBall") takerId = keeperFor(attKey)?.id;
      else if (rs.kind === "kickoff") takerId = (outf.find((p) => /ST|CF/.test(slotOf(attKey, p))) || outf[outf.length - 1])?.id;
      else if (rs.kind === "throwIn") {
        const wing = rs.side === "left" ? /^L/ : /^R/;
        takerId = (outf.find((p) => wing.test(slotOf(attKey, p)) && /B$|WB$/.test(slotOf(attKey, p))) || outf.find((p) => wing.test(slotOf(attKey, p))) || outf[0])?.id;
      }
      if (rs.kind === "goalKick") long = Math.random() < Math.max(0.15, Math.min(0.85, 0.1 + (ATT.b.directness ?? 50) / 100 * 0.7));
      if (takerId) playSeq.push({ attKey, phase: 0, carrierId: takerId, restart: rs.kind, zone: rs.zone, side: rs.side, long });
      if (rs.kind === "throwIn" && rs.zone === "attacking") skipBuild = true;
      if (rs.kind === "goalKick" && long) {
        // A long kick is fought for in the air around halfway
        const topAir = (key) => outfieldOf(key).map(aerialOf).sort((a, b) => b - a).slice(0, 3);
        const aAir = topAir(attKey).reduce((a, b) => a + b, 0) / 3, dAir = topAir(defKey).reduce((a, b) => a + b, 0) / 3;
        if (Math.random() > Math.max(0.3, Math.min(0.7, 0.5 + (aAir - dAir) / 80))) {
          const winner = pickWeighted([...outfieldOf(defKey)].sort((a, b) => aerialOf(b) - aerialOf(a)).slice(0, 3), ["headingAccuracy", "jumping"]);
          if (winner) {
            stats[winner.id].duelsWon += 1;
            playSeq.push({ attKey: defKey, phase: 1, carrierId: winner.id, won: { from: takerId }, header: true });
          }
          continue;
        }
        skipBuild = true;
      }
    }

    // ── PHASE 1: BUILD-UP ── beat the opponent's press
    if (!skipBuild) {
    const buildProb = contest(ATT.buildup * lateFactor, DEF.pressing * 0.95, 0.026, 0.80, 0.38);
    const passer = pickWeighted([...ATT.groups.def, ...ATT.groups.dm], ["shortPassing", "composure"]);
    if (passer) playSeq.push({ attKey, phase: 0, carrierId: passer.id });
    if (passer) { stats[passer.id].passes += 1; }
    if (Math.random() > buildProb) {
      // Turnover deep in the attacking team's own half — prime counter territory
      const winner = pickWeighted([...DEF.groups.att, ...DEF.groups.mid], ["interceptions", "aggression"]);
      if (winner) { stats[winner.id].interceptions += 1; stats[winner.id].duelsWon += 1; }
      // For the map: the presser closes in on the man in possession, then has it
      if (passer && winner) {
        playSeq.push({ attKey, phase: 0, carrierId: passer.id, duel: { by: winner.id, kind: "press" } });
        playSeq.push({ attKey: attKey === "home" ? "away" : "home", phase: 2, carrierId: winner.id, won: { from: passer.id } });
      }
      if (Math.random() < 0.12) {
        events.push({ min: claimMinute(minute), type: "turnover", team: attKey === "home" ? "away" : "home", icon: "🔁",
          text: `${winner ? winner.lastName : "Opponent"} wins it high up the pitch`, color: attKey === "home" ? "#ff6b6b" : "#00e5ff" });
      }
      // The team that won it can break immediately
      tryTransition(DEF, ATT, !isHome, minute, 1.0);
      continue;
    }
    if (passer) stats[passer.id].passesCompleted += 1;
    }

    // ── PHASE 2: PROGRESSION ── move it into midfield/attacking half
    const progProb = contest(ATT.progression * lateFactor, DEF.defBlock * 0.92, 0.026, 0.74, 0.44);
    const carrier = pickWeighted([...ATT.groups.mid, ...ATT.groups.wide], ["ballControl", "vision", "dribbling"]);
    if (carrier) playSeq.push({ attKey, phase: 1, carrierId: carrier.id });
    if (carrier) stats[carrier.id].passes += 1;
    if (Math.random() > progProb) {
      const stopper = pickWeighted([...DEF.groups.dm, ...DEF.groups.def], ["standingTackle", "interceptions"]);
      if (stopper) { stats[stopper.id].tackles += 1; stats[stopper.id].duelsWon += 1; }
      if (carrier && stopper) {
        playSeq.push({ attKey, phase: 1, carrierId: carrier.id, duel: { by: stopper.id, kind: "tackle" } });
        playSeq.push({ attKey: attKey === "home" ? "away" : "home", phase: 1, carrierId: stopper.id, won: { from: carrier.id } });
      }
      if (Math.random() < 0.10) {
        events.push({ min: claimMinute(minute), type: "tackle", team: attKey === "home" ? "away" : "home", icon: "🦶",
          text: `Strong challenge by ${stopper ? stopper.lastName : "the defence"} ends the move`, color: attKey === "home" ? "#ff6b6b" : "#00e5ff" });
      }
      // Ball won in midfield — a slightly less dangerous break
      tryTransition(DEF, ATT, !isHome, minute, 0.72);
      continue;
    }
    if (carrier) stats[carrier.id].passesCompleted += 1;

    // Fouls happen during progression
    if (Math.random() < 0.10 * (DEF.b.aggression / 55) * (0.55 + curIntensity / 145)) {
      const fouler = pickWeighted([...DEF.groups.dm, ...DEF.groups.def], ["aggression", "slidingTackle"]);
      const foulFrame = carrier && fouler ? { attKey, phase: 1, carrierId: carrier.id, duel: { by: fouler.id, kind: "foul" } } : null;
      if (foulFrame) playSeq.push(foulFrame);
      if (isHome) awayFouls++; else homeFouls++;
      if (Math.random() < 0.22 && fouler) {
        const card = Math.random() < 0.09 ? "red" : "yellow";
        if (foulFrame) foulFrame.duel.card = card;
        const offKey = attKey === "home" ? "away" : "home";
        events.push({ min: claimMinute(minute), type: card, team: offKey,
          icon: card === "red" ? "🟥" : "🟨",
          text: `${card === "red" ? "RED CARD! " : ""}${fouler.lastName} goes into the book`,
          color: card === "red" ? "#ff2040" : "#ffa800" });
        // Actually send him off: removed from the eleven, profile rebuilt
        if (card === "red") sendOff(offKey, fouler, minute);
      }

      // ── The free kick ── in range, out wide, or taken quickly
      const fkRoll = Math.random();
      if (fkRoll < 0.13) {
        const defKey = otherKey(attKey);
        const taker = bestBy(outfieldOf(attKey), (p) => attrOf(p, "fkAccuracy") * 0.6 + attrOf(p, "curve") * 0.25 + attrOf(p, "shotPower") * 0.15);
        const d = 17 + Math.random() * 9, lat = (Math.random() - 0.5) * 26;
        const wall = [...outfieldOf(defKey)].sort(() => Math.random() - 0.5).slice(0, 3 + Math.floor(Math.random() * 3));
        const ctx = { kind: "freekick", takerId: taker.id, spot: { d, lat }, wallIds: wall.map((p) => p.id), keeperId: keeperFor(defKey)?.id };
        playSeq.push({ attKey, phase: 3, setPiece: "freekick", stage: "setup", carrierId: taker.id, ctx });
        events.push({ min: claimMinute(minute), type: "freekick", team: attKey, icon: "🎯",
          text: `Free kick in shooting range — ${taker.lastName} stands over it`, color: colour });
        const fkSkill = attrOf(taker, "fkAccuracy") * 0.6 + attrOf(taker, "curve") * 0.4;
        const xg = Math.max(0.02, Math.min(0.14, 0.075 + (fkSkill - 65) / 500 - (d - 20) / 250 - Math.abs(lat) / 600));
        afterShot(setPieceShot(attKey, taker, xg, "freekick", minute, ctx, null), attKey, minute, 0);
        continue;
      }
      if (fkRoll < 0.36) {
        const taker = bestBy(outfieldOf(attKey), (p) => attrOf(p, "crossing") * 0.6 + attrOf(p, "curve") * 0.4);
        const lat = (Math.random() < 0.5 ? -1 : 1) * (18 + Math.random() * 16), d = 16 + Math.random() * 14;
        events.push({ min: claimMinute(minute), type: "freekick", team: attKey, icon: "🎯",
          text: `Free kick out wide — ${taker.lastName} to swing it in`, color: colour });
        takeCorner(attKey, minute, 0, { taker, d, lat });
        continue;
      }
      if (carrier) playSeq.push({ attKey, phase: 1, setPiece: "freekick", stage: "quick", carrierId: carrier.id });
    }

    // ── PHASE 3: FINAL THIRD ENTRY ──
    const entryProb = contest(ATT.finalThird * lateFactor, DEF.defBlock, 0.026, 0.60, 0.48);
    if (Math.random() > entryProb) {
      const r = Math.random();
      if (r < 0.22) takeCorner(attKey, minute);                                                        // off a defender
      else if (r < 0.34) restart = { team: attKey, kind: "throwIn", zone: "attacking", side: sideRoll() };            // cleared into touch
      else if (r < 0.52) restart = { team: otherKey(attKey), kind: "throwIn", zone: "defending", side: sideRoll() };  // overhit
      else if (r < 0.63) restart = { team: otherKey(attKey), kind: "goalKick" };                        // runs out over the byline
      continue;
    }

    // ── PHASE 4: CHANCE CREATION ──
    const creator = pickWeighted([...ATT.groups.mid, ...ATT.groups.wide, ...ATT.groups.att], ["vision", "crossing", "shortPassing"]);
    if (creator) playSeq.push({ attKey, phase: 2, carrierId: creator.id });
    const createProb = contest(ATT.chanceQuality, DEF.defBlock * 1.02, 0.024, 0.47, 0.44);
    if (Math.random() > createProb) {
      const r = Math.random();
      if (r < 0.14) restart = { team: otherKey(attKey), kind: "goalKick" };
      else if (r < 0.28) restart = { team: otherKey(attKey), kind: "throwIn", zone: "defending", side: sideRoll() };
      continue;
    }

    // ── PHASE 5: CHANCE QUALITY → xG ──
    const shooter = pickWeighted(ATT.groups.att.length ? ATT.groups.att : ATT.groups.mid,
      ["attackPositioning", "finishing", "composure"]);
    if (!shooter) continue;
    const shotFrame = { attKey, phase: 3, carrierId: shooter.id };
    playSeq.push(shotFrame);

    const sd = shooter.detailed || {};
    const positioning = sd.attackPositioning ?? 50;
    const creatorVision = creator ? (creator.detailed?.vision ?? 50) : 50;
    // Base xG from chance quality, shaped by creator vision and shooter positioning
    let xg = 0.05 + (creatorVision / 100) * 0.11 + (positioning / 100) * 0.10;
    // Patient build-up creates better chances; direct play creates more but worse
    xg *= 0.86 + (ATT.b.patience / 100) * 0.28;
    // A packed defence lowers chance quality
    xg *= Math.max(0.45, 1 - (DEF.defBlock - 50) / 220);
    xg = Math.max(0.02, Math.min(0.72, xg));
    // For the map: how good the chance is decides where it's struck from
    shotFrame.xg = xg;
    shotFrame.power = sd.shotPower ?? 55;

    stats[shooter.id].shots += 1;
    stats[shooter.id].xg += xg;
    if (isHome) { homeShots++; homeXg += xg; } else { awayShots++; awayXg += xg; }
    if (creator && creator.id !== shooter.id) stats[creator.id].keyPasses += 1;

    // ── PHASE 6: THE SHOT ── finishing vs chance difficulty
    const finishSkill = ((sd.finishing ?? 50) * 0.5 + (sd.composure ?? 50) * 0.25 + (sd.shotPower ?? 50) * 0.25);
    const onTargetProb = Math.max(0.18, Math.min(0.88, 0.28 + (finishSkill - 40) / 130));

    if (Math.random() > onTargetProb) {
      // Off target or blocked
      if (Math.random() < 0.42) {
        const blocker = pickWeighted(DEF.groups.def, ["defAwareness", "jumping"]);
        if (blocker) stats[blocker.id].duelsWon += 1;
        playSeq.push({ attKey, phase: 3, carrierId: shooter.id, xg, power: sd.shotPower ?? 55, outcome: "block", blockerId: blocker?.id });
        events.push({ min: claimMinute(minute), type: "block", team: attKey, icon: "🧱",
          text: `${shooter.lastName}'s shot is blocked by ${blocker ? blocker.lastName : "a body in the way"}`, color: colour,
          sd: { team: attKey, shot: 1, sot: 0, xg } });
        if (Math.random() < 0.35) takeCorner(attKey, minute);                 // deflected behind
      } else {
        playSeq.push({ attKey, phase: 3, carrierId: shooter.id, xg, power: sd.shotPower ?? 55, outcome: "miss" });
        events.push({ min: claimMinute(minute), type: "miss", team: attKey, icon: "💨",
          text: `${shooter.lastName} drags it wide (${xg.toFixed(2)} xG)`, color: "#64748b",
          sd: { team: attKey, shot: 1, sot: 0, xg } });
        restart = { team: otherKey(attKey), kind: "goalKick" };
      }
      continue;
    }

    stats[shooter.id].shotsOnTarget += 1;
    if (isHome) homeSOT++; else awaySOT++;

    // ── PHASE 7: GOALKEEPER ──
    const keeper = DEF.groups.gk[0];
    const kd = keeper?.detailed || {};
    const gkSkill = ((kd.reactions ?? 50) * 0.5 + (kd.composure ?? 50) * 0.25 + (kd.jumping ?? 50) * 0.25);
    // Conversion: xG is the baseline, then shooter quality vs keeper quality shifts it
    // On-target shots convert at roughly xG, adjusted by finisher vs keeper
    let convertProb = (xg / Math.max(0.05, onTargetProb)) * (0.66 + (finishSkill - gkSkill) / 240) * OPEN_PLAY_FINISH;
    convertProb = Math.max(0.04, Math.min(0.85, convertProb));

    if (Math.random() < convertProb) {
      // GOAL
      restart = { team: otherKey(attKey), kind: "kickoff" };
      if (isHome) homeGoals++; else awayGoals++;
      stats[shooter.id].goals += 1;
      if (creator && creator.id !== shooter.id) stats[creator.id].assists += 1;
      playSeq.push({ attKey, phase: 3, carrierId: shooter.id, xg, power: sd.shotPower ?? 55, outcome: "goal", keeperId: keeper?.id });
      events.push({ min: claimMinute(minute), type: "goal", team: attKey, icon: "⚽",
        text: `GOAL! ${shooter.firstName} ${shooter.lastName} finishes it${creator && creator.id !== shooter.id ? ` — assist ${creator.lastName}` : ""} (${xg.toFixed(2)} xG)`,
        color: colour, sd: { team: attKey, shot: 1, sot: 1, xg } });
    } else {
      if (keeper) stats[keeper.id].saves += 1;
      const held = Math.random() < 0.45;
      playSeq.push({ attKey, phase: 3, carrierId: shooter.id, xg, power: sd.shotPower ?? 55, outcome: "save", keeperId: keeper?.id, held });
      events.push({ min: claimMinute(minute), type: "save", team: attKey, icon: "🧤",
        text: `${keeper ? keeper.lastName : "The keeper"} saves from ${shooter.lastName} (${xg.toFixed(2)} xG)`, color: colour,
        sd: { team: attKey, shot: 1, sot: 1, xg } });
      if (held) restart = { team: otherKey(attKey), kind: "keeperBall" };
      else if (Math.random() < 0.45) takeCorner(attKey, minute);          // tipped round the post
    }
  }

  // ── Player ratings ──
  function rate(player, isHomeSide, minsPlayed) {
    const s = stats[player.id];
    if (!s) return 6.0;
    // A ten-minute cameo shouldn't carry the same share of the result as a
    // player who was out there for the whole ninety.
    const share = Math.max(0.25, Math.min(1, (minsPlayed ?? 90) / 90));
    let r = 6.0;
    r += s.goals * 1.15;
    r += s.assists * 0.75;
    r += s.keyPasses * 0.16;
    r += s.shotsOnTarget * 0.10;
    r += s.tackles * 0.13;
    r += s.interceptions * 0.11;
    r += s.saves * 0.22;
    const passAcc = s.passes > 0 ? s.passesCompleted / s.passes : 1;
    r += (passAcc - 0.75) * 1.2;
    // Team result nudge
    const gf = isHomeSide ? homeGoals : awayGoals;
    const ga = isHomeSide ? awayGoals : homeGoals;
    r += (gf - ga) * 0.14 * share;
    // Keeper conceding hurts
    if ((player.naturalPosition === "GK") && ga > 0) r -= ga * 0.28;
    // Fitness drag
    r -= (100 - (player.fitness ?? 100)) / 240;
    return Math.max(3.0, Math.min(10.0, r));
  }

  // Everyone who set foot on the pitch gets rated — a substitute who scores
  // the winner previously finished the match with no rating at all.
  [...home.squad, ...(home.bench || [])].forEach((p) => {
    if (stats[p.id] && (minutes[p.id] || 0) > 0) stats[p.id].rating = rate(p, true, minutes[p.id]);
  });
  [...away.squad, ...(away.bench || [])].forEach((p) => {
    if (stats[p.id] && (minutes[p.id] || 0) > 0) stats[p.id].rating = rate(p, false, minutes[p.id]);
  });

  // ── Whistles ──
  events.push({ min: 0, type: "whistle", team: "none", icon: "📣", text: "Kick off!", color: "#e2e8f0" });
  events.push({ min: 45, type: "whistle", team: "none", icon: "⏱️", text: "Half time!", color: "#e2e8f0" });
  events.push({ min: 91, type: "whistle", team: "none", icon: "📣", text: "Full time!", color: "#e2e8f0" });
  events.sort((a, b) => a.min - b.min);

  // Everyone still on the pitch at the whistle banks the rest of their minutes
  Object.keys(enteredAt).forEach((id) => {
    minutes[id] = (minutes[id] || 0) + Math.max(0, Math.round(90 - (enteredAt[id] ?? 0)));
  });

  return {
    events, homeGoals, awayGoals, stats,
    minutes,
    subs: { home: sides.home.subs, away: sides.away.subs },
    sentOff: { home: sides.home.sentOff, away: sides.away.sentOff },
    finalXI: { home: sides.home.xi.length, away: sides.away.xi.length },
    pulse,
    possTimeline,
    matchStats: {
      possession: Math.round((homePossCount / Math.max(1, totalPossCount)) * 100),
      homeShots, awayShots, homeSOT, awaySOT,
      homeXg: Number(homeXg.toFixed(2)), awayXg: Number(awayXg.toFixed(2)),
      homeCorners, awayCorners, homeFouls, awayFouls,
    },
  };
}


/* ═══════════════════════════════════════════════════════════════════════
   COMPONENTS (Pitch card, Bench card, etc.)
   ═══════════════════════════════════════════════════════════════════════ */

function PitchCard({ player, slotPos, onClick, isSelected, onDragStart, onDrop }) {
  const status = getSlotStatus(player, slotPos);
  const eff = getEffectiveOvr(player, slotPos);
  const ts = TIER_STYLES[getTier(player.ovr)]; // Card color = ALWAYS base OVR
  const fitColor = getFitnessColor(player.fitness ?? 100);

  return (
    <div draggable onDragStart={onDragStart} onDragOver={(e) => e.preventDefault()} onDrop={onDrop} onClick={onClick}
      style={{ position: "relative", cursor: "grab", userSelect: "none", transform: isSelected ? "scale(1.12)" : "scale(1)", transition: "transform 0.15s", filter: isSelected ? `drop-shadow(0 0 12px ${N.cyan})` : "drop-shadow(0 2px 5px rgba(0,0,0,0.5))" }}>
      {status.status !== "natural" && status.status !== "alt" && !player.injuredFor && (
        <div style={{ position: "absolute", top: -6, right: -6, zIndex: 30, width: 18, height: 18, borderRadius: "50%", background: status.status === "yellow" ? "#ffa800" : "#ff2040", border: "2px solid #0a0e1a", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 900, color: "#fff", lineHeight: 1 }}>!</div>
      )}
      {player.injuredFor > 0 && (
        <div style={{ position: "absolute", top: -6, right: -6, zIndex: 30, width: 18, height: 18, borderRadius: "50%", background: "#ff2040", border: "2px solid #0a0e1a", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9 }}>🏥</div>
      )}
      <div style={{ width: 56, height: 74, background: ts.bg, borderRadius: 6, border: `1.5px solid ${isSelected ? N.cyan : ts.border + "60"}`, overflow: "hidden", position: "relative", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 1, padding: 3 }}>
        <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 2, background: ts.headerBg, opacity: 0.9 }} />
        <div style={{ display: "flex", alignItems: "baseline", gap: 1, justifyContent: "center" }}>
          <span style={{ fontSize: 22, fontWeight: 900, color: ts.text, lineHeight: 1 }}>{eff}</span>
          {status.penalty > 0 && <span style={{ fontSize: 9, fontWeight: 800, lineHeight: 1, color: status.status === "yellow" ? "#ffa800" : "#ff4060" }}>-{status.penalty}</span>}
        </div>
        <span style={{ fontSize: 7.5, fontWeight: 800, color: ts.statLabel, lineHeight: 1 }}>{slotPos}</span>
        <div style={{ width: "75%", height: 0.5, background: `${ts.accent}50`, margin: "1px 0" }} />
        <span style={{ fontSize: 6.5, fontWeight: 700, color: ts.text, lineHeight: 1, maxWidth: "100%", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", padding: "0 2px" }}>{player.lastName}</span>
        <div style={{ width: "80%", height: 2, background: `${ts.text}20`, borderRadius: 1, marginTop: 1 }}>
          <div style={{ width: `${player.fitness ?? 100}%`, height: "100%", background: fitColor, borderRadius: 1 }} />
        </div>
      </div>
    </div>
  );
}

function BenchCard({ player, onClick, isSelected, onDragStart, onDrop }) {
  const ts = TIER_STYLES[getTier(player.ovr)];
  const fitColor = getFitnessColor(player.fitness ?? 100);
  return (
    <div draggable onDragStart={onDragStart} onDragOver={(e) => e.preventDefault()} onDrop={onDrop} onClick={onClick}
      style={{ cursor: "grab", userSelect: "none", transform: isSelected ? "scale(1.1)" : "scale(1)", transition: "transform 0.15s", filter: isSelected ? `drop-shadow(0 0 10px ${N.cyan})` : "drop-shadow(0 2px 4px rgba(0,0,0,0.4))" }}>
      <div style={{ width: 52, height: 70, background: ts.bg, borderRadius: 5, border: `1.5px solid ${isSelected ? N.cyan : ts.border + "60"}`, overflow: "hidden", position: "relative", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 1, padding: 3 }}>
        <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 2, background: ts.headerBg, opacity: 0.9 }} />
        <span style={{ fontSize: 18, fontWeight: 900, color: ts.text, lineHeight: 1 }}>{player.ovr}</span>
        <span style={{ fontSize: 6.5, fontWeight: 800, color: ts.statLabel, lineHeight: 1 }}>{player.naturalPosition}</span>
        <span style={{ fontSize: 6, fontWeight: 700, color: ts.text, lineHeight: 1, maxWidth: "100%", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", padding: "0 2px", marginTop: 1 }}>{player.lastName}</span>
        <div style={{ width: "80%", height: 2, background: `${ts.text}20`, borderRadius: 1, marginTop: 1 }}>
          <div style={{ width: `${player.fitness ?? 100}%`, height: "100%", background: fitColor, borderRadius: 1 }} />
        </div>
      </div>
    </div>
  );
}


function PlayerDetailModal({ player, slotPos, onClose, onRoleChange, onFocusChange, onTransferList, isListed, onSwap, otherGroup, inSquad, onBench }) {
  const tier = getTier(player.ovr);
  const s = TIER_STYLES[tier];
  const face = { PAC: player.pac, SHO: player.sho, PAS: player.pas, DRI: player.dri, DEF: player.def, PHY: player.phy };
  const faceColors = [N.cyan, N.magenta, N.green, N.gold, "#ff6b6b", "#a78bfa"];
  const posStatus = slotPos ? getSlotStatus(player, slotPos) : null;
  const eff = slotPos ? getEffectiveOvr(player, slotPos) : player.ovr;
  const [showSwapPicker, setShowSwapPicker] = useState(false);

  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 1000, background: "rgba(0,0,0,0.75)", backdropFilter: "blur(6px)", display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }} onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} style={{ width: "100%", maxWidth: 520, maxHeight: "90vh", overflowY: "auto", background: N.surface, borderRadius: 14, border: `1px solid ${N.border}` }}>
        <div style={{ padding: "20px 20px 16px", background: `linear-gradient(135deg, ${N.surface}, ${N.card})`, borderBottom: `1px solid ${N.border}`, display: "flex", gap: 20, alignItems: "flex-start", position: "relative", borderRadius: "14px 14px 0 0" }}>
          <button onClick={onClose} style={{ position: "absolute", top: 12, right: 12, background: "none", border: "none", color: N.muted, fontSize: 20, cursor: "pointer", padding: 4 }}>✕</button>
          <div style={{ width: 100, height: 132, flexShrink: 0, background: s.bg, borderRadius: 8, border: `2px solid ${s.border}60`, overflow: "hidden", position: "relative", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
            <span style={{ fontSize: 38, fontWeight: 900, color: s.text, lineHeight: 1 }}>{player.ovr}</span>
            <span style={{ fontSize: 12, fontWeight: 800, color: s.statLabel, marginTop: 2 }}>{player.naturalPosition}</span>
            <div style={{ width: "70%", height: 1, background: `${s.accent}50`, margin: "4px 0" }} />
            <span style={{ fontSize: 10, fontWeight: 800, color: s.text, textTransform: "uppercase" }}>{player.lastName}</span>
          </div>
          <div style={{ flex: 1, paddingTop: 2 }}>
            <div style={{ fontSize: 20, fontWeight: 800, color: N.text, marginBottom: 2 }}>{player.firstName} {player.lastName}</div>
            <div style={{ fontSize: 12, color: N.muted, marginBottom: 6 }}>{player.naturalPosition} · {tier.toUpperCase()} · {player.nationality}</div>
            {/* Role badge */}
            <div style={{ marginBottom: 6, display: "flex", gap: 6, flexWrap: "wrap" }}>
              <span style={{ display: "inline-block", padding: "3px 10px", borderRadius: 4, fontSize: 10, fontWeight: 700, background: `${N.cyan}18`, color: N.cyan, border: `1px solid ${N.cyan}30` }}>
                {player.role} — {player.roleLabel}
              </span>
              {(() => {
                const pot = player.potential || generatePotential(player.ovr, player.age || 25);
                const potLabel = getPotentialLabel(player.ovr, pot);
                return (
                  <span style={{ display: "inline-block", padding: "3px 10px", borderRadius: 4, fontSize: 10, fontWeight: 700, background: `${potLabel.color}18`, color: potLabel.color, border: `1px solid ${potLabel.color}30` }}>
                    {potLabel.icon} POT {pot} · {potLabel.label}
                  </span>
                );
              })()}
            </div>
            {/* Fitness bar */}
            <div style={{ marginBottom: 6 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ fontSize: 11, color: N.muted, fontWeight: 600 }}>Fitness</span>
                <div style={{ flex: 1, height: 6, background: "#1a2236", borderRadius: 3, overflow: "hidden" }}>
                  <div style={{ width: `${player.fitness ?? 100}%`, height: "100%", background: getFitnessColor(player.fitness ?? 100), borderRadius: 3 }} />
                </div>
                <span style={{ fontSize: 11, fontWeight: 800, color: getFitnessColor(player.fitness ?? 100) }}>{player.fitness ?? 100}%</span>
              </div>
            </div>
            {posStatus && posStatus.status !== "natural" && posStatus.status !== "alt" && (
              <div style={{ padding: "6px 10px", borderRadius: 6, marginBottom: 6, fontSize: 11, fontWeight: 600, background: posStatus.status === "yellow" ? "rgba(255,168,0,0.12)" : "rgba(255,32,64,0.12)", border: `1px solid ${posStatus.status === "yellow" ? "#ffa80040" : "#ff204040"}`, color: posStatus.status === "yellow" ? "#ffa800" : "#ff4060" }}>
                {posStatus.status === "yellow" ? "⚠️" : "🚫"} Playing as {slotPos} — OVR {eff} ({-posStatus.penalty})
              </div>
            )}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "4px 16px", fontSize: 12 }}>
              {[["Age", player.age], ["Foot", player.preferredFoot], ["Height", player.height + "cm"], ["Weight", player.weight + "kg"]].map(([l, v]) => (
                <div key={l} style={{ display: "flex", justifyContent: "space-between" }}>
                  <span style={{ color: N.muted }}>{l}</span><span style={{ fontWeight: 700 }}>{v}</span>
                </div>
              ))}
            </div>
            <div style={{ marginTop: 6 }}>
              <span style={{ fontSize: 11, color: N.muted, fontWeight: 600 }}>Alt. Positions: </span>
              {player.altPositions?.length > 0 ? player.altPositions.map((ap) => (
                <span key={ap} style={{ display: "inline-block", padding: "2px 8px", borderRadius: 4, fontSize: 10, fontWeight: 700, background: `${N.green}18`, color: N.green, border: `1px solid ${N.green}30`, marginRight: 4 }}>{ap}</span>
              )) : <span style={{ fontSize: 11, color: N.muted, fontStyle: "italic" }}>None</span>}
            </div>
            {(onTransferList || onSwap) && (
              <div style={{ marginTop: 10, display: "flex", flexWrap: "wrap", gap: 6 }}>
                {onTransferList && (
                  isListed ? (
                    <span style={{ fontSize: 11, fontWeight: 700, color: N.gold, alignSelf: "center" }}>📋 On the transfer list</span>
                  ) : (
                    <button onClick={() => onTransferList(player)} style={{
                      padding: "7px 12px", fontSize: 11, fontWeight: 800, borderRadius: 6,
                      background: `${N.gold}15`, border: `1px solid ${N.gold}40`, color: N.gold, cursor: "pointer",
                    }}>
                      📋 List · ${playerMarketValue(player)}
                    </button>
                  )
                )}
                {onSwap && (inSquad || onBench) && (
                  <button onClick={() => setShowSwapPicker((v) => !v)} style={{
                    padding: "7px 12px", fontSize: 11, fontWeight: 800, borderRadius: 6,
                    background: showSwapPicker ? `${N.cyan}25` : `${N.cyan}15`,
                    border: `1px solid ${N.cyan}40`, color: N.cyan, cursor: "pointer",
                  }}>
                    {inSquad ? "🔽 Move to Bench" : "🔼 Promote to XI"}
                  </button>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Swap Picker */}
        {showSwapPicker && onSwap && otherGroup && (
          <div style={{ padding: "12px 20px", borderBottom: `1px solid ${N.border}`, background: `${N.cyan}05` }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: N.cyan, marginBottom: 8 }}>
              {inSquad ? "🔽 SWAP WITH BENCH PLAYER" : "🔼 SWAP WITH STARTING XI PLAYER"}
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(88px, 1fr))", gap: 6, maxHeight: 200, overflowY: "auto" }}>
              {otherGroup.length === 0 ? (
                <div style={{ fontSize: 11, color: N.muted, gridColumn: "1 / -1", textAlign: "center", padding: 8 }}>
                  No players available to swap with.
                </div>
              ) : otherGroup.map((partner) => {
                const pts = TIER_STYLES[getTier(partner.ovr)];
                // If we're a starter moving to bench, the partner takes our slot — check if they fit it
                const targetSlot = inSquad ? slotPos : partner._slot;
                const status = targetSlot ? getSlotStatus(partner, targetSlot) : null;
                const warn = status && (status.status === "yellow" || status.status === "red");
                return (
                  <div key={partner.id} onClick={() => { onSwap(player, partner); setShowSwapPicker(false); }} style={{
                    padding: 6, borderRadius: 6, cursor: "pointer",
                    background: pts.bg, border: `1px solid ${warn ? "#ffa80080" : pts.border + "60"}`,
                    display: "flex", flexDirection: "column", alignItems: "center", gap: 2,
                    transition: "transform 0.1s",
                  }}
                    onMouseEnter={(e) => { e.currentTarget.style.transform = "scale(1.05)"; }}
                    onMouseLeave={(e) => { e.currentTarget.style.transform = "scale(1)"; }}
                  >
                    <div style={{ display: "flex", alignItems: "baseline", gap: 2 }}>
                      <span style={{ fontSize: 15, fontWeight: 900, color: pts.text, lineHeight: 1 }}>{partner.ovr}</span>
                      <span style={{ fontSize: 8, fontWeight: 800, color: pts.statLabel }}>{partner.naturalPosition}</span>
                    </div>
                    <span style={{ fontSize: 9, fontWeight: 700, color: pts.text, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: "100%" }}>
                      {partner.lastName}
                    </span>
                    {warn && <span style={{ fontSize: 8, color: "#ffa800", fontWeight: 700 }}>⚠️ Out of pos</span>}
                    {partner.injuredFor > 0 && <span style={{ fontSize: 8, color: "#ff4060", fontWeight: 700 }}>🏥 {partner.injuredFor}m</span>}
                  </div>
                );
              })}
            </div>
            <div style={{ marginTop: 8, textAlign: "center" }}>
              <button onClick={() => setShowSwapPicker(false)} style={{
                padding: "5px 12px", fontSize: 10, fontWeight: 700, borderRadius: 4,
                background: "transparent", border: `1px solid ${N.border}`, color: N.muted, cursor: "pointer",
              }}>Cancel</button>
            </div>
          </div>
        )}

        {/* Role & Focus Editor */}
        {onRoleChange && (
          <div style={{ padding: "12px 20px", borderBottom: `1px solid ${N.border}` }}>
            <div style={{ marginBottom: 10 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: N.muted, marginBottom: 6 }}>PLAYER ROLE</div>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                {getAvailableRoles(slotPos || player.naturalPosition).map((roleDef) => {
                  const isActive = (player.activeRole || player.role) === roleDef.role;
                  const isNatural = player.role === roleDef.role;
                  return (
                    <button key={roleDef.role} onClick={() => onRoleChange(player.id, roleDef.role)} style={{
                      padding: "6px 10px", fontSize: 10, fontWeight: 700, borderRadius: 6, cursor: "pointer",
                      textAlign: "left", display: "block", width: "100%",
                      background: isActive ? `${N.cyan}20` : N.card,
                      border: `1px solid ${isActive ? N.cyan : N.border}`,
                      color: isActive ? N.cyan : N.text,
                    }}>
                      <div style={{ fontWeight: 800 }}>{roleDef.role}{isNatural ? " +" : ""}</div>
                      {isActive && <div style={{ fontSize: 9, color: N.cyan, marginTop: 2, lineHeight: 1.4, fontWeight: 500, opacity: 0.8 }}>{roleDef.desc}</div>}
                    </button>
                  );
                })}
              </div>
              {(player.activeRole || player.role) !== player.role && (
                <div style={{ fontSize: 9, color: "#ffa800", marginTop: 4 }}>⚠️ Natural role: +1 OVR bonus</div>
              )}
            </div>
            <div>
              <div style={{ fontSize: 11, fontWeight: 700, color: N.muted, marginBottom: 6 }}>FOCUS</div>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                {(FOCUS_OPTIONS[slotPos || player.naturalPosition] || ["Balanced"]).map((foc) => {
                  const isActive = (player.focus || "Balanced") === foc;
                  return (
                    <button key={foc} onClick={() => onFocusChange(player.id, foc)} style={{
                      padding: "5px 10px", fontSize: 10, fontWeight: 700, borderRadius: 4, cursor: "pointer",
                      background: isActive ? `${FOCUS_COLORS[foc]}20` : N.card,
                      border: `1px solid ${isActive ? FOCUS_COLORS[foc] : N.border}`,
                      color: isActive ? FOCUS_COLORS[foc] : N.text,
                    }}>
                      {foc}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}
        <div style={{ display: "flex", justifyContent: "space-around", padding: "12px 16px", borderBottom: `1px solid ${N.border}` }}>
          {Object.entries(face).map(([k, v], i) => (
            <div key={k} style={{ textAlign: "center" }}>
              <div style={{ fontSize: 9, fontWeight: 700, color: faceColors[i], marginBottom: 2 }}>{k}</div>
              <div style={{ fontSize: 20, fontWeight: 900, color: statColor(v), lineHeight: 1 }}>{v}</div>
            </div>
          ))}
        </div>
        <div style={{ padding: "12px 16px 20px", display: "flex", flexDirection: "column", gap: 12 }}>
          {STAT_CATEGORIES.map((cat) => (
            <div key={cat.name}>
              <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8 }}>
                <span style={{ fontSize: 13 }}>{cat.icon}</span>
                <span style={{ fontSize: 13, fontWeight: 800, color: cat.color }}>{cat.name}</span>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "4px 20px" }}>
                {cat.keys.map(([label, key]) => {
                  const val = player.detailed[key];
                  return (
                    <div key={key} style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <span style={{ fontSize: 11, color: N.muted, flex: 1 }}>{label}</span>
                      <div style={{ width: 60, height: 4, background: "#1a2236", borderRadius: 2, overflow: "hidden" }}>
                        <div style={{ width: `${(val / 99) * 100}%`, height: "100%", background: statColor(val), borderRadius: 2 }} />
                      </div>
                      <span style={{ fontSize: 12, fontWeight: 800, color: statColor(val), width: 22, textAlign: "right" }}>{val}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function FormationPreview({ formation, active }) {
  const coords = FORMATIONS[formation].coords;
  const positions = FORMATIONS[formation].positions;
  return (
    <div style={{ width: 130, height: 175, position: "relative", background: active ? "linear-gradient(180deg, #0e4a2e 0%, #127a40 50%, #0e4a2e 100%)" : "linear-gradient(180deg, #0a2e1c 0%, #0d3d26 50%, #0a2e1c 100%)", borderRadius: 8, overflow: "hidden", border: `2px solid ${active ? N.cyan : N.border}`, boxShadow: active ? `0 0 16px ${N.cyan}30` : "none", transition: "all 0.25s", cursor: "pointer", flexShrink: 0 }}>
      <div style={{ position: "absolute", top: "50%", left: "8%", right: "8%", height: 1, background: "rgba(255,255,255,0.18)" }} />
      {coords.map((c, i) => (
        <div key={i} style={{ position: "absolute", left: `${c.x}%`, top: `${c.y}%`, transform: "translate(-50%,-50%)" }}>
          <div style={{ width: 18, height: 18, borderRadius: "50%", background: active ? `radial-gradient(circle, ${N.cyan} 0%, ${N.cyan}80 60%, transparent 100%)` : `radial-gradient(circle, #8ab4a0 0%, #5a8a70 60%, transparent 100%)`, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <span style={{ fontSize: 5.5, fontWeight: 800, color: active ? "#003040" : "#1a3a28", lineHeight: 1 }}>{positions[i]}</span>
          </div>
        </div>
      ))}
      <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, textAlign: "center", padding: "4px 0", background: "rgba(0,0,0,0.5)" }}>
        <span style={{ fontSize: 13, fontWeight: 800, color: active ? N.cyan : N.muted }}>{formation}</span>
      </div>
    </div>
  );
}

function Pitch({ squad, formation, onSelect, selected, onDragStart, onDrop }) {
  const coords = FORMATIONS[formation].coords;
  const slotPositions = FORMATIONS[formation].positions;
  return (
    <div style={{ width: "100%", maxWidth: 560, aspectRatio: "3/4", background: "linear-gradient(180deg, #0a3d23 0%, #0d5a30 30%, #0a4525 70%, #082e19 100%)", borderRadius: 12, position: "relative", overflow: "hidden", border: `1px solid ${N.green}20`, boxShadow: `0 0 40px ${N.green}10, inset 0 0 60px rgba(0,0,0,0.3)`, margin: "0 auto" }}>
      <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)", width: 90, height: 90, borderRadius: "50%", border: `1.5px solid ${N.pitchLine}` }} />
      <div style={{ position: "absolute", top: "50%", left: "5%", right: "5%", height: 1.5, background: N.pitchLine }} />
      <div style={{ position: "absolute", bottom: "2%", left: "20%", right: "20%", height: "16%", border: `1.5px solid ${N.pitchLine}`, borderBottom: "none" }} />
      <div style={{ position: "absolute", top: "2%", left: "20%", right: "20%", height: "16%", border: `1.5px solid ${N.pitchLine}`, borderTop: "none" }} />
      {squad.map((player, i) => (
        <div key={player.id} style={{ position: "absolute", left: `${coords[i].x}%`, top: `${coords[i].y}%`, transform: "translate(-50%,-50%)", zIndex: selected?.type === "squad" && selected.index === i ? 20 : 10 }}>
          <PitchCard player={player} slotPos={slotPositions[i]} isSelected={selected?.type === "squad" && selected.index === i}
            onClick={() => onSelect({ type: "squad", index: i })}
            onDragStart={(e) => { e.dataTransfer.setData("text", JSON.stringify({ type: "squad", index: i })); onDragStart?.({ type: "squad", index: i }); }}
            onDrop={(e) => { e.preventDefault(); onDrop?.({ type: "squad", index: i }, e); }} />
        </div>
      ))}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════
   MAIN APP
   ═══════════════════════════════════════════════════════════════════════ */

export default function FootballManager() {
  const [screen, setScreen] = useState("welcome");
  const [tab, setTab] = useState("squad");
  const [managerName, setManagerName] = useState("");
  const [clubName, setClubName] = useState(() => pickRandom(DEFAULT_CLUBS));
  const [editingClub, setEditingClub] = useState(false);
  const [formation, setFormation] = useState("4-3-3");
  const [squad, setSquad] = useState([]);
  const [bench, setBench] = useState([]);
  const [money, setMoney] = useState(100);
  const [detailPlayer, setDetailPlayer] = useState(null);
  const [detailSlot, setDetailSlot] = useState(null);
  const [selected, setSelected] = useState(null);
  const [season, setSeason] = useState(null);
  const [matchIdx, setMatchIdx] = useState(0);
  const [matchPhase, setMatchPhase] = useState(null);
  const [matchResult, setMatchResult] = useState(null);
  const [visibleEvents, setVisibleEvents] = useState(0);
  // ── Live match control ──
  const liveSim = useRef(null);        // the running generator
  const orderRef = useRef(null);       // the order waiting to be handed over
  const seenEventsRef = useRef(0);     // how many events we've already paced
  const [matchPaused, setMatchPaused] = useState(false);
  const [matchView, setMatchView] = useState("pitch");   // pitch · tempo · hidden
  const [matchSpeed, setMatchSpeed] = useState(1);   // 1 = normal, 2 = quick, 4 = rush
  const frameQueue = useRef([]);   // remaining stages of the current move
  const snapshotRef = useRef(null);// the pitch as it stands for this possession
  const lastFrameRef = useRef(null);// the last stage shown, so play never blanks
  const frameCountRef = useRef(0); // drives each player's own movement over time
  const pendingRevealRef = useRef(null); // events waiting for their move to finish on the pitch
  const postRevealRef = useRef(false);   // a shot's result has just been revealed
  const [liveState, setLiveState] = useState(null);
  const [simTick, setSimTick] = useState(0);
  const [plannedSubs, setPlannedSubs] = useState([]);
  const [plannedTactic, setPlannedTactic] = useState(null);
  const [plannedShape, setPlannedShape] = useState(null);
  const [pickOff, setPickOff] = useState(null);
  const [selectedTactic, setSelectedTactic] = useState("balanced");
  const [instructions, setInstructions] = useState({ ...DEFAULT_INSTRUCTIONS });
  const [activeEvent, setActiveEvent] = useState(null);
  const [morale, setMorale] = useState(60);
  const [trainingLevel, setTrainingLevel] = useState(0);
  const [editingPlayer, setEditingPlayer] = useState(null);
  const [squadSubTab, setSquadSubTab] = useState("lineup");
  const [shapeView, setShapeView] = useState("defensive");
  const [squadListSort, setSquadListSort] = useState({ key: "pos", dir: "asc" });
  const [saveStatus, setSaveStatus] = useState(null);
  const [hasLoadedSave, setHasLoadedSave] = useState(false);
  const [trophies, setTrophies] = useState([]);
  const [currentDivision, setCurrentDivision] = useState(4);
  const [leagueTable, setLeagueTable] = useState(null);
  const [world, setWorld] = useState([]);
  const [playerClubId, setPlayerClubId] = useState(null);
  const [seasonData, setSeasonData] = useState(null);
  const [lastRoundResults, setLastRoundResults] = useState([]);
  const [gameOver, setGameOver] = useState(false);
  // ── Transfer market ──
  const [transferSubTab, setTransferSubTab] = useState("search");
  const [hiredScouts, setHiredScouts] = useState([]);
  const [worldPlayers, setWorldPlayers] = useState([]);
  const [filterPos, setFilterPos] = useState("ALL");
  const [filterMinOvr, setFilterMinOvr] = useState(0);
  const [filterMaxAge, setFilterMaxAge] = useState(40);
  const [filterName, setFilterName] = useState("");
  const [searchLimit, setSearchLimit] = useState(24);
  const [transferList, setTransferList] = useState([]);
  const [pendingSignings, setPendingSignings] = useState([]);
  const [blacklist, setBlacklist] = useState([]);
  const [interview, setInterview] = useState(null);
  const [sellList, setSellList] = useState([]);        // [{ playerId, askingPrice, offers, source }]
  const [agreedSales, setAgreedSales] = useState([]);  // [{ player, offer, source }]
  const [saleTalks, setSaleTalks] = useState(null);    // active negotiation
  const [approachAlert, setApproachAlert] = useState(null);
  const loadedSeasonNum = useRef(null);
  const [seasonNumber, setSeasonNumber] = useState(1);
  const eventLogRef = useRef(null);

  // ── Reactive Self-Healer for the League Table ──
  // Watches leagueTable and auto-corrects any team whose points don't equal
  // won*3 + drawn*1. This rescues any save that was written with the old
  // (buggy) loss-gives-minus-3 math and is idempotent — a table with correct
  // points never triggers a re-set, so there's no infinite loop risk.
  useEffect(() => {
    if (!leagueTable) return;
    const needsHeal = leagueTable.some((t) => t.points !== (t.won || 0) * 3 + (t.drawn || 0));
    if (needsHeal) {
      setLeagueTable(leagueTable.map((t) => ({
        ...t,
        points: (t.won || 0) * 3 + (t.drawn || 0),
      })));
    }
  }, [leagueTable]);

  // ── Recover an empty league ──
  // A season generated while the world was missing produces a table with no
  // rows and no fixtures — the Table tab then renders its headers over
  // nothing. Once a world exists again, rebuild the season for the current
  // division so the league becomes playable instead of a blank screen.
  useEffect(() => {
    if (screen !== "main") return;
    if (!world.length || !playerClubId) return;
    if (leagueTable && leagueTable.length > 0) return;

    const rebuilt = generateLeagueSeason(world, playerClubId, currentDivision);
    if (!rebuilt.table.length) return;   // nothing to build from; don't loop

    setSeasonData(rebuilt);
    setSeason(rebuilt.matches);
    setLeagueTable(rebuilt.table);
    setMatchIdx(0);
  }, [screen, world, playerClubId, leagueTable, currentDivision]);

  // ── Save / Load System ──
  const saveGame = useCallback(async () => {
    try {
      setSaveStatus("saving");
      const saveData = {
        managerName, clubName, formation, squad, bench, money,
        season, seasonData, seasonNumber, matchIdx, selectedTactic,
        morale, trainingLevel, instructions, trophies, currentDivision, leagueTable, hiredScouts, transferList, pendingSignings, blacklist, worldPlayers, sellList, agreedSales,
        // Without these two the whole world vanishes on reload: no rival clubs,
        // no promotion/relegation, no competitions, no new fixtures.
        world, playerClubId,
      };
      await window.storage.set("neon-fm-save", JSON.stringify(saveData));
      setSaveStatus("saved");
      setTimeout(() => setSaveStatus(null), 2000);
    } catch (err) {
      console.error("Save failed:", err);
      setSaveStatus("error");
      setTimeout(() => setSaveStatus(null), 3000);
    }
  }, [managerName, clubName, formation, squad, bench, money, season, seasonData, seasonNumber, matchIdx, selectedTactic, morale, trainingLevel, instructions, trophies, currentDivision, leagueTable, hiredScouts, transferList, pendingSignings, blacklist, world, playerClubId]);

  // Load save on mount
  useEffect(() => {
    if (hasLoadedSave) return;
    (async () => {
      try {
        const result = await window.storage.get("neon-fm-save");
        if (result && result.value) {
          const data = JSON.parse(result.value);
          if (data.managerName && data.squad?.length > 0) {
            setManagerName(data.managerName);
            setClubName(data.clubName || "FC Novalux");
            setFormation(data.formation || "4-3-3");
            setSquad(data.squad.map((p) => ({ ...p, potential: p.potential || generatePotential(p.ovr, p.age || 25) })));
            setBench((data.bench || []).map((p) => ({ ...p, potential: p.potential || generatePotential(p.ovr, p.age || 25) })));
            setMoney(data.money ?? 100);
            setSeason(data.season);
            setMatchIdx(data.matchIdx ?? 0);
            setSelectedTactic(TACTICS[data.selectedTactic] ? data.selectedTactic : "balanced");
            if (data.instructions) setInstructions({ ...DEFAULT_INSTRUCTIONS, ...data.instructions });
            setMorale(data.morale ?? 60);
            setTrainingLevel(data.trainingLevel ?? 0);
            if (data.seasonNumber) {
              setSeasonNumber(data.seasonNumber);
            }
            if (data.trophies) setTrophies(data.trophies);
            if (data.currentDivision) setCurrentDivision(data.currentDivision);
            if (data.hiredScouts) {
              // Older saves stored scouts with a maxOvr ceiling and no attributes
              setHiredScouts(data.hiredScouts.map((sc) => {
                if (sc.judgingAbility !== undefined) return sc;
                const fresh = generateScout(sc.stars || 1);
                return { ...fresh, id: sc.id || fresh.id, name: sc.name || fresh.name };
              }));
            }
            // ── Restore the world (rival clubs) ──
            // Saves written before the world was persisted come back empty,
            // which silently breaks promotion/relegation, competitions and
            // new-season fixtures. Rebuild one and re-link it by club name.
            let restoredSeason = data.season;
            if (data.world?.length && data.playerClubId) {
              setWorld(data.world);
              setPlayerClubId(data.playerClubId);
              if (data.seasonData) setSeasonData(data.seasonData);
            } else if (data.squad?.length) {
              const fresh = generateWorld();
              const byName = new Map(fresh.map((c) => [c.name, c]));
              const div = data.currentDivision || 4;

              // Claim a club to be yours, renamed and carrying your squad
              let you = byName.get(data.clubName) || fresh.find((c) => c.division === div) || fresh[0];
              you.name = data.clubName || you.name;
              you.division = div;
              you.isPlayer = true;
              you.squad = data.squad;
              you.formation = data.formation || "4-3-3";
              byName.set(you.name, you);

              // Point the saved table at the rebuilt clubs and pull every
              // club it mentions into your division so the league is whole
              if (data.leagueTable) {
                data.leagueTable = data.leagueTable.map((row) => {
                  const club = byName.get(row.name);
                  if (!club) return row;
                  club.division = div;
                  return { ...row, clubId: club.id };
                });
              }

              // Re-link your remaining fixtures to the rebuilt opponents
              if (Array.isArray(restoredSeason)) {
                restoredSeason = restoredSeason.map((m) => {
                  const club = byName.get(m.opponent);
                  if (!club) return m;
                  return {
                    ...m, opponentId: club.id, oppSquad: club.squad,
                    oppManager: club.manager, formation: club.formation,
                  };
                });
                setSeason(restoredSeason);
              }

              setWorld(fresh);
              setPlayerClubId(you.id);
            }

            // ── Rebuild the other clubs' fixture list if it was never saved ──
            // Without `otherFixtures` the rival clubs never play, so every AI
            // row stays on zero and the table looks dead.
            if (!data.seasonData && data.leagueTable?.length) {
              const rows = data.leagueTable;
              const ids = rows.map((r) => r.clubId).filter(Boolean);
              const me = rows.find((r) => r.isYou)?.clubId;
              if (ids.length > 1) {
                const rounds = roundRobin(ids);
                setSeasonData({
                  matches: Array.isArray(restoredSeason) ? restoredSeason : [],
                  table: rows,
                  otherFixtures: rounds.map((round) =>
                    round.filter((f) => f.home !== me && f.away !== me)
                  ),
                  divisionTier: data.currentDivision || 4,
                });
              }
            }

            if (data.worldPlayers) setWorldPlayers(data.worldPlayers);
            if (data.transferList) setTransferList(data.transferList);
            if (data.pendingSignings) setPendingSignings(data.pendingSignings);
            if (data.blacklist) setBlacklist(data.blacklist);
            if (data.sellList) setSellList(data.sellList);
            if (data.agreedSales) setAgreedSales(data.agreedSales);
            if (data.leagueTable) {
              // Self-heal any league table saved with the old (buggy) loss-gives-minus-3 math
              // by recomputing points from the reliable won/drawn tallies. This is idempotent —
              // tables saved with correct math will end up with the exact same points.
              const healed = data.leagueTable.map((t) => ({
                ...t,
                points: (t.won || 0) * 3 + (t.drawn || 0),
              }));
              setLeagueTable(healed);
            } else if (data.season) {
              // Old save without league - generate a table from current season
              const div = getDivision(data.currentDivision || 4);
              const table = [
                { name: data.clubName || "FC Novalux", isYou: true, played: 0, won: 0, drawn: 0, lost: 0, gf: 0, ga: 0, points: 0, form: [] },
                ...data.season.map((m) => ({
                  name: m.opponent, isYou: false, ovr: m.oppOvr,
                  played: randInt(0, 5), won: randInt(0, 3), drawn: randInt(0, 2), lost: randInt(0, 3),
                  gf: randInt(0, 8), ga: randInt(0, 8), points: randInt(0, 9), form: [],
                })),
              ];
              setLeagueTable(table);
            }
            setScreen("main");
          }
        }
      } catch (err) {
        console.log("No save found or load error:", err);
      }
      setHasLoadedSave(true);
    })();
  }, [hasLoadedSave]);

  // Auto-save after important actions (debounced)
  const autoSaveTimer = useRef(null);
  const triggerAutoSave = useCallback(() => {
    if (screen !== "main") return;
    if (autoSaveTimer.current) clearTimeout(autoSaveTimer.current);
    autoSaveTimer.current = setTimeout(async () => {
      try {
        const saveData = {
          managerName, clubName, formation, squad, bench, money,
          season, seasonData, seasonNumber, matchIdx, selectedTactic, morale, trainingLevel,
          instructions,
          trophies, currentDivision, leagueTable, hiredScouts, transferList, pendingSignings, blacklist, worldPlayers, sellList, agreedSales,
          world, playerClubId,
        };
        await window.storage.set("neon-fm-save", JSON.stringify(saveData));
      } catch (err) { /* silent auto-save */ }
    }, 1500);
  }, [screen, managerName, clubName, formation, squad, bench, money, season, seasonData, seasonNumber, matchIdx, selectedTactic, morale, trainingLevel, instructions, trophies, currentDivision, leagueTable, hiredScouts, transferList, pendingSignings, blacklist, world, playerClubId]);

  // Trigger auto-save when key state changes
  useEffect(() => {
    if (screen === "main" && squad.length > 0) triggerAutoSave();
  }, [squad, bench, money, matchIdx, morale, trainingLevel, formation, selectedTactic, instructions, trophies, currentDivision, leagueTable, hiredScouts, transferList, pendingSignings, season, seasonData, world, playerClubId]);

  const resetSave = useCallback(async () => {
    try {
      await window.storage.delete("neon-fm-save");
    } catch (err) { /* ignore */ }
    setScreen("welcome");
    setSquad([]); setBench([]); setMoney(100); setSeason(null);
    setMatchIdx(0); setMorale(60); setTrainingLevel(0);
    setManagerName(""); setClubName(pickRandom(DEFAULT_CLUBS));
    setFormation("4-3-3"); setSelectedTactic("balanced"); setInstructions({ ...DEFAULT_INSTRUCTIONS });
    setSeasonNumber(1); setTrophies([]); setCurrentDivision(4);
    setLeagueTable(null); setGameOver(false);
    setHiredScouts([]); setWorldPlayers([]); setTransferList([]);
    setPendingSignings([]); setBlacklist([]); setInterview(null);
    setSellList([]); setAgreedSales([]);
  }, []);

  const slotPositions = FORMATIONS[formation].positions;

  const teamOvr = useMemo(() => {
    if (!squad.length) return 0;
    return Math.round(squad.reduce((sum, p, i) => sum + getEffectiveOvr(p, slotPositions[i]), 0) / squad.length);
  }, [squad, slotPositions]);

  const chemistry = useMemo(() => {
    if (!squad.length) return { total: 0, bonus: 0, links: 0 };
    return calculateChemistry(squad, formation);
  }, [squad, formation]);

  // ── Swap logic ──
  const doSwap = useCallback((target) => {
    if (!selected) return;
    if (selected.type === target.type && selected.index === target.index) {
      if (selected.type === "squad") { setDetailPlayer(squad[selected.index]); setDetailSlot(slotPositions[selected.index]); }
      else { setDetailPlayer(bench[selected.index]); setDetailSlot(null); }
      setSelected(null);
      return;
    }
    const newSquad = [...squad]; const newBench = [...bench];
    const getP = (s) => s.type === "squad" ? newSquad[s.index] : newBench[s.index];
    const setP = (s, p) => { if (s.type === "squad") newSquad[s.index] = p; else newBench[s.index] = p; };
    const a = getP(selected); const b = getP(target);
    setP(selected, b); setP(target, a);
    setSquad(newSquad); setBench(newBench); setSelected(null);
  }, [selected, squad, bench, slotPositions]);

  const handleSelect = useCallback((s) => { if (!selected) { setSelected(s); return; } doSwap(s); }, [selected, doSwap]);
  const handleDrop = useCallback((target, e) => {
    try {
      const src = JSON.parse(e.dataTransfer.getData("text"));
      if (src.type === target.type && src.index === target.index) return;
      const ns = [...squad]; const nb = [...bench];
      const gP = (s) => s.type === "squad" ? ns[s.index] : nb[s.index];
      const sP = (s, p) => { if (s.type === "squad") ns[s.index] = p; else nb[s.index] = p; };
      const a = gP(src); const b = gP(target); sP(src, b); sP(target, a);
      setSquad(ns); setBench(nb); setSelected(null);
    } catch (err) { /* ignore */ }
  }, [squad, bench]);

  const handleStart = useCallback(() => {
    if (!managerName.trim()) return;
    const startingSquad = generateSquad(formation);
    setSquad(startingSquad);
    setBench(generateBench());

    // Build the football world, then replace the weakest Division 4 club with yours
    const newWorld = generateWorld();
    const div4 = newWorld.filter((c) => c.division === 4);
    const weakest = div4.reduce((a, b) => (clubOvr(b) < clubOvr(a) ? b : a));
    const yourClub = {
      ...weakest,
      name: clubName,
      isPlayer: true,
      manager: { name: managerName, tactical: {}, management: {}, personality: {} },
      squad: startingSquad,
      formation,
    };
    const finalWorld = newWorld.map((c) => (c.id === weakest.id ? yourClub : c));

    setWorld(finalWorld);
    setPlayerClubId(yourClub.id);
    const leagueData = generateLeagueSeason(finalWorld, yourClub.id, 4);
    setSeasonData(leagueData);
    setSeason(leagueData.matches);
    setLeagueTable(leagueData.table);
    setCurrentDivision(4);
    setScreen("main");
  }, [managerName, formation, clubName]);

  // ── Season & Transfer system ──
  // seasonNumber is declared earlier with save system
  const [transferWindow, setTransferWindow] = useState(null);
  const [clubLeague, setClubLeague] = useState(null);
  const [clPhase, setClPhase] = useState(null);
  const [clResult, setClResult] = useState(null);
  const [clVisibleEvts, setClVisibleEvts] = useState(0);
  const clLogRef = useRef(null);

  // Promotion and relegation applied across the whole world, not just your club
  const applyPromotionRelegation = useCallback(() => {
    if (!leagueTable || !world.length) return { newDiv: currentDivision, world };
    const sorted = sortTable(leagueTable);
    const total = sorted.length;
    const promotedIds = sorted.slice(0, 3).map((r) => r.clubId);
    const relegatedIds = sorted.slice(total - 3).map((r) => r.clubId);

    let yourNewDiv = currentDivision;
    const updated = world.map((club) => {
      if (club.division !== currentDivision) return club;
      if (promotedIds.includes(club.id) && currentDivision > 1) {
        if (club.id === playerClubId) yourNewDiv = currentDivision - 1;
        return { ...club, division: currentDivision - 1 };
      }
      if (relegatedIds.includes(club.id) && currentDivision < 4) {
        if (club.id === playerClubId) yourNewDiv = currentDivision + 1;
        return { ...club, division: currentDivision + 1 };
      }
      return club;
    });

    // Clubs coming the other way keep the divisions at ten each
    const balanced = [...updated];
    for (let tier = 1; tier <= 4; tier++) {
      const inTier = balanced.filter((c) => c.division === tier);
      if (inTier.length > CLUBS_PER_DIVISION && tier < 4) {
        // Push the weakest surplus clubs down
        const surplus = inTier.sort((a, b) => clubOvr(a) - clubOvr(b)).slice(0, inTier.length - CLUBS_PER_DIVISION);
        surplus.forEach((s) => {
          if (s.id === playerClubId) return;
          const idx = balanced.findIndex((c) => c.id === s.id);
          balanced[idx] = { ...s, division: tier + 1 };
        });
      } else if (inTier.length < CLUBS_PER_DIVISION && tier < 4) {
        // Pull the strongest clubs up from below
        const below = balanced.filter((c) => c.division === tier + 1)
          .sort((a, b) => clubOvr(b) - clubOvr(a));
        const need = CLUBS_PER_DIVISION - inTier.length;
        below.slice(0, need).forEach((s) => {
          if (s.id === playerClubId) return;
          const idx = balanced.findIndex((c) => c.id === s.id);
          balanced[idx] = { ...s, division: tier };
        });
      }
    }

    setWorld(balanced);
    setCurrentDivision(yourNewDiv);
    return { newDiv: yourNewDiv, world: balanced };
  }, [leagueTable, world, currentDivision, playerClubId]);

  // Completes every agreed sale: money in, players out, squad backfilled.
  // The transfer window does this as part of its own flow; this exists so
  // skipping the window doesn't quietly strand deals you already agreed.
  const settleAgreedSales = useCallback(() => {
    if (agreedSales.length === 0) return 0;
    const soldIds = agreedSales.map((x) => x.player.id);
    const income = agreedSales.reduce((sum, x) => sum + x.offer.amount, 0);

    let newSquad = squad.filter((p) => !soldIds.includes(p.id));
    let newBench = bench.filter((p) => !soldIds.includes(p.id));

    let moraleHit = 0;
    agreedSales.forEach((x) => {
      if (x.player.ovr >= 70) moraleHit -= 3;
      else if (x.player.ovr >= 55) moraleHit -= 1;
    });

    // The buyers actually receive the players
    setWorld((w) => w.map((club) => {
      const incoming = agreedSales.filter((x) => x.offer.clubId === club.id);
      if (incoming.length === 0) return club;
      return { ...club, squad: [...club.squad, ...incoming.map((x) => x.player)] };
    }));

    // Backfill so you never start a season short
    while (newSquad.length < 11 && newBench.length > 0) {
      newBench.sort((a, b) => b.ovr - a.ovr);
      newSquad.push(newBench.shift());
    }
    while (newSquad.length < 11) {
      newSquad.push(generatePlayer(pickRandom(ALL_POSITIONS), [28, 42]));
    }

    setSquad(newSquad);
    setBench(newBench);
    setMoney((m) => m + income);
    setMorale((m) => Math.max(0, Math.min(100, m + moraleHit)));
    setAgreedSales([]);
    setSellList([]);
    setWorldPlayers([]);
    return income;
  }, [agreedSales, squad, bench]);

  const startNewSeason = useCallback((divisionOverride, worldOverride) => {
    const nextSeason = seasonNumber + 1;
    const div = divisionOverride ?? currentDivision;
    // A fresh world snapshot (from applyPromotionRelegation) beats the possibly
    // stale one in this callback's closure, which gets captured at render time
    // and hasn't seen the promotion/relegation changes yet.
    const baseWorld = worldOverride ?? world;
    setSeasonNumber(nextSeason);
    setMatchIdx(0);

    // Sync your squad into the world, age every other club's players,
    // and move your club into its new division
    const agedWorld = baseWorld.map((c) => {
      if (c.id === playerClubId) {
        return { ...c, squad, formation, division: div, name: clubName };
      }
      return { ...c, squad: c.squad.map(progressPlayerAge) };
    });
    setWorld(agedWorld);

    const leagueData = generateLeagueSeason(agedWorld, playerClubId, div);
    setSeasonData(leagueData);
    setSeason(leagueData.matches);
    setLeagueTable(leagueData.table);
    setLastRoundResults([]);
    setMorale((m) => Math.min(100, m + 5));
  }, [seasonNumber, currentDivision, world, playerClubId, squad, formation, clubName]);

  const openTransferWindow = useCallback(() => {
    // Generate 2-3 players wanting to leave (lower morale = more want to leave)
    const allPlayers = [...squad, ...bench];
    const leaveCount = morale < 40 ? 3 : morale < 60 ? 2 : 1;
    const shuffled = [...allPlayers].sort(() => Math.random() - 0.5);
    const departures = shuffled.slice(0, Math.min(leaveCount, allPlayers.length)).map((p) => ({
      player: p,
      value: Math.round(p.ovr * 1.5),
      reason: pickRandom(["wants a new challenge", "feels undervalued", "homesick", "seeking higher wages", "wants more playing time"]),
    }));

    // Generate 2-3 new players wanting to join
    const arrivalCount = randInt(2, 3);
    const arrivals = [];
    for (let i = 0; i < arrivalCount; i++) {
      const pos = pickRandom(ALL_POSITIONS);
      const prestigeBonus = getPrestigeArrivalBonus(calculatePrestige(trophies));
      const ovrRange = [Math.max(35, teamOvr - 10 + Math.floor(prestigeBonus / 2)), Math.min(99, teamOvr + 15 + prestigeBonus)];
      const newPlayer = generatePlayer(pos, ovrRange);
      arrivals.push({
        player: newPlayer,
        salary: getPlayerSalary(newPlayer),
        askingFee: Math.round(newPlayer.ovr * randInt(8, 15) / 10),
      });
    }

    setTransferWindow({ departures, arrivals, decisions: {}, pending: pendingSignings });
  }, [squad, bench, morale, teamOvr, trophies, pendingSignings]);

  const handleTransferDecision = useCallback((type, index, accept) => {
    if (!transferWindow) return;
    setTransferWindow((tw) => ({
      ...tw,
      decisions: { ...tw.decisions, [`${type}-${index}`]: accept },
    }));
  }, [transferWindow]);

  const confirmTransfers = useCallback(() => {
    if (!transferWindow) return;
    let newSquad = [...squad];
    let newBench = [...bench];
    let moneyChange = 0;
    let moraleChange = 0;

    // Process departures
    transferWindow.departures.forEach((dep, i) => {
      const accepted = transferWindow.decisions[`dep-${i}`];
      if (accepted) {
        moneyChange += dep.value;
        newSquad = newSquad.filter((p) => p.id !== dep.player.id);
        newBench = newBench.filter((p) => p.id !== dep.player.id);
        // Replace in squad if needed
        if (newSquad.length < 11) {
          newSquad.push(generatePlayer(dep.player.naturalPosition, [25, 40]));
        }
      } else {
        moraleChange -= 5; // Rejecting departure hurts morale
      }
    });

    // Process arrivals
    transferWindow.arrivals.forEach((arr, i) => {
      const accepted = transferWindow.decisions[`arr-${i}`];
      if (accepted) {
        moneyChange -= arr.askingFee;
        newBench.push(arr.player);
        moraleChange += 2; // New signing boosts morale
      }
    });

    // Players you agreed to sell now leave for their new clubs
    if (agreedSales.length > 0) {
      const soldIds = agreedSales.map((s) => s.player.id);
      const salesIncome = agreedSales.reduce((sum, s) => sum + s.offer.amount, 0);
      moneyChange += salesIncome;

      newSquad = newSquad.filter((p) => !soldIds.includes(p.id));
      newBench = newBench.filter((p) => !soldIds.includes(p.id));

      // Selling a popular player unsettles the dressing room a little
      agreedSales.forEach((s) => {
        if (s.player.ovr >= 70) moraleChange -= 3;
        else if (s.player.ovr >= 55) moraleChange -= 1;
      });

      // They join their new club's squad — the world stays honest
      setWorld((w) => w.map((club) => {
        const incoming = agreedSales.filter((s) => s.offer.clubId === club.id);
        if (incoming.length === 0) return club;
        return { ...club, squad: [...club.squad, ...incoming.map((s) => s.player)] };
      }));

      // If you sold a starter, promote from the bench
      while (newSquad.length < 11 && newBench.length > 0) {
        newBench.sort((a, b) => b.ovr - a.ovr);
        newSquad.push(newBench.shift());
      }
      while (newSquad.length < 11) {
        newSquad.push(generatePlayer(pickRandom(ALL_POSITIONS), [28, 42]));
      }

      setAgreedSales([]);
      setSellList([]);
      setWorldPlayers([]);
    }

    // Bring in players who agreed to sign during the season.
    // They physically leave their old club — the world stays consistent.
    if (pendingSignings.length > 0) {
      const departedByClub = {};
      pendingSignings.forEach((ps) => {
        newBench.push(ps.player);
        moraleChange += 1;
        const cid = ps.player.clubId;
        if (cid) {
          if (!departedByClub[cid]) departedByClub[cid] = [];
          departedByClub[cid].push(ps.player.id);
        }
      });

      if (Object.keys(departedByClub).length > 0) {
        setWorld((w) => w.map((club) => {
          const gone = departedByClub[club.id];
          if (!gone) return club;
          const remaining = club.squad.filter((p) => !gone.includes(p.id));
          // The selling club replaces them from their youth setup
          while (remaining.length < club.squad.length) {
            const slot = FORMATIONS[club.formation].positions[remaining.length % 11];
            const rep = club.reputation;
            const centre = 28 + (rep / 99) * 55;
            remaining.push(generatePlayer(slot, [Math.round(centre - 14), Math.round(centre - 2)]));
          }
          return { ...club, squad: remaining };
        }));
        // The market view is now stale
        setWorldPlayers([]);
      }
      setPendingSignings([]);
    }

    // Age all players by 1 year and apply OVR changes
    newSquad = newSquad.map(progressPlayerAge);
    newBench = newBench.map(progressPlayerAge);

    setSquad(newSquad);
    setBench(newBench);
    setMoney((m) => Math.max(0, m + moneyChange));
    setMorale((m) => Math.max(0, Math.min(100, m + moraleChange)));
    setTransferWindow(null);

    // Start new season after transfer window
    startNewSeason();
  }, [transferWindow, squad, bench, startNewSeason, pendingSignings, agreedSales]);

  // ── Club League handlers ──
  // ── Competition handlers (real clubs, real draws) ──
  const startClubLeague = useCallback((worldOverride) => {
    const baseWorld = worldOverride ?? world;
    if (!baseWorld.length || !playerClubId) return;
    const syncedWorld = baseWorld.map((c) => c.id === playerClubId ? { ...c, squad, formation } : c);
    const comp = generateCompetition(syncedWorld, playerClubId, seasonNumber);
    setWorld(syncedWorld);
    setClubLeague(comp);
    setClPhase("bracket");
  }, [world, playerClubId, seasonNumber, squad, formation]);

  // Who is the player facing right now in the competition?
  const clCurrentTie = useMemo(() => {
    if (!clubLeague || !playerClubId) return null;
    if (clubLeague.stage === "group") {
      const g = playerGroupFixture(clubLeague, playerClubId);
      if (!g) return null;
      const opp = world.find((c) => c.id === g.oppId);
      if (!opp) return null;
      const def = COMPETITION_DEFS[clubLeague.type];
      return {
        opponent: opp, isHome: g.fixture.home === playerClubId,
        roundName: `Group ${g.group.letter} — Matchday ${clubLeague.groupMatchDay + 1}`,
        reward: def.groupReward, consolation: def.groupConsolation, isGroup: true,
      };
    }
    const k = playerKnockoutTie(clubLeague, playerClubId);
    if (!k) return null;
    const opp = world.find((c) => c.id === k.oppId);
    if (!opp) return null;
    return {
      opponent: opp, isHome: k.tie.homeId === playerClubId,
      roundName: k.round.name, reward: k.round.reward,
      consolation: k.round.consolation, isGroup: false,
    };
  }, [clubLeague, playerClubId, world]);

  const startClMatch = useCallback(() => {
    if (!clubLeague || !clCurrentTie) return;
    const opp = clCurrentTie.opponent;
    const moraleBonus = getMoraleMatchBonus(morale);
    const trainBonus = TRAINING_LEVELS[trainingLevel].matchBonus;
    const oppTactic = managerPickTactic(opp.manager, { scoreDiff: 0, minute: 0 });
    const result = simulateMatchV2(
      {
        name: clubName, squad, slotPositions, bench,
        formationKey: formation,
        behaviour: resolveBehaviour(selectedTactic, instructions),
        tacticKey: selectedTactic,
        bonus: chemistry.bonus + moraleBonus + trainBonus + (clCurrentTie.isHome ? HOME_ADVANTAGE : 0),
      },
      {
        name: opp.name, squad: opp.squad.slice(0, 11),
        slotPositions: FORMATIONS[opp.formation].positions,
        formationKey: opp.formation,
        bench: opp.squad.slice(11),
        behaviour: resolveBehaviour(oppTactic, managerInstructions(opp.manager)),
        tacticKey: oppTactic,
        bonus: clCurrentTie.isHome ? 0 : HOME_ADVANTAGE,
      }
    );
    setClResult(result);
    setClPhase("simulating");
    setClVisibleEvts(0);
  }, [clubLeague, clCurrentTie, squad, bench, formation, slotPositions, selectedTactic, instructions, chemistry, morale, trainingLevel, clubName]);

  useEffect(() => {
    if (clPhase !== "simulating" || !clResult) return;
    if (clVisibleEvts >= clResult.events.length) { setClPhase("result"); return; }
    const evt = clResult.events[clVisibleEvts];
    const timer = setTimeout(() => {
      setClVisibleEvts((v) => v + 1);
      if (clLogRef.current) clLogRef.current.scrollTop = clLogRef.current.scrollHeight;
    }, eventRevealDelay(evt));
    return () => clearTimeout(timer);
  }, [clPhase, clResult, clVisibleEvts]);

  const collectClReward = useCallback(() => {
    if (!clResult || !clubLeague || !clCurrentTie) return;
    const won = clResult.homeGoals > clResult.awayGoals;
    const draw = clResult.homeGoals === clResult.awayGoals;
    const reward = won ? clCurrentTie.reward : draw && clCurrentTie.isGroup
      ? Math.round(clCurrentTie.reward * 0.5) : clCurrentTie.consolation;
    setMoney((v) => v + reward);

    const drain = TACTICS[selectedTactic]?.fitnessDrain ?? 1.0;
    const clRecovery = TRAINING_LEVELS[trainingLevel].benchRecovery;
    const clMins = clResult.minutes || {};
    const applyClFit = (p) => ({
      ...p,
      minutesPlayed: (p.minutesPlayed || 0) + (clMins[p.id] || 0),
      fitness: Math.max(0, Math.min(100,
        (p.fitness ?? 100) + matchFitnessChange(p, clMins[p.id], drain, clRecovery))),
    });
    setSquad((sq) => sq.map(applyClFit));
    setBench((b) => b.map(applyClFit));

    const def = COMPETITION_DEFS[clubLeague.type];
    const comp = { ...clubLeague };

    if (comp.stage === "group") {
      // Record your result and play every other group fixture this matchday
      const groups = comp.groups.map((g) => {
        const round = g.fixtures[comp.groupMatchDay];
        if (!round) return g;
        const table = g.table.map((r) => ({ ...r, form: [...r.form] }));
        round.forEach((f) => {
          if (f.home === playerClubId || f.away === playerClubId) {
            const hg = f.home === playerClubId ? clResult.homeGoals : clResult.awayGoals;
            const ag = f.home === playerClubId ? clResult.awayGoals : clResult.homeGoals;
            applyResult(table, f.home, f.away, hg, ag);
          } else {
            const hc = world.find((c) => c.id === f.home);
            const ac = world.find((c) => c.id === f.away);
            if (hc && ac) {
              const r = quickSimulate(hc, ac);
              applyResult(table, f.home, f.away, r.homeGoals, r.awayGoals);
            }
          }
        });
        return { ...g, table };
      });

      const nextMd = comp.groupMatchDay + 1;
      const groupsDone = nextMd >= (groups[0]?.fixtures.length || 3);
      comp.groups = groups;
      comp.groupMatchDay = nextMd;

      if (groupsDone) {
        // Did you finish top two?
        const yourGroup = groups.find((g) => g.clubIds.includes(playerClubId));
        const sorted = sortTable(yourGroup.table);
        const yourPos = sorted.findIndex((r) => r.clubId === playerClubId) + 1;
        if (yourPos > 2) {
          comp.eliminated = true;
          setClubLeague(comp);
          setClPhase("eliminated");
          setClResult(null);
          return;
        }
        comp.stage = "knockout";
        comp.bracket = buildKnockoutFromGroups(comp, world, def);
        comp.knockoutRound = 0;
      }
      setClubLeague(comp);
      setClPhase("bracket");
      setClResult(null);
      return;
    }

    // ── Knockout ──
    if (!won && !draw) {
      comp.eliminated = true;
      setClubLeague(comp);
      setClPhase("eliminated");
      setClResult(null);
      return;
    }
    if (draw) {
      // Extra time / penalties — the better side usually goes through
      const opp = clCurrentTie.opponent;
      const edge = (teamOvr + chemistry.bonus) - clubOvr(opp);
      if (Math.random() > 0.5 + edge / 60) {
        comp.eliminated = true;
        setClubLeague(comp);
        setClPhase("eliminated");
        setClResult(null);
        return;
      }
    }

    // You advanced — resolve the rest of the round, then build the next one
    const bracket = comp.bracket.map((r) => ({ ...r, ties: [...r.ties] }));
    const round = bracket[comp.knockoutRound];
    const advancing = [];
    round.ties.forEach((t) => {
      if (t.homeId === playerClubId || t.awayId === playerClubId) {
        advancing.push(playerClubId);
        return;
      }
      const hc = world.find((c) => c.id === t.homeId);
      const ac = world.find((c) => c.id === t.awayId);
      if (!hc || !ac) return;
      const r = quickSimulate(hc, ac);
      advancing.push(r.homeGoals >= r.awayGoals ? t.homeId : t.awayId);
    });
    round.winners = advancing;

    const nextRound = comp.knockoutRound + 1;
    if (nextRound >= bracket.length || advancing.length < 2) {
      comp.champion = true;
      comp.bracket = bracket;
      setClubLeague(comp);
      setClPhase("champion");
      setMorale((m) => Math.min(100, m + 15));
      setTrophies((t) => [...t, { type: comp.type, title: comp.title, season: seasonNumber, icon: comp.icon }]);
      setClResult(null);
      return;
    }

    // Seed the next round from this round's winners
    const ties = [];
    for (let i = 0; i < advancing.length; i += 2) {
      if (advancing[i + 1]) ties.push({ homeId: advancing[i], awayId: advancing[i + 1] });
    }
    bracket[nextRound] = { ...bracket[nextRound], ties };
    comp.bracket = bracket;
    comp.knockoutRound = nextRound;
    setClubLeague(comp);
    setClPhase("bracket");
    setClResult(null);
  }, [clResult, clubLeague, clCurrentTie, world, playerClubId, trainingLevel, selectedTactic, teamOvr, chemistry, seasonNumber]);

  const exitClubLeague = useCallback(() => {
    setClubLeague(null);
    setClPhase(null);
    setClResult(null);
    openTransferWindow();
  }, [openTransferWindow]);

  // ── Scout hiring (permanent staff) ──
  const hireScout = useCallback((tier) => {
    const t = SCOUT_TIERS.find((s) => s.stars === tier);
    if (!t || money < t.hireCost) return;
    setMoney((m) => m - t.hireCost);
    setHiredScouts((s) => [...s, generateScout(tier)]);
  }, [money]);

  const fireScout = useCallback((scoutId) => {
    setHiredScouts((s) => s.filter((sc) => sc.id !== scoutId));
  }, []);

  // Give a scout a brief. He starts from scratch each time you reassign him.
  const assignScout = useCallback((scoutId, type, params) => {
    setHiredScouts((list) => list.map((sc) =>
      sc.id === scoutId
        ? { ...sc, assignment: { type, params, cycles: 0, found: [] } }
        : sc
    ));
  }, []);

  // ── Selling players ──
  const listForSale = useCallback((player, source, askingPrice) => {
    setSellList((list) => {
      if (list.some((s) => s.playerId === player.id)) return list;
      return [...list, {
        playerId: player.id,
        source,
        askingPrice: askingPrice || Math.round(playerMarketValue(player) * 1.15),
        offers: [],
        weeksListed: 0,
      }];
    });
  }, []);

  const unlistFromSale = useCallback((playerId) => {
    setSellList((list) => list.filter((s) => s.playerId !== playerId));
  }, []);

  const setAskingPrice = useCallback((playerId, price) => {
    setSellList((list) => list.map((s) =>
      s.playerId === playerId ? { ...s, askingPrice: price } : s
    ));
  }, []);

  // Clubs make their move between matches
  const refreshTransferOffers = useCallback(() => {
    if (sellList.length === 0 || world.length === 0) return;
    const newApproaches = [];
    setSellList((list) => list.map((entry) => {
      const player = (entry.source === "squad" ? squad : bench).find((p) => p.id === entry.playerId);
      if (!player) return entry;
      // Existing offers may be withdrawn if you keep them waiting
      const surviving = (entry.offers || []).filter((o) => o.patience > 1)
        .map((o) => ({ ...o, patience: o.patience - 1 }));
      const fresh = generateOffers(player, world, playerClubId, entry.askingPrice);
      const merged = [...surviving];
      fresh.forEach((f) => {
        if (!merged.some((m) => m.clubId === f.clubId)) merged.push(f);
      });
      const sorted = merged.sort((a, b) => b.amount - a.amount).slice(0, 4);
      // Flag a notable new approach so the manager hears about it
      const best = sorted[0];
      if (best && !surviving.some((o) => o.id === best.id)) {
        const value = playerMarketValue(player);
        if (best.amount >= value * 0.85) {
          newApproaches.push({ player, offer: best });
        }
      }
      return {
        ...entry,
        weeksListed: (entry.weeksListed || 0) + 1,
        offers: sorted,
      };
    }));
    if (newApproaches.length > 0) setApproachAlert(newApproaches);
  }, [sellList.length, world, playerClubId, squad, bench]);

  const acceptOffer = useCallback((playerId, offerId) => {
    const entry = sellList.find((s) => s.playerId === playerId);
    if (!entry) return;
    const offer = (entry.offers || []).find((o) => o.id === offerId);
    if (!offer) return;
    const player = (entry.source === "squad" ? squad : bench).find((p) => p.id === playerId);
    if (!player) return;

    setAgreedSales((sales) => [...sales, { player, offer, source: entry.source }]);
    setSellList((list) => list.filter((s) => s.playerId !== playerId));
  }, [sellList, squad, bench]);

  const rejectOffer = useCallback((playerId, offerId) => {
    setSellList((list) => list.map((s) =>
      s.playerId === playerId
        ? { ...s, offers: (s.offers || []).filter((o) => o.id !== offerId) }
        : s
    ));
  }, []);

  // ── Sale negotiations ──
  const openSaleTalks = useCallback((playerId, offerId) => {
    const entry = sellList.find((s) => s.playerId === playerId);
    if (!entry) return;
    const offer = (entry.offers || []).find((o) => o.id === offerId);
    if (!offer) return;
    const player = (entry.source === "squad" ? squad : bench).find((p) => p.id === playerId);
    if (!player) return;

    const myClub = world.find((cl) => cl.id === playerClubId);
    const reaction = playerReactionToSale(player, offer, myClub?.reputation ?? 40);

    setSaleTalks({
      playerId, offerId, player, source: entry.source,
      offer, currentAmount: offer.amount,
      counter: Math.round(offer.amount * 1.2),
      round: 0, reaction,
      log: [{ who: "them", text: `We'd like to take ${player.lastName}. Our opening offer is $${offer.amount}.` }],
      status: "talking",
    });
  }, [sellList, squad, bench, world, playerClubId]);

  const submitCounter = useCallback(() => {
    if (!saleTalks || saleTalks.status !== "talking") return;
    const { offer, player, counter, round, currentAmount } = saleTalks;
    const nextRound = round + 1;
    const result = evaluateCounter({ ...offer, amount: currentAmount }, player, counter, nextRound);

    setSaleTalks((t) => {
      const log = [...t.log, { who: "you", text: `We want $${counter} for him.` }];
      if (result.verdict === "accept") {
        log.push({ who: "them", text: `Agreed. $${result.amount} it is — we'll get the paperwork done.` });
        return { ...t, round: nextRound, currentAmount: result.amount, log, status: "agreed" };
      }
      if (result.verdict === "counter") {
        log.push({ who: "them", text: `That's beyond us. We can stretch to $${result.amount}, no further.` });
        return {
          ...t, round: nextRound, currentAmount: result.amount,
          counter: Math.round(result.amount * 1.08), log, status: "talking",
        };
      }
      log.push({ who: "them", text: `Then we're wasting each other's time. The offer's withdrawn.` });
      return { ...t, round: nextRound, log, status: "collapsed" };
    });
  }, [saleTalks]);

  const acceptFromTalks = useCallback(() => {
    if (!saleTalks) return;
    const { playerId, offerId, player, source, offer, currentAmount, reaction } = saleTalks;
    setAgreedSales((sales) => [...sales, {
      player, source,
      offer: { ...offer, amount: currentAmount },
    }]);
    setSellList((list) => list.filter((s) => s.playerId !== playerId));
    if (reaction && reaction.morale) {
      setMorale((m) => Math.max(0, Math.min(100, m + reaction.morale)));
    }
    setSaleTalks(null);
  }, [saleTalks]);

  const closeSaleTalks = useCallback(() => {
    if (saleTalks && saleTalks.status === "collapsed") {
      // The club walked — their offer is gone for good
      const { playerId, offerId } = saleTalks;
      setSellList((list) => list.map((s) =>
        s.playerId === playerId
          ? { ...s, offers: (s.offers || []).filter((o) => o.id !== offerId) }
          : s
      ));
    }
    setSaleTalks(null);
  }, [saleTalks]);

  const cancelSale = useCallback((playerId) => {
    setAgreedSales((sales) => sales.filter((s) => s.player.id !== playerId));
  }, []);

  const clearAssignment = useCallback((scoutId) => {
    setHiredScouts((list) => list.map((sc) =>
      sc.id === scoutId ? { ...sc, assignment: null } : sc
    ));
  }, []);

  // Scouts do their work between matches
  const runScoutingCycle = useCallback(() => {
    if (hiredScouts.length === 0 || worldPlayers.length === 0) return;
    setHiredScouts((list) => list.map((sc) => advanceScouting(sc, worldPlayers)));
  }, [hiredScouts.length, worldPlayers]);

  // ── Transfer pool — a live view of who's available across the world ──
  useEffect(() => {
    if (screen !== "main") return;
    if (!world.length || !playerClubId) return;
    if (worldPlayers.length === 0) {
      setWorldPlayers(buildTransferPool(world, playerClubId));
    }
  }, [screen, world, playerClubId, worldPlayers.length]);

  // ── Scout reports: what your scouts have actually turned up ──
  const scoutReports = useMemo(() => {
    if (hiredScouts.length === 0 || worldPlayers.length === 0) return [];
    const listedIds = new Set(transferList.map((p) => p.id));
    const pendingIds = new Set(pendingSignings.map((ps) => ps.player.id));
    const byId = new Map(worldPlayers.map((p) => [p.id, p]));

    const reports = [];
    hiredScouts.forEach((sc) => {
      const found = sc.assignment?.found || [];
      found.forEach((f) => {
        const player = byId.get(f.playerId);
        if (!player) return;
        if (blacklist.includes(player.id) || listedIds.has(player.id) || pendingIds.has(player.id)) return;
        reports.push({ scout: sc, player, report: buildScoutReport(sc, player, f.progress) });
      });
    });
    // Best prospects first, by what the scout believes they could become
    return reports.sort((a, b) => b.report.potentialStars - a.report.potentialStars);
  }, [hiredScouts, worldPlayers, blacklist, transferList, pendingSignings]);

  // Filtered, visible players
  const visiblePlayers = useMemo(() => {
    const listedIds = new Set(transferList.map((p) => p.id));
    const pendingIds = new Set(pendingSignings.map((ps) => ps.player.id));
    const nameQuery = filterName.trim().toLowerCase();

    return worldPlayers.filter((p) => {
      if (blacklist.includes(p.id)) return false;
      if (listedIds.has(p.id) || pendingIds.has(p.id)) return false;
      if (filterPos !== "ALL" && p.naturalPosition !== filterPos && !(p.altPositions || []).includes(filterPos)) return false;
      if (p.ovr < filterMinOvr) return false;
      if (p.age > filterMaxAge) return false;
      if (nameQuery && !`${p.firstName} ${p.lastName}`.toLowerCase().includes(nameQuery)) return false;
      return true;
    }).sort((a, b) => b.ovr - a.ovr);
  }, [worldPlayers, blacklist, transferList, pendingSignings, filterPos, filterMinOvr, filterMaxAge, filterName]);

  // ── List a player for transfer ──
  const listPlayer = useCallback((player) => {
    if (transferList.some((p) => p.id === player.id)) return;
    if (blacklist.includes(player.id)) return;
    setTransferList((l) => [...l, player]);
  }, [transferList, blacklist]);

  const unlistPlayer = useCallback((playerId) => {
    setTransferList((l) => l.filter((p) => p.id !== playerId));
  }, []);

  // ── Interview / Negotiation ──
  const startInterview = useCallback((player) => {
    const prestige = calculatePrestige(trophies);
    const demands = getAgentDemands(player, prestige);
    setInterview({
      player, demands, prestige,
      offer: { salary: demands.salary, clause: demands.clause },
      stage: "demands", // demands → offer → result
      result: null,
    });
  }, [trophies]);

  const updateOffer = useCallback((field, value) => {
    setInterview((iv) => iv ? { ...iv, offer: { ...iv.offer, [field]: value } } : iv);
  }, []);

  const submitOffer = useCallback(() => {
    if (!interview) return;
    const { player, demands, offer, prestige } = interview;
    const verdict = evaluateOffer(demands, offer, prestige);

    if (verdict === "accept") {
      const fee = demands.signingFee;
      if (money < fee) {
        setInterview((iv) => ({ ...iv, stage: "result", result: "nofunds" }));
        return;
      }
      setMoney((m) => m - fee);
      setPendingSignings((p) => [...p, {
        player: { ...player, agreedSalary: offer.salary, releaseClause: offer.clause },
        salary: offer.salary, clause: offer.clause, fee,
      }]);
      setTransferList((l) => l.filter((p) => p.id !== player.id));
      setInterview((iv) => ({ ...iv, stage: "result", result: "accept" }));
    } else {
      setBlacklist((b) => [...b, player.id]);
      setTransferList((l) => l.filter((p) => p.id !== player.id));
      setInterview((iv) => ({ ...iv, stage: "result", result: "reject" }));
    }
  }, [interview, money]);

  const closeInterview = useCallback(() => setInterview(null), []);

  // ── Match simulation ──
  const startMatch = useCallback(() => {
    if (!season) return;
    const match = season[matchIdx];
    const moraleBonus = getMoraleMatchBonus(morale);
    const trainBonus = TRAINING_LEVELS[trainingLevel].matchBonus;
    // League opponents now think like their manager, the same way cup
    // opponents already did — previously match.oppTactic was undefined,
    // so every league side fell back to the same default behaviour.
    const oppTacticKey = match.oppManager
      ? managerPickTactic(match.oppManager, { scoreDiff: 0, minute: 0 })
      : (match.oppTactic || "balanced");
    const oppInstr = match.oppManager ? managerInstructions(match.oppManager) : null;

    // Home advantage finally means something: the fixture already knew who
    // was at home, but nothing in the engine ever used it.
    const homeEdge = match.isHome ? HOME_ADVANTAGE : 0;
    const awayEdge = match.isHome ? 0 : HOME_ADVANTAGE;

    const gen = runMatch(
      {
        name: clubName, squad, slotPositions, bench,
        formationKey: formation,
        behaviour: resolveBehaviour(selectedTactic, instructions),
        tacticKey: selectedTactic,
        bonus: chemistry.bonus + moraleBonus + trainBonus + homeEdge,
      },
      {
        name: match.opponent, squad: match.oppSquad.slice(0, 11),
        slotPositions: FORMATIONS[match.formation].positions,
        formationKey: match.formation,
        bench: match.oppSquad.slice(11),
        behaviour: resolveBehaviour(oppTacticKey, oppInstr),
        tacticKey: oppTacticKey,
        bonus: awayEdge,
      }
    );
    liveSim.current = { gen, meta: { moraleBonus, trainBonus, homeEdge } };
    orderRef.current = null;
    seenEventsRef.current = 0;
    frameQueue.current = [];
    snapshotRef.current = null;
    lastFrameRef.current = null;
    pendingRevealRef.current = null;
    postRevealRef.current = false;
    setPlannedSubs([]); setPlannedTactic(null); setPlannedShape(null); setPickOff(null);
    setMatchPaused(false);
    setLiveState(null);
    setMatchResult({ events: [], homeGoals: 0, awayGoals: 0 });
    setVisibleEvents(0);
    setMatchPhase("simulating");
    setSimTick((t) => t + 1);
  }, [season, matchIdx, squad, slotPositions, selectedTactic, instructions, chemistry, morale, trainingLevel, clubName]);

  // Drives the live match forward one possession at a time. Pausing simply
  // stops the clock — the simulation state sits untouched until you resume.
  useEffect(() => {
    if (matchPhase !== "simulating") return;
    if (matchPaused) return;
    const sim = liveSim.current;
    if (!sim) return;

    // Pace on what JUST happened: a fresh event gets its full dramatic pause,
    // quiet possessions tick by quickly so the match doesn't crawl.
    // How long each stage of a move lingers on screen. Building out from the
    // back is patient; the final ball and the shot come quicker. Everything is
    // divided by the speed the manager has chosen.
    const STAGE_MS = [1150, 950, 800, 650];
    const IDLE_MS = 900;

    const queued = frameQueue.current;
    const before = matchResult?.events?.length ?? 0;
    const isNew = before > seenEventsRef.current;
    const lastEvt = matchResult?.events?.[before - 1];

    const lingerFor = (f) => {
      if (!f) return 600;
      if (f.setPiece && f.stage === "setup") return 1400;   // players take up their positions
      if (f.stage === "delivery") return 1700;              // the ball in, the duel in the air
      if (f.stage === "quick") return 700;
      if (f.restart) return f.long ? 1500 : 1150;
      if (f.duel) return f.duel.card ? 1400 : 1050;      // close in, make contact
      if (f.won) return 800;                              // ball changes feet
      if (f.outcome) return f.outcome === "goal" ? 2000 : f.outcome === "miss" ? 1700 : 1900;
      return STAGE_MS[f.phase ?? 0];
    };
    // Shots always play out at watchable speed, whatever the match speed:
    // set, strike, flight, result. The setting-up touch gets a moment too.
    const realMinFor = (f) => {
      if (!f) return 0;
      if (f.stage === "delivery") return 1600;              // wind-up, flight, the header or clearance
      // Setting up, quick free kicks and routine restarts speed up with the match
      if (f.outcome) return f.outcome === "goal" ? 2000 : f.outcome === "miss" ? 1700 : 1900;
      if (f.phase === 3) return 450;
      return 0;
    };

    const lf = lastFrameRef.current;
    let delay;
    if (queued.length || pendingRevealRef.current) {
      // Let the stage on screen finish before moving on
      delay = Math.max(lingerFor(lf) / matchSpeed, realMinFor(lf));
    } else if (postRevealRef.current) {
      delay = 350 / matchSpeed;                         // the shot's been seen — move on
    } else if (before === 0) {
      delay = 600 / matchSpeed;
    } else if (isNew && lastEvt) {
      delay = (eventRevealDelay(lastEvt) + 350) / matchSpeed;
    } else {
      delay = IDLE_MS / matchSpeed;
    }
    delay = Math.max(70, delay);
    seenEventsRef.current = before;

    const reveal = () => {
      const r = pendingRevealRef.current;
      pendingRevealRef.current = null;
      if (!r) return;
      setMatchResult(r);
      setVisibleEvents(r.events.length);
    };

    const timer = setTimeout(() => {
      // A shot has finished playing out: only now do the log and score catch up
      if (!frameQueue.current.length && pendingRevealRef.current) {
        reveal();
        postRevealRef.current = true;
        setSimTick((t) => t + 1);
        return;
      }
      postRevealRef.current = false;

      // Stages left in this move? Play the next one without advancing the
      // simulation — this is what lets you watch the ball actually travel.
      if (frameQueue.current.length && snapshotRef.current) {
        const frame = frameQueue.current.shift();
        lastFrameRef.current = frame;
        setLiveState({ ...snapshotRef.current, play: frame, frame: ++frameCountRef.current });
        // Last stage of the move: a tackle or a card is shown as it lands; a
        // shot waits until the ball has actually arrived (next tick).
        if (!frameQueue.current.length && !frame?.outcome) reveal();
        setSimTick((t) => t + 1);
        return;
      }

      const order = orderRef.current;
      orderRef.current = null;
      const step = sim.gen.next(order);

      if (step.done) {
        const final = { ...step.value, ...sim.meta };
        liveSim.current = null;
        setMatchResult(final);
        setVisibleEvents(final.events.length);
        setLiveState(null);
        setMatchPhase("result");
        return;
      }

      const v = step.value;
      const you = v.sides.home;
      const them = v.sides.away;
      const yourCoords = you.coords || [];
      const theirCoords = them.coords || [];
      // Label your XI and bench together, so a sub never shares a name on screen
      const yourLabelled = withLabels([...you.xi, ...you.bench]);
      const yourLabel = Object.fromEntries(yourLabelled.map((p) => [p.id, p.label]));
      const theirLabel = Object.fromEntries(withLabels(them.xi).map((p) => [p.id, p.label]));
      // A player sent off during this move is still shown for the move itself —
      // he commits the foul, sees the card, and is gone from the next one.
      const prevIds = new Set([...(snapshotRef.current?.xi || []), ...(snapshotRef.current?.oppXi || [])]
        .filter((p) => !p.sentOff).map((p) => p.id));   // only players who were still playing last time
      const justOff = (S) => S.sentOff.filter((x) => x.player && x.coord && prevIds.has(x.id));
      const snapshot = {
        minute: v.minute,
        ballDead: v.ballDead,
        subsUsed: you.subsUsed,
        formation: you.formationKey,
        oppFormation: them.formationKey,
        homeBeh: you.src.behaviour,
        awayBeh: them.src.behaviour,
        pulse: v.pulse,

        // Their shape is mirrored so the two teams face each other
        oppXi: them.xi.map((pl, i) => ({
          id: pl.id, lastName: pl.lastName, label: theirLabel[pl.id], slot: them.slots[i],
          role: pl.role, focus: pl.focus,
          x: 100 - (theirCoords[i]?.x ?? 50), y: 100 - (theirCoords[i]?.y ?? 50),
        })).concat(justOff(them).map((x) => ({
          id: x.id, lastName: x.name, label: x.name, slot: x.slot, role: x.player.role, focus: x.player.focus,
          x: 100 - x.coord.x, y: 100 - x.coord.y, sentOff: true,
        }))),
        xi: you.xi.map((pl, i) => ({
          id: pl.id, lastName: pl.lastName, label: yourLabel[pl.id], ovr: pl.ovr, slot: you.slots[i],
          role: pl.role, focus: pl.focus,
          x: yourCoords[i]?.x ?? 50, y: yourCoords[i]?.y ?? 50,
          condition: Math.max(0, Math.round(v.liveCondition(pl, v.minute))),
        })).concat(justOff(you).map((x) => ({
          id: x.id, lastName: x.name, label: x.name, ovr: x.player.ovr, slot: x.slot,
          role: x.player.role, focus: x.player.focus, x: x.coord.x, y: x.coord.y, condition: 0, sentOff: true,
        }))),
        bench: you.bench.map((pl) => ({
          id: pl.id, lastName: pl.lastName, label: yourLabel[pl.id], ovr: pl.ovr,
          pos: pl.naturalPosition, injured: !!pl.injuredFor,
        })),
      };
      snapshotRef.current = snapshot;
      // Queue the move's stages; show the first straight away
      const seq = (v.playSeq && v.playSeq.length) ? [...v.playSeq] : [];
      // A possession that broke down instantly leaves the ball where it was
      const first = seq.length ? seq.shift() : lastFrameRef.current;
      lastFrameRef.current = first;
      setLiveState({ ...snapshot, play: first, frame: ++frameCountRef.current });
      frameQueue.current = seq;
      pendingRevealRef.current = { events: [...v.events], homeGoals: v.homeGoals, awayGoals: v.awayGoals };
      if (!frameQueue.current.length && !first?.outcome) reveal();   // nothing left to watch
      if (eventLogRef.current) eventLogRef.current.scrollTop = eventLogRef.current.scrollHeight;
      setSimTick((t) => t + 1);
    }, delay);

    return () => clearTimeout(timer);
  }, [matchPhase, matchPaused, simTick, matchSpeed]);

  // Hand the queued changes to the engine, which holds them until the ball is dead
  const confirmMatchOrder = useCallback(() => {
    const subs = plannedSubs.map((sp) => ({ outId: sp.outId, inId: sp.inId }));
    const order = { side: "home" };
    if (subs.length) order.subs = subs;
    if (plannedTactic) {
      order.tacticKey = plannedTactic;
      order.tacticName = TACTICS[plannedTactic]?.name || plannedTactic;
      order.behaviour = resolveBehaviour(plannedTactic, instructions);
    }
    if (plannedShape) order.formation = plannedShape;
    if (order.subs || order.behaviour || order.formation) orderRef.current = order;
    setPlannedSubs([]); setPlannedTactic(null); setPlannedShape(null); setPickOff(null);
    setMatchPaused(false);
    setSimTick((t) => t + 1);
  }, [plannedSubs, plannedTactic, plannedShape, instructions]);

  const collectMatchReward = useCallback(() => {
    if (!matchResult || !season) return;
    const match = season[matchIdx];
    const won = matchResult.homeGoals > matchResult.awayGoals;
    const draw = matchResult.homeGoals === matchResult.awayGoals;
    const reward = won ? match.reward : draw ? Math.round(match.reward * 0.4) : Math.round(match.reward * 0.15);

    const scoutWages = hiredScouts.reduce((s, sc) => s + sc.wage, 0);
    const salary = getTotalSalary(squad) + scoutWages;
    const netReward = reward - salary;
    const canAffordSalary = (money + reward) >= salary;
    const benchRecovery = TRAINING_LEVELS[trainingLevel].benchRecovery;
    const trainMoraleBoost = TRAINING_LEVELS[trainingLevel].moraleBoost;
    const fitDrain = TACTICS[selectedTactic]?.fitnessDrain ?? 1.0;

    const mins = matchResult.minutes || {};
    const applyFit = (p) => ({
      ...p,
      minutesPlayed: (p.minutesPlayed || 0) + (mins[p.id] || 0),
      fitness: p.injuredFor > 0 ? 0 : Math.max(0, Math.min(100,
        (p.fitness ?? 100) + matchFitnessChange(p, mins[p.id], fitDrain, benchRecovery))),
      injuredFor: Math.max(0, (p.injuredFor || 0) - 1),
    });
    const updatedSquad = squad.map(applyFit);
    const updatedBench = bench.map(applyFit);

    setSquad(updatedSquad);
    setBench(updatedBench);
    setMoney((v) => Math.max(0, v + netReward));

    let moraleChange = won ? 6 : draw ? 0 : -8;
    if (chemistry.total < 30) moraleChange -= 3;
    if (chemistry.total > 70) moraleChange += 2;
    if (!canAffordSalary) moraleChange -= 10;
    moraleChange += trainMoraleBoost;
    // Bonus morale for players in natural roles
    const naturalRoleCount = squad.filter((p) => (p.activeRole || p.role) === p.role).length;
    if (naturalRoleCount >= 9) moraleChange += 3;
    else if (naturalRoleCount >= 6) moraleChange += 1;
    const newMorale = Math.max(0, Math.min(100, morale + moraleChange));
    setMorale(newMorale);

    const newSeason = [...season];
    newSeason[matchIdx] = { ...match, result: { ...matchResult, reward: netReward, outcome: won ? "W" : draw ? "D" : "L" } };
    setSeason(newSeason);
    setMatchIdx((i) => i + 1);
    setMatchPhase(null);
    setMatchResult(null);

    // Update league table — your result plus the other real fixtures.
    // Your own result must be recorded even if the other fixtures can't be
    // played (e.g. an older save with no stored fixture list); otherwise the
    // whole table silently freezes at zero.
    if (leagueTable) {
      const other = seasonData
        ? playOtherFixtures(world, seasonData, matchIdx, leagueTable)
        : { table: leagueTable.map((r) => ({ ...r, form: [...(r.form || [])] })), results: [] };
      const updatedTable = other.table.map((t) => {
        if (!t.isYou) return t;
        return {
          ...t,
          played: t.played + 1,
          won: t.won + (won ? 1 : 0),
          drawn: t.drawn + (draw ? 1 : 0),
          lost: t.lost + (!won && !draw ? 1 : 0),
          gf: t.gf + matchResult.homeGoals,
          ga: t.ga + matchResult.awayGoals,
          points: t.points + (won ? 3 : draw ? 1 : 0),
          form: [...(t.form || []), won ? "W" : draw ? "D" : "L"].slice(-5),
        };
      });
      setLeagueTable(updatedTable);
      setLastRoundResults(other.results);
    }

    // Your scouts have been out working while the team played
    runScoutingCycle();
    // And clubs have been watching the players you've made available
    refreshTransferOffers();

    const moraleEvent = checkMoraleEvents(newMorale, chemistry.total, canAffordSalary, updatedSquad, updatedBench);
    if (moraleEvent) {
      setActiveEvent(moraleEvent);
    } else {
      const randomEvent = pickRandomEvent(updatedSquad, updatedBench);
      if (randomEvent) setActiveEvent(randomEvent);
    }
  }, [matchResult, season, seasonData, world, matchIdx, squad, bench, money, morale, chemistry, trainingLevel, seasonNumber, leagueTable, selectedTactic, hiredScouts, runScoutingCycle, refreshTransferOffers]);

  const handleEventDismiss = useCallback(() => {
    if (!activeEvent) return;
    const { event, targetPlayer } = activeEvent;
    const currentState = { squad, bench, money, morale };
    const newState = event.apply(currentState, targetPlayer);
    setSquad(newState.squad);
    setBench(newState.bench);
    if (newState.money !== undefined) setMoney(newState.money);
    if (newState.morale !== undefined) setMorale(newState.morale);
    setActiveEvent(null);
  }, [activeEvent, squad, bench, money, morale]);

  /* ── Random-time event ticker: fires background events between matches ── */
  const lastBackgroundEventAt = useRef(0);
  useEffect(() => {
    if (screen !== "main") return;
    if (gameOver) return;

    const tick = () => {
      // Silence the ticker whenever anything modal-ish is on screen
      if (matchPhase) return;
      if (activeEvent) return;
      if (saleTalks) return;
      if (detailPlayer) return;
      if (transferWindow) return;
      if (interview) return;
      if (approachAlert) return;
      if (clubLeague && clPhase) return;

      // Don't fire more than once per 90s to avoid feeling spammy
      const now = Date.now();
      if (now - lastBackgroundEventAt.current < 90_000) return;

      // 22% chance per tick (combined with pickRandomEvent's own 50% = ~11% per tick)
      if (Math.random() > 0.22) return;

      const evt = pickRandomEvent(squad, bench);
      if (evt) {
        lastBackgroundEventAt.current = now;
        setActiveEvent(evt);
      }
    };

    // Check every 30 seconds — average event roughly every 4-5 minutes of idle time
    const timer = setInterval(tick, 30_000);
    return () => clearInterval(timer);
  }, [screen, gameOver, matchPhase, activeEvent, saleTalks, detailPlayer, transferWindow, interview, approachAlert, clubLeague, clPhase, squad, bench]);

  const upgradeTraining = useCallback(() => {
    const nextLevel = trainingLevel + 1;
    if (nextLevel >= TRAINING_LEVELS.length) return;
    const cost = TRAINING_LEVELS[nextLevel].cost;
    if (money < cost) return;
    setMoney((m) => m - cost);
    setTrainingLevel(nextLevel);
    setMorale((m) => Math.min(100, m + 5));
  }, [trainingLevel, money]);

  const changePlayerRole = useCallback((playerIdx, newRole) => {
    setSquad((sq) => sq.map((p, i) => i === playerIdx ? { ...p, activeRole: newRole } : p));
  }, []);

  const changePlayerFocus = useCallback((playerIdx, newFocus) => {
    setSquad((sq) => sq.map((p, i) => i === playerIdx ? { ...p, focus: newFocus } : p));
  }, []);

  const changeRoleById = useCallback((playerId, newRole) => {
    setSquad((sq) => sq.map((p) => p.id === playerId ? { ...p, activeRole: newRole } : p));
    setBench((b) => b.map((p) => p.id === playerId ? { ...p, activeRole: newRole } : p));
    setDetailPlayer((dp) => dp && dp.id === playerId ? { ...dp, activeRole: newRole } : dp);
  }, []);

  const changeFocusById = useCallback((playerId, newFocus) => {
    setSquad((sq) => sq.map((p) => p.id === playerId ? { ...p, focus: newFocus } : p));
    setBench((b) => b.map((p) => p.id === playerId ? { ...p, focus: newFocus } : p));
    setDetailPlayer((dp) => dp && dp.id === playerId ? { ...dp, focus: newFocus } : dp);
  }, []);

  const handleRecoverySession = useCallback(() => {
    if (money < REST_COST || clubLeague) return;
    setMoney((m) => m - REST_COST);
    setSquad((sq) => sq.map((p) => p.injuredFor > 0 ? p : { ...p, fitness: Math.min(100, (p.fitness ?? 100) + 30) }));
    setBench((b) => b.map((p) => p.injuredFor > 0 ? p : { ...p, fitness: Math.min(100, (p.fitness ?? 100) + 30) }));
  }, [money, clubLeague]);

  const currentMatch = season?.[matchIdx];

  /* ═══ WELCOME SCREEN ═══ */
  /* ═══ LOADING SCREEN ═══ */
  if (!hasLoadedSave) {
    return (
      <div style={{ minHeight: "100vh", background: N.bg, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Inter', system-ui, sans-serif" }}>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 44, marginBottom: 12, filter: "drop-shadow(0 0 12px rgba(0,229,255,0.4))" }}>⚽</div>
          <div style={{ fontSize: 14, color: N.muted, fontWeight: 600 }}>Loading...</div>
        </div>
      </div>
    );
  }

  /* ═══ WELCOME SCREEN ═══ */
  if (screen === "welcome") {
    return (
      <div style={{ minHeight: "100vh", background: N.bg, display: "flex", alignItems: "center", justifyContent: "center", padding: 20, fontFamily: "'Inter', system-ui, sans-serif" }}>
        <div style={{ width: "100%", maxWidth: 520, display: "flex", flexDirection: "column", alignItems: "center", gap: 24 }}>
          <div style={{ textAlign: "center" }}>
            <div style={{ fontSize: 44, marginBottom: 4, filter: "drop-shadow(0 0 12px rgba(0,229,255,0.4))" }}>⚽</div>
            <h1 style={{ fontSize: 28, fontWeight: 800, color: N.text, margin: 0 }}>
              <span style={{ background: `linear-gradient(135deg, ${N.cyan}, ${N.magenta})`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>NEON</span> FOOTBALL
            </h1>
            <p style={{ color: N.muted, fontSize: 13, margin: "6px 0 0" }}>Build your legacy from nothing</p>
          </div>
          <div style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 12, padding: "16px 24px", width: "100%", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <div>
              <p style={{ color: N.muted, fontSize: 10, fontWeight: 600, margin: "0 0 4px" }}>YOUR CLUB</p>
              {editingClub
                ? <input autoFocus value={clubName} onChange={(e) => setClubName(e.target.value)} onBlur={() => setEditingClub(false)} onKeyDown={(e) => { if (e.key === "Enter") setEditingClub(false); }} style={{ background: "transparent", border: "none", borderBottom: `2px solid ${N.cyan}`, color: N.cyan, fontSize: 18, fontWeight: 800, outline: "none", width: 200 }} />
                : <p onClick={() => setEditingClub(true)} style={{ color: N.cyan, fontSize: 18, fontWeight: 800, margin: 0, cursor: "pointer" }}>{clubName} ✏️</p>
              }
            </div>
            <div style={{ textAlign: "right" }}>
              <p style={{ color: N.muted, fontSize: 10, fontWeight: 600, margin: "0 0 4px" }}>BUDGET</p>
              <p style={{ color: N.gold, fontSize: 22, fontWeight: 900, margin: 0 }}>${money}</p>
            </div>
          </div>
          <div style={{ width: "100%" }}>
            <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: N.muted, marginBottom: 8 }}>Manager Name</label>
            <input type="text" placeholder="Enter your name, boss..." value={managerName} onChange={(e) => setManagerName(e.target.value)} onKeyDown={(e) => e.key === "Enter" && handleStart()} autoFocus
              style={{ width: "100%", padding: "14px 16px", fontSize: 16, background: N.card, border: `1.5px solid ${N.border}`, borderRadius: 8, color: N.text, outline: "none", boxSizing: "border-box" }}
              onFocus={(e) => { e.target.style.borderColor = N.cyan; }} onBlur={(e) => { e.target.style.borderColor = N.border; }} />
          </div>
          <div style={{ width: "100%" }}>
            <label style={{ display: "block", fontSize: 12, fontWeight: 600, color: N.muted, marginBottom: 10 }}>Choose Formation</label>
            <div style={{ display: "flex", gap: 10, overflowX: "auto", paddingBottom: 6 }}>
              {FORMATION_KEYS.map((f) => <div key={f} onClick={() => setFormation(f)}><FormationPreview formation={f} active={formation === f} /></div>)}
            </div>
          </div>
          <button onClick={handleStart} disabled={!managerName.trim()} style={{ width: "100%", padding: "16px", fontSize: 16, fontWeight: 800, background: managerName.trim() ? `linear-gradient(135deg, ${N.cyan}, ${N.magenta})` : N.card, border: "none", borderRadius: 10, color: managerName.trim() ? "#000" : N.muted, cursor: managerName.trim() ? "pointer" : "not-allowed", letterSpacing: 1 }}>
            START CAREER ▶
          </button>
        </div>
      </div>
    );
  }

  /* ═══ MAIN GAME ═══ */
  return (
    <div style={{ minHeight: "100vh", background: N.bg, fontFamily: "'Inter', system-ui, sans-serif", color: N.text }} onClick={() => setSelected(null)}>
      {detailPlayer && (() => {
        const inSquad = squad.some((p) => p.id === detailPlayer.id);
        const onBench = bench.some((p) => p.id === detailPlayer.id);
        const isMine = inSquad || onBench;
        const slotPositions = FORMATIONS[formation].positions;
        // Tag partners with their slot info so the picker can show warnings
        const otherGroup = inSquad
          ? bench.map((p) => ({ ...p, _slot: null }))
          : onBench
          ? squad.map((p, i) => ({ ...p, _slot: slotPositions[i] }))
          : [];
        return (
          <PlayerDetailModal
            player={detailPlayer}
            slotPos={detailSlot}
            onClose={() => { setDetailPlayer(null); setDetailSlot(null); }}
            onRoleChange={changeRoleById}
            onFocusChange={changeFocusById}
            onTransferList={isMine ? ((p) => {
              listForSale(p, inSquad ? "squad" : "bench");
              setDetailPlayer(null); setDetailSlot(null);
              setTab("transfers"); setTransferSubTab("sell");
            }) : null}
            isListed={sellList.some((s) => s.playerId === detailPlayer.id)}
            inSquad={inSquad}
            onBench={onBench}
            otherGroup={otherGroup}
            onSwap={isMine ? ((a, b) => {
              // a is the player being viewed, b is who they swap with
              // Find their indices in the correct arrays
              const ns = [...squad];
              const nb = [...bench];
              const aInSquad = ns.some((p) => p.id === a.id);
              const bInSquad = ns.some((p) => p.id === b.id);
              const aIdx = aInSquad ? ns.findIndex((p) => p.id === a.id) : nb.findIndex((p) => p.id === a.id);
              const bIdx = bInSquad ? ns.findIndex((p) => p.id === b.id) : nb.findIndex((p) => p.id === b.id);
              if (aIdx === -1 || bIdx === -1) return;
              const aArr = aInSquad ? ns : nb;
              const bArr = bInSquad ? ns : nb;
              // Strip any _slot / _group / _idx metadata tags before swapping back
              const cleanA = { ...aArr[aIdx] }; delete cleanA._slot; delete cleanA._group; delete cleanA._idx;
              const cleanB = { ...bArr[bIdx] }; delete cleanB._slot; delete cleanB._group; delete cleanB._idx;
              aArr[aIdx] = cleanB;
              bArr[bIdx] = cleanA;
              setSquad(ns); setBench(nb);
              setDetailPlayer(null); setDetailSlot(null);
            }) : null}
          />
        );
      })()}

      {/* ═══ SALE NEGOTIATION MODAL ═══ */}
      {saleTalks && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1100, background: "rgba(0,0,0,0.88)", backdropFilter: "blur(8px)", display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }} onClick={(e) => e.stopPropagation()}>
          <div style={{ width: "100%", maxWidth: 470, maxHeight: "92vh", overflowY: "auto", background: N.surface, borderRadius: 14, border: `1px solid ${N.border}` }}>
            {/* Header */}
            <div style={{ padding: "16px 20px", background: `linear-gradient(135deg, ${N.card}, ${N.surface})`, borderBottom: `1px solid ${N.border}`, borderRadius: "14px 14px 0 0", display: "flex", alignItems: "center", gap: 12 }}>
              {(() => {
                const ts = TIER_STYLES[getTier(saleTalks.player.ovr)];
                return (
                  <div style={{ width: 46, height: 58, background: ts.bg, borderRadius: 6, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                    <span style={{ fontSize: 19, fontWeight: 900, color: ts.text, lineHeight: 1 }}>{saleTalks.player.ovr}</span>
                    <span style={{ fontSize: 7, fontWeight: 800, color: ts.statLabel }}>{saleTalks.player.naturalPosition}</span>
                  </div>
                );
              })()}
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 16, fontWeight: 800, color: N.text }}>{saleTalks.player.firstName} {saleTalks.player.lastName}</div>
                <div style={{ fontSize: 11, color: N.muted }}>
                  Talks with {saleTalks.offer.clubName} · Div {saleTalks.offer.clubDivision}
                </div>
                <div style={{ fontSize: 10, color: N.gold }}>Valued at ${playerMarketValue(saleTalks.player)}</div>
              </div>
            </div>

            {/* Player's stance */}
            <div style={{ padding: "10px 20px", borderBottom: `1px solid ${N.border}`, background: N.card }}>
              {(() => {
                const r = saleTalks.reaction;
                const col = r.mood === "eager" ? N.green : r.mood === "keen" ? N.cyan : r.mood === "neutral" ? N.gold : "#ff4060";
                return (
                  <div style={{ fontSize: 11, color: N.muted }}>
                    <span style={{ color: col, fontWeight: 700 }}>{saleTalks.player.lastName}</span> is {r.text}.
                    {r.morale ? <span style={{ color: "#ff6b6b" }}> Selling him costs {Math.abs(r.morale)} morale.</span> : null}
                  </div>
                );
              })()}
            </div>

            {/* Transcript */}
            <div style={{ padding: "14px 20px", maxHeight: 230, overflowY: "auto", display: "flex", flexDirection: "column", gap: 8 }}>
              {saleTalks.log.map((entry, i) => (
                <div key={i} style={{
                  alignSelf: entry.who === "you" ? "flex-end" : "flex-start",
                  maxWidth: "85%", padding: "8px 12px", borderRadius: 10,
                  background: entry.who === "you" ? `${N.cyan}15` : N.card,
                  border: `1px solid ${entry.who === "you" ? N.cyan + "30" : N.border}`,
                }}>
                  <div style={{ fontSize: 9, fontWeight: 700, color: entry.who === "you" ? N.cyan : N.muted, marginBottom: 2 }}>
                    {entry.who === "you" ? "YOU" : saleTalks.offer.clubName.toUpperCase()}
                  </div>
                  <div style={{ fontSize: 12, color: N.text, lineHeight: 1.5 }}>{entry.text}</div>
                </div>
              ))}
            </div>

            {/* Controls */}
            <div style={{ padding: "12px 20px 18px", borderTop: `1px solid ${N.border}` }}>
              {saleTalks.status === "talking" && (
                <>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                    <span style={{ fontSize: 11, color: N.muted }}>On the table</span>
                    <span style={{ fontSize: 14, fontWeight: 900, color: N.gold }}>${saleTalks.currentAmount}</span>
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                    <span style={{ fontSize: 12, fontWeight: 700, color: N.text }}>Your demand</span>
                    <span style={{ fontSize: 15, fontWeight: 900, color: N.cyan }}>${saleTalks.counter}</span>
                  </div>
                  <input type="range"
                    min={saleTalks.currentAmount}
                    max={Math.round(saleTalks.currentAmount * 2.2)}
                    value={saleTalks.counter}
                    onChange={(e) => setSaleTalks((t) => ({ ...t, counter: Number(e.target.value) }))}
                    style={{ width: "100%", accentColor: N.cyan }} />
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 9, color: N.muted, marginBottom: 10 }}>
                    <span>Accept theirs</span><span>Push hard</span>
                  </div>
                  <div style={{ fontSize: 10, color: N.muted, marginBottom: 10, lineHeight: 1.5 }}>
                    Round {saleTalks.round + 1} of 3. Push too far and they'll walk away for good.
                  </div>
                  <div style={{ display: "flex", gap: 8 }}>
                    <button onClick={submitCounter} style={{
                      flex: 1, padding: "11px", fontSize: 13, fontWeight: 800, borderRadius: 8,
                      background: `linear-gradient(135deg, ${N.cyan}, ${N.magenta})`, border: "none", color: "#000", cursor: "pointer",
                    }}>DEMAND ${saleTalks.counter}</button>
                    <button onClick={acceptFromTalks} style={{
                      flex: 1, padding: "11px", fontSize: 13, fontWeight: 800, borderRadius: 8,
                      background: `${N.green}18`, border: `1px solid ${N.green}40`, color: N.green, cursor: "pointer",
                    }}>ACCEPT ${saleTalks.currentAmount}</button>
                  </div>
                  <button onClick={closeSaleTalks} style={{
                    width: "100%", padding: "9px", fontSize: 11, fontWeight: 700, borderRadius: 8, marginTop: 8,
                    background: "transparent", border: `1px solid ${N.border}`, color: N.muted, cursor: "pointer",
                  }}>Leave it for now</button>
                </>
              )}

              {saleTalks.status === "agreed" && (
                <div style={{ textAlign: "center" }}>
                  <div style={{ fontSize: 34, marginBottom: 8 }}>🤝</div>
                  <div style={{ fontSize: 17, fontWeight: 900, color: N.green, marginBottom: 6 }}>DEAL AGREED</div>
                  <div style={{ fontSize: 12, color: N.text, marginBottom: 12 }}>
                    {saleTalks.player.lastName} joins {saleTalks.offer.clubName} for <b style={{ color: N.gold }}>${saleTalks.currentAmount}</b> when the window opens.
                  </div>
                  <button onClick={acceptFromTalks} style={{
                    padding: "11px 30px", fontSize: 13, fontWeight: 800, borderRadius: 8,
                    background: `linear-gradient(135deg, ${N.green}, ${N.cyan})`, border: "none", color: "#000", cursor: "pointer",
                  }}>CONFIRM SALE</button>
                </div>
              )}

              {saleTalks.status === "collapsed" && (
                <div style={{ textAlign: "center" }}>
                  <div style={{ fontSize: 34, marginBottom: 8 }}>🚪</div>
                  <div style={{ fontSize: 17, fontWeight: 900, color: "#ff4060", marginBottom: 6 }}>TALKS COLLAPSED</div>
                  <div style={{ fontSize: 12, color: N.muted, marginBottom: 12 }}>
                    {saleTalks.offer.clubName} have withdrawn. You pushed too hard.
                  </div>
                  <button onClick={closeSaleTalks} style={{
                    padding: "11px 30px", fontSize: 13, fontWeight: 800, borderRadius: 8,
                    background: N.card, border: `1px solid ${N.border}`, color: N.text, cursor: "pointer",
                  }}>CLOSE</button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ═══ INTERVIEW / NEGOTIATION MODAL ═══ */}
      {interview && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1100, background: "rgba(0,0,0,0.88)", backdropFilter: "blur(8px)", display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }} onClick={(e) => e.stopPropagation()}>
          <div style={{ width: "100%", maxWidth: 480, maxHeight: "92vh", overflowY: "auto", background: N.surface, borderRadius: 14, border: `1px solid ${N.border}` }}>
            {/* Header */}
            <div style={{ padding: "18px 22px", background: `linear-gradient(135deg, ${N.card}, ${N.surface})`, borderBottom: `1px solid ${N.border}`, borderRadius: "14px 14px 0 0", display: "flex", alignItems: "center", gap: 14 }}>
              {(() => {
                const ts = TIER_STYLES[getTier(interview.player.ovr)];
                return (
                  <div style={{ width: 52, height: 66, background: ts.bg, borderRadius: 6, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                    <span style={{ fontSize: 21, fontWeight: 900, color: ts.text, lineHeight: 1 }}>{interview.player.ovr}</span>
                    <span style={{ fontSize: 8, fontWeight: 800, color: ts.statLabel }}>{interview.player.naturalPosition}</span>
                  </div>
                );
              })()}
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 17, fontWeight: 800, color: N.text }}>{interview.player.firstName} {interview.player.lastName}</div>
                <div style={{ fontSize: 11, color: N.muted }}>{interview.player.nationality} · Age {interview.player.age} · {interview.player.role}</div>
                {(() => {
                  const pot = getPotentialLabel(interview.player.ovr, interview.player.potential);
                  return <div style={{ fontSize: 11, color: pot.color, fontWeight: 700 }}>{pot.icon} POT {interview.player.potential}</div>;
                })()}
              </div>
            </div>

            {/* Stage: Agent demands */}
            {interview.stage === "demands" && (
              <div style={{ padding: "18px 22px" }}>
                <div style={{ padding: "12px 14px", borderRadius: 8, background: N.card, border: `1px solid ${N.border}`, marginBottom: 16 }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: N.gold, marginBottom: 6 }}>🤝 THE AGENT SPEAKS</div>
                  <div style={{ fontSize: 12, color: N.text, lineHeight: 1.6 }}>
                    "My client is interested in joining {clubName}. But we have terms. He wants <span style={{ color: N.gold, fontWeight: 800 }}>${interview.demands.salary}/match</span> in wages and a release clause of at least <span style={{ color: N.gold, fontWeight: 800 }}>${interview.demands.clause}</span>. There's also a signing fee of <span style={{ color: N.gold, fontWeight: 800 }}>${interview.demands.signingFee}</span>. Make us a serious offer."
                  </div>
                </div>
                <div style={{ fontSize: 11, color: N.muted, marginBottom: 14, lineHeight: 1.5 }}>
                  ⚠️ Lowball them and they'll walk away <span style={{ color: "#ff4060", fontWeight: 700 }}>permanently</span>. Your club prestige ({interview.prestige}) makes them slightly more forgiving.
                </div>
                <button onClick={() => setInterview((iv) => ({ ...iv, stage: "offer" }))} style={{
                  width: "100%", padding: "12px", fontSize: 13, fontWeight: 800, borderRadius: 8,
                  background: `linear-gradient(135deg, ${N.cyan}, ${N.magenta})`, border: "none", color: "#000", cursor: "pointer",
                }}>MAKE AN OFFER →</button>
                <button onClick={closeInterview} style={{
                  width: "100%", padding: "10px", fontSize: 12, fontWeight: 700, borderRadius: 8, marginTop: 8,
                  background: "transparent", border: `1px solid ${N.border}`, color: N.muted, cursor: "pointer",
                }}>Walk away for now</button>
              </div>
            )}

            {/* Stage: Make offer */}
            {interview.stage === "offer" && (
              <div style={{ padding: "18px 22px" }}>
                {/* Salary slider */}
                <div style={{ marginBottom: 18 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                    <span style={{ fontSize: 12, fontWeight: 700, color: N.text }}>Weekly Salary</span>
                    <span style={{ fontSize: 14, fontWeight: 900, color: interview.offer.salary >= interview.demands.salary ? N.green : "#ff4060" }}>${interview.offer.salary}/match</span>
                  </div>
                  <input type="range" min={Math.max(1, Math.round(interview.demands.salary * 0.5))} max={Math.round(interview.demands.salary * 1.5)}
                    value={interview.offer.salary} onChange={(e) => updateOffer("salary", Number(e.target.value))}
                    style={{ width: "100%", accentColor: N.cyan }} />
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 9, color: N.muted }}>
                    <span>Lowball</span><span>Asking: ${interview.demands.salary}</span><span>Generous</span>
                  </div>
                </div>

                {/* Release clause slider */}
                <div style={{ marginBottom: 18 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                    <span style={{ fontSize: 12, fontWeight: 700, color: N.text }}>Release Clause</span>
                    <span style={{ fontSize: 14, fontWeight: 900, color: interview.offer.clause >= interview.demands.clause ? N.green : "#ff4060" }}>${interview.offer.clause}</span>
                  </div>
                  <input type="range" min={Math.round(interview.demands.clause * 0.4)} max={Math.round(interview.demands.clause * 1.6)}
                    value={interview.offer.clause} onChange={(e) => updateOffer("clause", Number(e.target.value))}
                    style={{ width: "100%", accentColor: N.gold }} />
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 9, color: N.muted }}>
                    <span>Low</span><span>Asking: ${interview.demands.clause}</span><span>High</span>
                  </div>
                </div>

                {/* Signing fee */}
                <div style={{ padding: "10px 14px", borderRadius: 8, background: N.card, marginBottom: 16, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ fontSize: 12, color: N.muted }}>Signing fee (fixed)</span>
                  <span style={{ fontSize: 14, fontWeight: 800, color: money >= interview.demands.signingFee ? N.gold : "#ff4060" }}>${interview.demands.signingFee}</span>
                </div>

                <button onClick={submitOffer} style={{
                  width: "100%", padding: "13px", fontSize: 14, fontWeight: 800, borderRadius: 8,
                  background: `linear-gradient(135deg, ${N.green}, ${N.cyan})`, border: "none", color: "#000", cursor: "pointer",
                }}>SUBMIT OFFER ✍️</button>
                <button onClick={() => setInterview((iv) => ({ ...iv, stage: "demands" }))} style={{
                  width: "100%", padding: "10px", fontSize: 12, fontWeight: 700, borderRadius: 8, marginTop: 8,
                  background: "transparent", border: `1px solid ${N.border}`, color: N.muted, cursor: "pointer",
                }}>← Back</button>
              </div>
            )}

            {/* Stage: Result */}
            {interview.stage === "result" && (
              <div style={{ padding: "24px 22px", textAlign: "center" }}>
                {interview.result === "accept" && (
                  <>
                    <div style={{ fontSize: 44, marginBottom: 10 }}>🤝</div>
                    <div style={{ fontSize: 20, fontWeight: 900, color: N.green, marginBottom: 8 }}>DEAL AGREED!</div>
                    <div style={{ fontSize: 12, color: N.text, lineHeight: 1.6, marginBottom: 6 }}>
                      "Excellent. My client is delighted. He'll join {clubName} when the transfer window opens."
                    </div>
                    <div style={{ fontSize: 11, color: N.muted, marginBottom: 16 }}>
                      Signing fee of ${interview.demands.signingFee} paid. Check the <b>Agreed</b> tab.
                    </div>
                  </>
                )}
                {interview.result === "reject" && (
                  <>
                    <div style={{ fontSize: 44, marginBottom: 10 }}>🚪</div>
                    <div style={{ fontSize: 20, fontWeight: 900, color: "#ff4060", marginBottom: 8 }}>OFFER REJECTED</div>
                    <div style={{ fontSize: 12, color: N.text, lineHeight: 1.6, marginBottom: 6 }}>
                      "That's an insult to my client. We're done here — don't contact us again."
                    </div>
                    <div style={{ fontSize: 11, color: "#ff4060", marginBottom: 16 }}>
                      {interview.player.firstName} {interview.player.lastName} will never join your club.
                    </div>
                  </>
                )}
                {interview.result === "nofunds" && (
                  <>
                    <div style={{ fontSize: 44, marginBottom: 10 }}>💸</div>
                    <div style={{ fontSize: 20, fontWeight: 900, color: N.gold, marginBottom: 8 }}>NOT ENOUGH FUNDS</div>
                    <div style={{ fontSize: 12, color: N.text, lineHeight: 1.6, marginBottom: 16 }}>
                      Terms were acceptable, but you can't afford the ${interview.demands.signingFee} signing fee. Come back with more money.
                    </div>
                  </>
                )}
                <button onClick={closeInterview} style={{
                  padding: "11px 30px", fontSize: 13, fontWeight: 800, borderRadius: 8,
                  background: `linear-gradient(135deg, ${N.cyan}, ${N.magenta})`, border: "none", color: "#000", cursor: "pointer",
                }}>CLOSE</button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Random Event Modal */}
      {activeEvent && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1100, background: "rgba(0,0,0,0.85)", backdropFilter: "blur(8px)", display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }} onClick={(e) => e.stopPropagation()}>
          <div style={{
            width: "100%", maxWidth: 420, background: N.surface, borderRadius: 14,
            border: `1px solid ${activeEvent.event.type === "positive" ? N.green + "40" : "#ff406040"}`,
            boxShadow: `0 0 40px ${activeEvent.event.type === "positive" ? N.green + "20" : "#ff406020"}`,
            overflow: "hidden",
          }}>
            {/* Event header */}
            <div style={{
              padding: "20px 24px", textAlign: "center",
              background: activeEvent.event.type === "positive"
                ? `linear-gradient(135deg, ${N.green}10, ${N.green}05)`
                : `linear-gradient(135deg, #ff406010, #ff406005)`,
              borderBottom: `1px solid ${N.border}`,
            }}>
              <div style={{ fontSize: 40, marginBottom: 8 }}>{activeEvent.event.icon}</div>
              <div style={{
                display: "inline-block", padding: "3px 12px", borderRadius: 4, fontSize: 10, fontWeight: 700, marginBottom: 8,
                background: activeEvent.event.type === "positive" ? `${N.green}18` : "#ff406018",
                color: activeEvent.event.type === "positive" ? N.green : "#ff4060",
                border: `1px solid ${activeEvent.event.type === "positive" ? N.green + "30" : "#ff406030"}`,
              }}>
                {activeEvent.event.type === "positive" ? "GOOD NEWS" : "BAD NEWS"}
              </div>
              <div style={{ fontSize: 18, fontWeight: 800, color: N.text, marginBottom: 8 }}>
                {activeEvent.event.title}
              </div>
              <div style={{ fontSize: 13, color: N.muted, lineHeight: 1.5 }}>
                {activeEvent.event.getText(activeEvent.targetPlayer)}
              </div>
            </div>
            <div style={{ padding: "16px 24px", textAlign: "center" }}>
              <button onClick={handleEventDismiss} style={{
                padding: "12px 36px", fontSize: 14, fontWeight: 800,
                background: activeEvent.event.type === "positive"
                  ? `linear-gradient(135deg, ${N.green}, ${N.cyan})`
                  : `linear-gradient(135deg, #ff6b6b, ${N.magenta})`,
                border: "none", borderRadius: 8, color: "#000", cursor: "pointer",
              }}>
                {activeEvent.event.type === "positive" ? "NICE! ✓" : "UNDERSTOOD ✓"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Match simulation modal */}
      {matchPhase && matchResult && currentMatch && matchPhase !== "preview" && (
        <div style={{ position: "fixed", inset: 0, zIndex: 1000, background: "rgba(0,0,0,0.9)", backdropFilter: "blur(8px)", display: "flex", flexDirection: "column", alignItems: "center", padding: "20px 16px", overflowY: "auto" }} onClick={(e) => e.stopPropagation()}>
          <div style={{ width: "100%", maxWidth: 500 }}>
            {/* Score header */}
            <div style={{ background: N.surface, borderRadius: 12, padding: "20px 24px", marginBottom: 16, textAlign: "center", border: `1px solid ${N.border}` }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 24, marginBottom: 8 }}>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 800, color: N.cyan }}>{clubName}</div>
                  <div style={{ fontSize: 11, color: N.muted }}>{TACTICS[selectedTactic]?.icon} {TACTICS[selectedTactic]?.name}</div>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <span style={{ fontSize: 40, fontWeight: 900, color: N.text }}>
                    {matchPhase === "simulating" ? matchResult.events.filter((e, idx) => e.type === "goal" && e.team === "home" && idx < visibleEvents).length : matchResult.homeGoals}
                  </span>
                  <span style={{ fontSize: 20, color: N.muted }}>-</span>
                  <span style={{ fontSize: 40, fontWeight: 900, color: N.text }}>
                    {matchPhase === "simulating" ? matchResult.events.filter((e, idx) => e.type === "goal" && e.team === "away" && idx < visibleEvents).length : matchResult.awayGoals}
                  </span>
                </div>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 800, color: "#ff6b6b" }}>{currentMatch.opponent}</div>
                  <div style={{ fontSize: 11, color: N.muted }}>OVR {currentMatch.oppOvr}</div>
                </div>
              </div>
              {/* Live match stats — accumulate as events reveal */}
              {(() => {
                const live = liveMatchStats(matchResult, visibleEvents, matchPhase === "simulating");
                if (!live) return null;
                const rows = [
                  ["Possession", live.possession + "%", (100 - live.possession) + "%", live.possession],
                  ["Shots", live.homeShots, live.awayShots, (live.homeShots / Math.max(1, live.homeShots + live.awayShots)) * 100],
                  ["On Target", live.homeSOT, live.awaySOT, (live.homeSOT / Math.max(1, live.homeSOT + live.awaySOT)) * 100],
                  ["xG", live.homeXg.toFixed(2), live.awayXg.toFixed(2), (live.homeXg / Math.max(0.1, live.homeXg + live.awayXg)) * 100],
                ];
                return (
                  <div style={{ marginBottom: 8 }}>
                    {rows.map(([label, hv, av, pct]) => (
                      <div key={label} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                        <span style={{ fontSize: 11, fontWeight: 800, color: N.cyan, width: 40, textAlign: "right" }}>{hv}</span>
                        <div style={{ flex: 1 }}>
                          <div style={{ fontSize: 9, color: N.muted, textAlign: "center", marginBottom: 2 }}>{label}</div>
                          <div style={{ height: 4, background: "#ff6b6b40", borderRadius: 2, overflow: "hidden" }}>
                            <div style={{ width: `${pct}%`, height: "100%", background: N.cyan, borderRadius: 2, transition: "width 0.4s ease" }} />
                          </div>
                        </div>
                        <span style={{ fontSize: 11, fontWeight: 800, color: "#ff6b6b", width: 40 }}>{av}</span>
                      </div>
                    ))}
                  </div>
                );
              })()}
              {matchPhase === "simulating" && (() => {
                const live = liveMatchStats(matchResult, visibleEvents, true);
                return <div style={{ fontSize: 12, color: N.green, fontWeight: 600 }}>⏱️ {live?.minute || 0}' — match in progress</div>;
              })()}
              {matchPhase === "result" && (() => {
                const won = matchResult.homeGoals > matchResult.awayGoals;
                const draw = matchResult.homeGoals === matchResult.awayGoals;
                const reward = won ? currentMatch.reward : draw ? Math.round(currentMatch.reward * 0.4) : Math.round(currentMatch.reward * 0.15);
                return (
                  <div>
                    <div style={{ fontSize: 28, fontWeight: 900, color: won ? N.green : draw ? N.gold : "#ff4060", marginBottom: 4 }}>{won ? "VICTORY!" : draw ? "DRAW" : "DEFEAT"}</div>
                    <div style={{ fontSize: 14, color: N.gold, fontWeight: 700 }}>+${reward} earned</div>
                    <div style={{ fontSize: 11, color: N.muted, marginTop: 4 }}>⚠️ Your starters lost fitness from this match</div>
                  </div>
                );
              })()}
            </div>
            {/* ── Match views: Pitch · Tempo ── */}
            {(matchPhase === "simulating" || matchPhase === "result") && (() => {
              const isLive = matchPhase === "simulating";
              // The pitch only exists while the match is running
              const view = !isLive && matchView === "pitch" ? "tempo" : matchView;
              const tabs = isLive
                ? [["pitch", "🗺️ Pitch"], ["tempo", "⚡ Tempo"], ["hidden", "Hide"]]
                : [["tempo", "⚡ Tempo"], ["hidden", "Hide"]];
              const pulseData = isLive ? liveState?.pulse : matchResult?.pulse;
              return (
                <>
                  <div style={{ display: "flex", gap: 6, marginBottom: 10 }}>
                    {tabs.map(([k, l]) => (
                      <button key={k} onClick={() => setMatchView(k)} style={{
                        flex: k === "hidden" ? "0 0 auto" : 1, padding: "8px 12px", fontSize: 12, fontWeight: 800,
                        borderRadius: 7, cursor: "pointer",
                        background: view === k ? `${N.cyan}1c` : N.card,
                        border: `1px solid ${view === k ? N.cyan : N.border}`,
                        color: view === k ? N.cyan : N.muted,
                      }}>{l}</button>
                    ))}
                  </div>
                  {view === "pitch" && isLive && liveState && (
                    <MatchMap live={liveState} homeName={clubName} awayName={currentMatch.opponent} speed={matchSpeed} paused={matchPaused} />
                  )}
                  {view === "tempo" && (
                    <TempoPanel pulse={pulseData} events={matchResult?.events} homeName={clubName}
                      awayName={currentMatch.opponent} live={isLive} />
                  )}
                </>
              );
            })()}

            {/* ── Touchline controls (live match only) ── */}
            {matchPhase === "simulating" && liveState && (
              <div style={{ background: N.surface, borderRadius: 12, border: `1px solid ${matchPaused ? N.gold : N.border}`, padding: 12, marginBottom: 16 }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <span style={{ fontSize: 15, fontWeight: 900, color: N.text }}>{liveState.minute}'</span>
                    <span style={{ fontSize: 10, fontWeight: 700, color: liveState.ballDead ? N.green : N.muted }}>
                      {liveState.ballDead ? "⏹ Ball out of play" : "▶ Ball in play"}
                    </span>
                    <span style={{ fontSize: 10, color: N.muted }}>Subs {liveState.subsUsed}/5</span>
                  </div>
                  <div style={{ display: "flex", gap: 6 }}>
                    {[{ v: 1, l: "1x" }, { v: 2, l: "2x" }, { v: 4, l: "4x" }].map((sp) => (
                      <button key={sp.v} onClick={() => setMatchSpeed(sp.v)} title={`Match speed ${sp.l}`} style={{
                        padding: "7px 9px", fontSize: 11, fontWeight: 800, borderRadius: 6, cursor: "pointer",
                        background: matchSpeed === sp.v ? `${N.magenta}22` : N.card,
                        border: `1px solid ${matchSpeed === sp.v ? N.magenta : N.border}`,
                        color: matchSpeed === sp.v ? N.magenta : N.muted,
                      }}>{sp.l}</button>
                    ))}
                    <button onClick={() => setMatchPaused((v) => !v)} style={{
                      padding: "7px 16px", fontSize: 12, fontWeight: 800, borderRadius: 6, cursor: "pointer",
                      background: matchPaused ? `linear-gradient(135deg, ${N.green}, ${N.cyan})` : N.card,
                      border: `1px solid ${matchPaused ? "transparent" : N.border}`,
                      color: matchPaused ? "#000" : N.cyan,
                    }}>{matchPaused ? "▶ Resume" : "⏸ Pause"}</button>
                  </div>
                </div>

                {matchPaused && (
                  <div style={{ marginTop: 12, borderTop: `1px solid ${N.border}`, paddingTop: 12 }}>
                    <div style={{ fontSize: 10, color: N.gold, fontWeight: 700, marginBottom: 10 }}>
                      ⚠️ Changes take effect at the next stoppage.
                    </div>

                    {/* On the pitch */}
                    <div style={{ fontSize: 10, fontWeight: 800, color: N.muted, marginBottom: 6 }}>
                      ON THE PITCH {pickOff ? "— now pick a replacement below" : "— tap a player to take off"}
                    </div>
                    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(88px, 1fr))", gap: 5, marginBottom: 12 }}>
                      {liveState.xi.filter((pl) => !pl.sentOff).map((pl) => {
                        const queued = plannedSubs.some((sp) => sp.outId === pl.id);
                        const chosen = pickOff === pl.id;
                        const cond = pl.condition;
                        const condColor = cond >= 70 ? N.green : cond >= 55 ? "#ffa800" : "#ff4060";
                        return (
                          <div key={pl.id} onClick={() => !queued && setPickOff(chosen ? null : pl.id)} style={{
                            padding: 6, borderRadius: 6, cursor: queued ? "default" : "pointer",
                            background: chosen ? `${N.cyan}22` : N.card, opacity: queued ? 0.45 : 1,
                            border: `1px solid ${chosen ? N.cyan : N.border}`,
                            display: "flex", flexDirection: "column", alignItems: "center", gap: 1,
                          }}>
                            <span style={{ fontSize: 8, fontWeight: 800, color: N.muted }}>{pl.slot}</span>
                            <span style={{ fontSize: 11, fontWeight: 700, color: N.text, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: "100%" }}>{pl.label || pl.lastName}</span>
                            <span style={{ fontSize: 9, fontWeight: 800, color: condColor }}>{queued ? "↔ swapping" : `${cond}%`}</span>
                          </div>
                        );
                      })}
                    </div>

                    {/* Bench */}
                    {pickOff && (
                      <>
                        <div style={{ fontSize: 10, fontWeight: 800, color: N.cyan, marginBottom: 6 }}>BENCH — tap who comes on</div>
                        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(88px, 1fr))", gap: 5, marginBottom: 12 }}>
                          {liveState.bench.filter((b) => !plannedSubs.some((sp) => sp.inId === b.id)).map((b) => (
                            <div key={b.id} onClick={() => {
                              if (b.injured) return;
                              setPlannedSubs((list) => [...list, { outId: pickOff, inId: b.id, outName: (() => { const o = liveState.xi.find((x) => x.id === pickOff); return o?.label || o?.lastName; })(), inName: b.label || b.lastName }]);
                              setPickOff(null);
                            }} style={{
                              padding: 6, borderRadius: 6, cursor: b.injured ? "not-allowed" : "pointer",
                              background: N.card, border: `1px solid ${N.border}`, opacity: b.injured ? 0.4 : 1,
                              display: "flex", flexDirection: "column", alignItems: "center", gap: 1,
                            }}>
                              <span style={{ fontSize: 8, fontWeight: 800, color: N.muted }}>{b.pos}</span>
                              <span style={{ fontSize: 11, fontWeight: 700, color: N.text, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: "100%" }}>{b.label || b.lastName}</span>
                              <span style={{ fontSize: 9, fontWeight: 800, color: statColor(b.ovr) }}>{b.injured ? "🏥" : b.ovr}</span>
                            </div>
                          ))}
                          {liveState.bench.length === 0 && (
                            <div style={{ gridColumn: "1 / -1", fontSize: 11, color: N.muted, textAlign: "center", padding: 6 }}>No players left on the bench.</div>
                          )}
                        </div>
                      </>
                    )}

                    {/* Shape switch */}
                    {(() => {
                      const cur = plannedShape || liveState.formation;
                      const edge = (cur && liveState.oppFormation)
                        ? (FORMATION_MATCHUPS[cur]?.[liveState.oppFormation] ?? 0) : 0;
                      const edgeColor = edge > 0 ? N.green : edge < 0 ? "#ff4060" : N.muted;
                      return (
                        <>
                          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 6 }}>
                            <span style={{ fontSize: 10, fontWeight: 800, color: N.muted }}>FORMATION</span>
                            <span style={{ fontSize: 9, fontWeight: 700, color: edgeColor }}>
                              vs their {liveState.oppFormation || "?"} · {edge > 0 ? `+${edge}` : edge} matchup
                            </span>
                          </div>
                          <select value={cur || ""} onChange={(e) => setPlannedShape(e.target.value)} style={{
                            width: "100%", background: N.card, color: plannedShape ? N.cyan : N.text,
                            border: `1px solid ${plannedShape ? N.cyan : N.border}`, borderRadius: 5,
                            padding: "7px 8px", fontSize: 12, fontWeight: 700, cursor: "pointer", outline: "none", marginBottom: 12,
                          }}>
                            {Object.keys(FORMATIONS).map((f) => {
                              const e2 = liveState.oppFormation ? (FORMATION_MATCHUPS[f]?.[liveState.oppFormation] ?? 0) : 0;
                              return <option key={f} value={f}>{f} ({e2 > 0 ? `+${e2}` : e2})</option>;
                            })}
                          </select>
                        </>
                      );
                    })()}

                    {/* Tactic switch */}
                    <div style={{ fontSize: 10, fontWeight: 800, color: N.muted, marginBottom: 6 }}>TEAM TACTIC</div>
                    <select value={plannedTactic || selectedTactic} onChange={(e) => setPlannedTactic(e.target.value)} style={{
                      width: "100%", background: N.card, color: TACTICS[plannedTactic || selectedTactic]?.color || N.cyan,
                      border: `1px solid ${plannedTactic ? N.cyan : N.border}`, borderRadius: 5,
                      padding: "7px 8px", fontSize: 12, fontWeight: 700, cursor: "pointer", outline: "none", marginBottom: 12,
                    }}>
                      {Object.entries(TACTICS).map(([key, tac]) => <option key={key} value={key}>{tac.icon} {tac.name}</option>)}
                    </select>

                    {/* Queued changes */}
                    {(plannedSubs.length > 0 || plannedTactic || plannedShape) && (
                      <div style={{ background: `${N.gold}10`, border: `1px solid ${N.gold}30`, borderRadius: 6, padding: 8, marginBottom: 10 }}>
                        <div style={{ fontSize: 10, fontWeight: 800, color: N.gold, marginBottom: 4 }}>READY TO GO ON</div>
                        {plannedSubs.map((sp, i) => (
                          <div key={i} style={{ fontSize: 11, color: N.text, display: "flex", justifyContent: "space-between", gap: 8 }}>
                            <span>🔄 {sp.inName} for {sp.outName}</span>
                            <span onClick={() => setPlannedSubs((l) => l.filter((_, j) => j !== i))} style={{ color: "#ff4060", cursor: "pointer", fontWeight: 800 }}>✕</span>
                          </div>
                        ))}
                        {plannedTactic && (
                          <div style={{ fontSize: 11, color: N.text, display: "flex", justifyContent: "space-between", gap: 8 }}>
                            <span>🧠 Switch to {TACTICS[plannedTactic]?.name}</span>
                            <span onClick={() => setPlannedTactic(null)} style={{ color: "#ff4060", cursor: "pointer", fontWeight: 800 }}>✕</span>
                          </div>
                        )}
                        {plannedShape && (
                          <div style={{ fontSize: 11, color: N.text, display: "flex", justifyContent: "space-between", gap: 8 }}>
                            <span>📐 Reshape to {plannedShape}</span>
                            <span onClick={() => setPlannedShape(null)} style={{ color: "#ff4060", cursor: "pointer", fontWeight: 800 }}>✕</span>
                          </div>
                        )}
                      </div>
                    )}

                    <div style={{ display: "flex", gap: 8 }}>
                      <button onClick={() => { setPlannedSubs([]); setPlannedTactic(null); setPlannedShape(null); setPickOff(null); setMatchPaused(false); setSimTick((t) => t + 1); }} style={{
                        flex: 1, padding: "9px 12px", fontSize: 12, fontWeight: 700, borderRadius: 6,
                        background: "transparent", border: `1px solid ${N.border}`, color: N.muted, cursor: "pointer",
                      }}>Cancel</button>
                      <button onClick={confirmMatchOrder} disabled={!plannedSubs.length && !plannedTactic && !plannedShape} style={{
                        flex: 2, padding: "9px 12px", fontSize: 12, fontWeight: 800, borderRadius: 6, border: "none",
                        background: (plannedSubs.length || plannedTactic || plannedShape) ? `linear-gradient(135deg, ${N.cyan}, ${N.magenta})` : N.card,
                        color: (plannedSubs.length || plannedTactic || plannedShape) ? "#000" : N.muted,
                        cursor: (plannedSubs.length || plannedTactic || plannedShape) ? "pointer" : "not-allowed",
                      }}>Confirm & Resume ▶</button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Event log */}
            <div ref={eventLogRef} style={{ background: N.surface, borderRadius: 12, border: `1px solid ${N.border}`, padding: 16, maxHeight: 380, overflowY: "auto", marginBottom: 16 }}>
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                {matchResult.events.slice(0, matchPhase === "result" ? 999 : visibleEvents).map((evt, i) => (
                  <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 10, padding: "8px 10px", borderRadius: 6, background: evt.type === "goal" ? `${evt.color}10` : "transparent", border: evt.type === "goal" ? `1px solid ${evt.color}25` : "1px solid transparent" }}>
                    <div style={{ width: 36, textAlign: "center", flexShrink: 0 }}>
                      <span style={{ fontSize: 11, fontWeight: 800, color: evt.type === "whistle" ? N.muted : evt.color }}>{evt.min}'</span>
                    </div>
                    <span style={{ fontSize: 15 }}>{evt.icon}</span>
                    <span style={{ fontSize: 12, fontWeight: evt.type === "goal" || evt.type === "red" ? 800 : 500, color: evt.type === "goal" || evt.type === "red" ? evt.color : N.text }}>{evt.text}</span>
                  </div>
                ))}
              </div>
            </div>
            {matchPhase === "result" && matchResult.stats && (
              <div style={{ background: N.surface, borderRadius: 12, border: `1px solid ${N.border}`, padding: 16, marginBottom: 16 }}>
                <h4 style={{ fontSize: 13, fontWeight: 800, color: N.cyan, margin: "0 0 10px" }}>📋 Player Ratings</h4>
                <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                  {squad.map((p, i) => {
                    const s = matchResult.stats[p.id];
                    if (!s) return null;
                    const passAcc = s.passes > 0 ? Math.round((s.passesCompleted / s.passes) * 100) : 100;
                    const ratingCol = s.rating >= 8 ? N.magenta : s.rating >= 7 ? N.green : s.rating >= 6 ? N.cyan : s.rating >= 5 ? N.gold : "#ff4060";
                    const bits = [];
                    if (s.goals) bits.push(`${s.goals} goal${s.goals > 1 ? "s" : ""}`);
                    if (s.assists) bits.push(`${s.assists} assist${s.assists > 1 ? "s" : ""}`);
                    if (s.shots) bits.push(`${s.shots} shot${s.shots > 1 ? "s" : ""}`);
                    if (s.xg >= 0.05) bits.push(`${s.xg.toFixed(2)} xG`);
                    if (s.keyPasses) bits.push(`${s.keyPasses} KP`);
                    if (s.saves) bits.push(`${s.saves} save${s.saves > 1 ? "s" : ""}`);
                    if (s.tackles) bits.push(`${s.tackles} tkl`);
                    if (s.interceptions) bits.push(`${s.interceptions} int`);
                    bits.push(`${passAcc}% pass`);
                    return (
                      <div key={p.id} style={{ display: "flex", alignItems: "center", gap: 8, padding: "6px 8px", borderRadius: 6, background: s.rating >= 8 ? `${N.magenta}08` : "transparent" }}>
                        <span style={{ fontSize: 8, fontWeight: 700, width: 32, textAlign: "center", padding: "2px 3px", borderRadius: 3, background: N.card, color: N.muted }}>{slotPositions[i]}</span>
                        <span style={{ fontSize: 11, fontWeight: 700, color: N.text, width: 84, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{p.lastName}</span>
                        <span style={{ fontSize: 9, color: N.muted, flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{bits.join(" · ")}</span>
                        <span style={{ fontSize: 13, fontWeight: 900, color: ratingCol, width: 32, textAlign: "right" }}>{s.rating.toFixed(1)}</span>
                      </div>
                    );
                  })}
                </div>
                {(() => {
                  const rated = squad.map((p) => ({ p, s: matchResult.stats[p.id] })).filter((x) => x.s);
                  if (!rated.length) return null;
                  const mom = rated.reduce((a, b) => (b.s.rating > a.s.rating ? b : a));
                  return (
                    <div style={{ marginTop: 10, padding: "8px 12px", borderRadius: 6, background: `${N.gold}10`, border: `1px solid ${N.gold}25`, fontSize: 11, color: N.gold, fontWeight: 700, textAlign: "center" }}>
                      ⭐ Man of the Match: {mom.p.firstName} {mom.p.lastName} ({mom.s.rating.toFixed(1)})
                    </div>
                  );
                })()}
              </div>
            )}
            {matchPhase === "result" && (
              <div style={{ textAlign: "center" }}>
                <button onClick={collectMatchReward} style={{ padding: "14px 40px", fontSize: 15, fontWeight: 800, background: `linear-gradient(135deg, ${N.cyan}, ${N.magenta})`, border: "none", borderRadius: 10, color: "#000", cursor: "pointer" }}>COLLECT REWARDS ✓</button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Top Bar */}
      <div style={{ background: `linear-gradient(180deg, ${N.surface} 0%, ${N.bg} 100%)`, borderBottom: `1px solid ${N.border}`, padding: "12px 16px" }} onClick={(e) => e.stopPropagation()}>
        <div style={{ maxWidth: 1000, margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ width: 36, height: 36, borderRadius: "50%", background: `linear-gradient(135deg, ${N.cyan}30, ${N.magenta}30)`, border: `1.5px solid ${N.cyan}40`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>⚽</div>
            <div>
              <div style={{ fontSize: 15, fontWeight: 800, color: N.cyan }}>{clubName}</div>
              <div style={{ fontSize: 11, color: N.muted }}>Manager: {managerName}</div>
              <div style={{ fontSize: 10, color: getDivision(currentDivision).color, fontWeight: 700 }}>{getDivision(currentDivision).icon} {getDivision(currentDivision).name}</div>
            </div>
          </div>
          <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
            <div style={{ textAlign: "center" }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: N.muted, marginBottom: 2 }}>BUDGET</div>
              <div style={{ fontSize: 22, fontWeight: 900, color: N.gold, lineHeight: 1 }}>${money.toLocaleString()}</div>
            </div>
            <div style={{ width: 1, height: 36, background: N.border }} />
            <div style={{ textAlign: "center" }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: N.muted, marginBottom: 2 }}>OVR</div>
              <div style={{ fontSize: 26, fontWeight: 900, lineHeight: 1, color: TIER_STYLES[getTier(teamOvr)].accent }}>{teamOvr}</div>
            </div>
            <div style={{ width: 1, height: 36, background: N.border }} />
            <div style={{ textAlign: "center" }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: N.muted, marginBottom: 2 }}>CHEM</div>
              <div style={{ fontSize: 26, fontWeight: 900, color: N.green, lineHeight: 1 }}>{chemistry.total}</div>
            </div>
            <div style={{ width: 1, height: 36, background: N.border }} />
            <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
              <button onClick={saveGame} style={{
                padding: "6px 12px", fontSize: 11, fontWeight: 700, borderRadius: 4, cursor: "pointer",
                background: saveStatus === "saved" ? `${N.green}15` : `${N.cyan}15`,
                border: `1px solid ${saveStatus === "saved" ? N.green + "30" : N.cyan + "30"}`,
                color: saveStatus === "saved" ? N.green : N.cyan,
              }}>
                {saveStatus === "saving" ? "💾..." : saveStatus === "saved" ? "✅ Saved" : saveStatus === "error" ? "❌ Error" : "💾 Save"}
              </button>
              <button onClick={resetSave} title="Reset progress" style={{
                padding: "6px 8px", fontSize: 11, fontWeight: 700, borderRadius: 4, cursor: "pointer",
                background: "transparent", border: `1px solid ${N.border}`, color: N.muted,
              }}>🔄</button>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ background: N.surface, borderBottom: `1px solid ${N.border}`, padding: "0 16px" }} onClick={(e) => e.stopPropagation()}>
        <div style={{ maxWidth: 1000, margin: "0 auto", display: "flex" }}>
          {[{ id: "squad", label: "⚽ Squad" }, { id: "transfers", label: "💼 Transfers" }, { id: "season", label: "🏆 Season" }, { id: "league", label: "📊 Table" }, { id: "morale", label: "😊 Morale" }, { id: "trophies", label: "🏅 Trophies" }].map((t) => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{ padding: "12px 20px", fontSize: 13, fontWeight: 700, border: "none", cursor: "pointer", background: "transparent", color: tab === t.id ? N.cyan : N.muted, borderBottom: `2px solid ${tab === t.id ? N.cyan : "transparent"}`, transition: "all 0.2s" }}>{t.label}</button>
          ))}
        </div>
      </div>

      {selected && tab === "squad" && (
        <div style={{ textAlign: "center", padding: "8px 16px", background: `${N.cyan}08`, borderBottom: `1px solid ${N.cyan}15` }}>
          <span style={{ fontSize: 12, color: N.cyan, fontWeight: 600 }}>🔄 {selected.type === "squad" ? squad[selected.index].lastName : bench[selected.index].lastName} selected — tap another to swap</span>
        </div>
      )}

      {/* ═══ SQUAD TAB with sub-tabs ═══ */}
      {tab === "squad" && (
        <div onClick={(e) => e.stopPropagation()}>
          {/* Sub-tab bar */}
          <div style={{ background: N.card, borderBottom: `1px solid ${N.border}`, padding: "0 16px" }}>
            <div style={{ maxWidth: 1000, margin: "0 auto", display: "flex", gap: 0 }}>
              {[
                { id: "lineup", label: "📋 Lineup" },
                { id: "squadList", label: "📊 Squad List" },
                { id: "tactics", label: "🧠 Tactics" },
                { id: "roles", label: "🎭 Roles" },
              ].map((st) => (
                <button key={st.id} onClick={() => setSquadSubTab(st.id)} style={{
                  padding: "10px 18px", fontSize: 12, fontWeight: 700, border: "none", cursor: "pointer",
                  background: "transparent", color: squadSubTab === st.id ? N.cyan : N.muted,
                  borderBottom: `2px solid ${squadSubTab === st.id ? N.cyan : "transparent"}`,
                  transition: "all 0.2s",
                }}>{st.label}</button>
              ))}
            </div>
          </div>

          {/* ── Lineup Sub-tab ── */}
          {squadSubTab === "lineup" && (
            <div style={{ maxWidth: 1000, margin: "0 auto", padding: "20px 16px", display: "flex", gap: 20, flexWrap: "wrap", justifyContent: "center" }}>
              <div style={{ flex: "1 1 400px", maxWidth: 560 }}>
                <Pitch squad={squad} formation={formation} selected={selected} onSelect={handleSelect} onDragStart={(s) => setSelected(s)} onDrop={handleDrop} />
                <div style={{ textAlign: "center", marginTop: 8 }}>
                  <select value={formation} onChange={(e) => setFormation(e.target.value)} style={{ background: N.card, color: N.cyan, border: `1px solid ${N.border}`, borderRadius: 6, padding: "6px 12px", fontSize: 14, fontWeight: 700, cursor: "pointer", outline: "none" }}>
                    {FORMATION_KEYS.map((f) => <option key={f} value={f}>{f}</option>)}
                  </select>
                </div>
                <div style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 10, padding: 12, marginTop: 12 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span style={{ fontSize: 12, fontWeight: 700, color: N.green }}>🧩 Chemistry: {chemistry.total}/100</span>
                    <span style={{ fontSize: 11, color: N.muted }}>+{chemistry.bonus} OVR in matches</span>
                  </div>
                </div>
              </div>
              <div style={{ flex: "1 1 300px", maxWidth: 400, display: "flex", flexDirection: "column", gap: 16 }}>
                <div style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 10, padding: 16 }}>
                  <h3 style={{ fontSize: 13, fontWeight: 700, color: N.cyan, margin: "0 0 12px" }}>Bench ({bench.length})</h3>
                  <button onClick={handleRecoverySession} disabled={money < REST_COST || !!clubLeague} style={{
                    width: "100%", padding: "10px", marginBottom: 12, fontSize: 12, fontWeight: 700,
                    background: clubLeague ? "#ff406010" : money >= REST_COST ? `${N.green}15` : N.card,
                    border: `1px solid ${clubLeague ? "#ff406020" : money >= REST_COST ? N.green + "30" : N.border}`,
                    borderRadius: 6, color: clubLeague ? "#ff4060" : money >= REST_COST ? N.green : N.muted,
                    cursor: money >= REST_COST && !clubLeague ? "pointer" : "not-allowed",
                  }}>
                    {clubLeague ? "🚫 Recovery blocked during Club League" : `💆 Recovery ($${REST_COST}) — +30 fitness`}
                  </button>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center", maxHeight: 220, overflowY: "auto" }}>
                    {bench.map((p, i) => (
                      <BenchCard key={p.id} player={p} isSelected={selected?.type === "bench" && selected.index === i}
                        onClick={() => handleSelect({ type: "bench", index: i })}
                        onDragStart={(e) => { e.dataTransfer.setData("text", JSON.stringify({ type: "bench", index: i })); setSelected({ type: "bench", index: i }); }}
                        onDrop={(e) => { e.preventDefault(); handleDrop({ type: "bench", index: i }, e); }} />
                    ))}
                  </div>
                </div>
                <div style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 10, padding: 16 }}>
                  <h3 style={{ fontSize: 13, fontWeight: 700, color: N.cyan, margin: "0 0 12px" }}>Squad List</h3>
                  <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                    {squad.map((p, i) => {
                      const ts = TIER_STYLES[getTier(p.ovr)];
                      const st = getSlotStatus(p, slotPositions[i]);
                      const eff = getEffectiveOvr(p, slotPositions[i]);
                      return (
                        <div key={p.id} onClick={() => { setDetailPlayer(p); setDetailSlot(slotPositions[i]); }} style={{ display: "flex", alignItems: "center", gap: 8, padding: "6px 10px", borderRadius: 6, cursor: "pointer", background: "transparent", border: "1px solid transparent" }}>
                          {st.status === "yellow" && <span style={{ fontSize: 12 }}>⚠️</span>}
                          {st.status === "red" && <span style={{ fontSize: 12 }}>🚫</span>}
                          <div style={{ display: "flex", alignItems: "baseline", gap: 2, width: 48 }}>
                            <span style={{ fontSize: 12, fontWeight: 800, color: statColor(eff) }}>{eff}</span>
                            {st.penalty > 0 && <span style={{ fontSize: 9, fontWeight: 800, color: st.status === "yellow" ? "#ffa800" : "#ff4060" }}>-{st.penalty}</span>}
                          </div>
                          <span style={{ fontSize: 8, fontWeight: 700, width: 42, textAlign: "center", padding: "3px 4px", borderRadius: 3, background: ts.bg, color: ts.text }}>{slotPositions[i]}</span>
                          <span style={{ fontSize: 12, fontWeight: 600 }}>{p.firstName[0]}. {p.lastName}</span>
                          <span style={{ fontSize: 9, color: N.muted, marginLeft: "auto" }}>
                            {p.injuredFor > 0
                              ? <span style={{ color: "#ff4060", fontWeight: 700 }}>🏥 {p.injuredFor}m</span>
                              : <span style={{ color: getFitnessColor(p.fitness ?? 100) }}>{p.fitness ?? 100}%</span>
                            }
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ── Tactics Sub-tab ── */}
          {squadSubTab === "tactics" && (
            <div style={{ maxWidth: 600, margin: "0 auto", padding: "20px 16px" }}>
              {/* Formation picker with previews */}
              <div style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 12, padding: 20, marginBottom: 16 }}>
                <h3 style={{ fontSize: 14, fontWeight: 700, color: N.cyan, margin: "0 0 12px" }}>🏟️ Formation</h3>
                <div style={{ display: "flex", gap: 10, overflowX: "auto", paddingBottom: 6 }}>
                  {FORMATION_KEYS.map((f) => (
                    <div key={f} onClick={() => setFormation(f)}>
                      <FormationPreview formation={f} active={formation === f} />
                    </div>
                  ))}
                </div>
              </div>

              {/* Tactic selector */}
              <div style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 12, padding: 20, marginBottom: 16 }}>
                <h3 style={{ fontSize: 14, fontWeight: 700, color: N.cyan, margin: "0 0 12px" }}>⚔️ Team Tactic</h3>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                  {Object.entries(TACTICS).map(([key, tac]) => {
                    const isActive = selectedTactic === key;
                    return (
                      <div key={key} onClick={() => setSelectedTactic(key)} style={{
                        padding: "12px 14px", borderRadius: 8, cursor: "pointer",
                        background: isActive ? `${tac.color}15` : N.card,
                        border: `1.5px solid ${isActive ? tac.color : N.border}`,
                        transition: "all 0.2s",
                      }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
                          <span style={{ fontSize: 18 }}>{tac.icon}</span>
                          <span style={{ fontSize: 13, fontWeight: 800, color: isActive ? tac.color : N.text }}>{tac.name}</span>
                        </div>
                        <div style={{ fontSize: 11, color: N.muted }}>{tac.desc}</div>
                        <div style={{ fontSize: 10, marginTop: 4, fontWeight: 700, color: tac.fitnessDrain >= 1.3 ? "#ff4060" : tac.fitnessDrain >= 1.0 ? N.gold : N.green }}>
                          ⚡ Energy: {tac.fitnessDrain >= 1.4 ? "Very High" : tac.fitnessDrain >= 1.1 ? "High" : tac.fitnessDrain >= 0.95 ? "Normal" : tac.fitnessDrain >= 0.8 ? "Low" : "Very Low"}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Live behaviour profile */}
              {(() => {
                const bh = resolveBehaviour(selectedTactic, instructions);
                const rows = [
                  ["Tempo", bh.tempo, N.cyan], ["Directness", bh.directness, N.gold],
                  ["Width", bh.width, N.green], ["Creative Freedom", bh.creativeFreedom, N.magenta],
                  ["Press Intensity", bh.pressIntensity, "#ff6b00"], ["Defensive Line", bh.defLine, "#ff4060"],
                  ["Aggression", bh.aggression, "#a78bfa"], ["Transition Speed", bh.transitionSpeed, "#8ab4f8"],
                  ["Patience", bh.patience, "#c8d6e0"], ["Counter-Press", bh.counterPress, "#00ffc8"],
                ];
                return (
                  <div style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 12, padding: 20, marginBottom: 16 }}>
                    <h3 style={{ fontSize: 14, fontWeight: 700, color: N.cyan, margin: "0 0 4px" }}>📊 Team Behaviour</h3>
                    <p style={{ fontSize: 11, color: N.muted, margin: "0 0 14px" }}>How your side actually plays, after instructions are applied.</p>
                    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "8px 20px" }}>
                      {rows.map(([label, val, col]) => (
                        <div key={label}>
                          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 2 }}>
                            <span style={{ fontSize: 10, color: N.muted, fontWeight: 600 }}>{label}</span>
                            <span style={{ fontSize: 10, fontWeight: 800, color: col }}>{Math.round(val)}</span>
                          </div>
                          <div style={{ width: "100%", height: 5, background: "#1a2236", borderRadius: 3, overflow: "hidden" }}>
                            <div style={{ width: `${val}%`, height: "100%", background: col, borderRadius: 3, transition: "width 0.3s ease" }} />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })()}

              {/* Team instructions */}
              <div style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 12, padding: 20, marginBottom: 16 }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 4 }}>
                  <h3 style={{ fontSize: 14, fontWeight: 700, color: N.cyan, margin: 0 }}>🎛️ Team Instructions</h3>
                  <button onClick={() => setInstructions({ ...DEFAULT_INSTRUCTIONS })} style={{
                    padding: "4px 10px", fontSize: 10, fontWeight: 700, borderRadius: 5,
                    background: "transparent", border: `1px solid ${N.border}`, color: N.muted, cursor: "pointer",
                  }}>Reset</button>
                </div>
                <p style={{ fontSize: 11, color: N.muted, margin: "0 0 14px" }}>Fine-tune your tactic. Each choice shifts how the team behaves in that phase.</p>
                {INSTRUCTION_GROUPS.map((group) => (
                  <div key={group.id} style={{ marginBottom: 16 }}>
                    <div style={{ fontSize: 11, fontWeight: 800, color: N.gold, marginBottom: 8 }}>{group.icon} {group.label.toUpperCase()}</div>
                    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                      {group.instructions.map((ins) => (
                        <div key={ins.id} style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                          <span style={{ fontSize: 11, color: N.muted, width: 130, flexShrink: 0 }}>{ins.label}</span>
                          <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
                            {ins.options.map((opt) => {
                              const active = (instructions[ins.id] ?? DEFAULT_INSTRUCTIONS[ins.id]) === opt.v;
                              return (
                                <button key={opt.v} onClick={() => setInstructions((prev) => ({ ...prev, [ins.id]: opt.v }))} style={{
                                  padding: "5px 11px", fontSize: 10, fontWeight: 700, borderRadius: 5, cursor: "pointer",
                                  background: active ? `${N.cyan}18` : N.card,
                                  border: `1px solid ${active ? N.cyan : N.border}`,
                                  color: active ? N.cyan : N.muted,
                                }}>{opt.label}</button>
                              );
                            })}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              <div style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 12, padding: 20 }}>
                <h3 style={{ fontSize: 14, fontWeight: 700, color: N.cyan, margin: "0 0 12px" }}>🧩 Chemistry</h3>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
                  <span style={{ fontSize: 32, fontWeight: 900, color: N.green }}>{chemistry.total}</span>
                  <span style={{ fontSize: 12, color: N.muted }}>{chemistry.links} nationality links · +{chemistry.bonus} OVR in matches</span>
                </div>
                <div style={{ width: "100%", height: 8, background: "#1a2236", borderRadius: 4, overflow: "hidden" }}>
                  <div style={{ width: `${chemistry.total}%`, height: "100%", background: N.green, borderRadius: 4 }} />
                </div>
                <div style={{ fontSize: 11, color: N.muted, marginTop: 8 }}>Tip: Players from the same nationality near each other on the pitch boost chemistry.</div>
              </div>
            </div>
          )}

          {/* ── Roles Sub-tab (Grid-based activity map) ── */}
          {squadSubTab === "roles" && (() => {
            // Heat map parameters per role: yCenter (0=opp goal,1=own goal), xSpread, ySpread
            const HEAT = {
              "Shot Stopper":{y:0.92,xs:0.25,ys:0.12},"Sweeper Keeper":{y:0.82,xs:0.35,ys:0.22},"Goalkeeper":{y:0.9,xs:0.3,ys:0.15},
              "Stopper":{y:0.78,xs:0.45,ys:0.18},"Ball-Playing CB":{y:0.72,xs:0.5,ys:0.25},"Leader":{y:0.76,xs:0.4,ys:0.2},"Libero":{y:0.6,xs:0.5,ys:0.35},"Aerial Threat":{y:0.75,xs:0.35,ys:0.22},
              "Attacking Fullback":{y:0.45,xs:0.25,ys:0.5},"Defensive Fullback":{y:0.72,xs:0.22,ys:0.3},"Inverted Fullback":{y:0.55,xs:0.35,ys:0.35},"Wing-Back":{y:0.5,xs:0.22,ys:0.55},
              "Complete Wing-Back":{y:0.45,xs:0.25,ys:0.55},"Defensive Wing-Back":{y:0.68,xs:0.22,ys:0.3},
              "Destroyer":{y:0.62,xs:0.5,ys:0.22},"Deep Playmaker":{y:0.58,xs:0.55,ys:0.28},"Holding Midfielder":{y:0.65,xs:0.4,ys:0.2},"Anchor":{y:0.68,xs:0.35,ys:0.18},"Half-Back":{y:0.72,xs:0.45,ys:0.22},
              "Box-to-Box":{y:0.48,xs:0.55,ys:0.5},"Playmaker":{y:0.42,xs:0.5,ys:0.3},"Mezzala":{y:0.4,xs:0.4,ys:0.4},"Carrilero":{y:0.5,xs:0.55,ys:0.3},"Deep-Lying Playmaker":{y:0.55,xs:0.5,ys:0.3},"Pressing Midfielder":{y:0.42,xs:0.55,ys:0.35},
              "Advanced Playmaker":{y:0.32,xs:0.5,ys:0.3},"Shadow Striker":{y:0.2,xs:0.4,ys:0.3},"Trequartista":{y:0.3,xs:0.6,ys:0.35},"Enganche":{y:0.35,xs:0.45,ys:0.25},"Half-Winger":{y:0.32,xs:0.35,ys:0.35},
              "Wide Midfielder":{y:0.5,xs:0.22,ys:0.4},"Wide Playmaker":{y:0.4,xs:0.28,ys:0.35},"Inside Midfielder":{y:0.45,xs:0.35,ys:0.35},"Defensive Winger":{y:0.6,xs:0.22,ys:0.4},
              "Winger":{y:0.28,xs:0.2,ys:0.5},"Inside Forward":{y:0.18,xs:0.35,ys:0.35},"Inverted Winger":{y:0.25,xs:0.3,ys:0.4},"Wide Forward":{y:0.2,xs:0.22,ys:0.35},"Raumdeuter":{y:0.18,xs:0.4,ys:0.3},
              "Target Man":{y:0.12,xs:0.4,ys:0.22},"Poacher":{y:0.08,xs:0.3,ys:0.18},"False 9":{y:0.28,xs:0.5,ys:0.35},"Pace Merchant":{y:0.12,xs:0.35,ys:0.3},"Complete Forward":{y:0.18,xs:0.5,ys:0.35},"Advanced Forward":{y:0.1,xs:0.35,ys:0.25},"Pressing Forward":{y:0.2,xs:0.5,ys:0.3},
              "Deep-Lying Forward":{y:0.3,xs:0.45,ys:0.3},
            };

            const GRID_COLS = 6;
            const GRID_ROWS = 8;
            const selPlayer = editingPlayer !== null ? squad[editingPlayer] : null;
            const selCoord = editingPlayer !== null ? FORMATIONS[formation].coords[editingPlayer] : null;

            // Calculate grid intensities
            const gridCells = [];
            if (selPlayer && selCoord) {
              const role = selPlayer.activeRole || selPlayer.role;
              const params = HEAT[role] || { y: 0.5, xs: 0.4, ys: 0.3 };
              const playerX = selCoord.x / 100;

              for (let r = 0; r < GRID_ROWS; r++) {
                for (let c = 0; c < GRID_COLS; c++) {
                  const cellX = (c + 0.5) / GRID_COLS;
                  const cellY = (r + 0.5) / GRID_ROWS;
                  const dx = (cellX - playerX) / params.xs;
                  const dy = (cellY - params.y) / params.ys;
                  const dist = Math.sqrt(dx * dx + dy * dy);
                  const intensity = Math.max(0, Math.min(1, 1 - dist * 0.8));
                  gridCells.push({ r, c, intensity });
                }
              }
            }

            const focusCol = selPlayer ? (FOCUS_COLORS[selPlayer.focus] || N.cyan) : N.cyan;
            const liveBehaviour = resolveBehaviour(selectedTactic, instructions);
            const shapeCoords = shapeView === "attacking"
              ? getAttackingShape(squad, formation, liveBehaviour)
              : FORMATIONS[formation].coords;

            return (
              <div style={{ maxWidth: 750, margin: "0 auto", padding: "20px 16px" }}>
                <div style={{ display: "flex", gap: 16, flexWrap: "wrap", justifyContent: "center" }}>
                  {/* Pitch with grid */}
                  <div style={{ flex: "1 1 340px", maxWidth: 440 }}>
                    {/* Shape toggle */}
                    <div style={{ display: "flex", gap: 6, marginBottom: 8, justifyContent: "center" }}>
                      {[
                        { id: "defensive", label: "🛡️ Out of Possession" },
                        { id: "attacking", label: "⚽ In Possession" },
                      ].map((sv) => (
                        <button key={sv.id} onClick={() => setShapeView(sv.id)} style={{
                          padding: "6px 14px", fontSize: 11, fontWeight: 700, borderRadius: 6, cursor: "pointer",
                          background: shapeView === sv.id ? `${N.cyan}18` : N.card,
                          border: `1px solid ${shapeView === sv.id ? N.cyan : N.border}`,
                          color: shapeView === sv.id ? N.cyan : N.muted,
                        }}>{sv.label}</button>
                      ))}
                    </div>
                    <div style={{
                      width: "100%", aspectRatio: "3/4",
                      background: "linear-gradient(180deg, #0a3d23 0%, #0d5a30 30%, #0a4525 70%, #082e19 100%)",
                      borderRadius: 12, position: "relative", overflow: "hidden",
                      border: `1px solid ${N.green}20`,
                    }}>
                      {/* Grid overlay */}
                      {gridCells.map(({ r, c, intensity }) => intensity > 0.05 && (
                        <div key={`${r}-${c}`} style={{
                          position: "absolute",
                          left: `${(c / GRID_COLS) * 100}%`,
                          top: `${(r / GRID_ROWS) * 100}%`,
                          width: `${100 / GRID_COLS}%`,
                          height: `${100 / GRID_ROWS}%`,
                          background: focusCol,
                          opacity: intensity * 0.45,
                          border: `0.5px solid ${focusCol}15`,
                          pointerEvents: "none",
                          transition: "opacity 0.3s ease",
                        }} />
                      ))}

                      {/* Grid lines (subtle) */}
                      {Array.from({ length: GRID_COLS - 1 }).map((_, i) => (
                        <div key={`vc-${i}`} style={{ position: "absolute", left: `${((i + 1) / GRID_COLS) * 100}%`, top: 0, bottom: 0, width: 0.5, background: "rgba(255,255,255,0.06)", pointerEvents: "none" }} />
                      ))}
                      {Array.from({ length: GRID_ROWS - 1 }).map((_, i) => (
                        <div key={`hr-${i}`} style={{ position: "absolute", top: `${((i + 1) / GRID_ROWS) * 100}%`, left: 0, right: 0, height: 0.5, background: "rgba(255,255,255,0.06)", pointerEvents: "none" }} />
                      ))}

                      {/* Pitch lines */}
                      <div style={{ position: "absolute", top: "50%", left: "5%", right: "5%", height: 1, background: "rgba(255,255,255,0.15)" }} />
                      <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)", width: 60, height: 60, borderRadius: "50%", border: "1px solid rgba(255,255,255,0.12)" }} />
                      <div style={{ position: "absolute", bottom: "2%", left: "22%", right: "22%", height: "14%", border: "1px solid rgba(255,255,255,0.12)", borderBottom: "none" }} />
                      <div style={{ position: "absolute", top: "2%", left: "22%", right: "22%", height: "14%", border: "1px solid rgba(255,255,255,0.12)", borderTop: "none" }} />

                      {/* Player cards */}
                      {squad.map((player, i) => {
                        const coord = shapeCoords[i] || FORMATIONS[formation].coords[i];
                        const isNatRole = (player.activeRole || player.role) === player.role;
                        const focCol2 = FOCUS_COLORS[player.focus] || N.text;
                        const isSel = editingPlayer === i;

                        return (
                          <div key={player.id} onClick={() => setEditingPlayer(isSel ? null : i)} style={{
                            position: "absolute", left: `${coord.x}%`, top: `${coord.y}%`,
                            transform: "translate(-50%,-50%)", zIndex: isSel ? 30 : 10, cursor: "pointer",
                            transition: "left 0.45s ease, top 0.45s ease",
                          }}>
                            <div style={{
                              width: 64, padding: "3px 3px 2px",
                              background: isSel ? `rgba(0,229,255,0.18)` : `rgba(15,22,40,0.92)`,
                              border: `1.5px solid ${isSel ? N.cyan : focCol2 + "40"}`,
                              borderRadius: 5,
                              boxShadow: isSel ? `0 0 8px ${N.cyan}30` : "none",
                            }}>
                              <div style={{ fontSize: 8.5, fontWeight: 800, color: N.text, textAlign: "center", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{player.lastName}</div>
                              <div style={{ fontSize: 6.5, fontWeight: 700, textAlign: "center", color: isNatRole ? N.green : N.gold, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", marginTop: 1 }}>
                                {player.activeRole || player.role}{isNatRole ? "+" : ""}
                              </div>
                              <div style={{ display: "flex", justifyContent: "center", gap: 2, marginTop: 1 }}>
                                <span style={{ fontSize: 6, fontWeight: 700, color: focCol2 }}>{player.focus}</span>
                                <span style={{ fontSize: 6, color: N.muted }}>·</span>
                                <span style={{ fontSize: 6, fontWeight: 700, color: N.muted }}>{slotPositions[i]}</span>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Heat map legend */}
                    {selPlayer && (
                      <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 8, justifyContent: "center" }}>
                        <span style={{ fontSize: 10, color: N.muted }}>Activity:</span>
                        <div style={{ display: "flex", gap: 2 }}>
                          {[0.1, 0.25, 0.4, 0.55, 0.7].map((op, i) => (
                            <div key={i} style={{ width: 16, height: 8, borderRadius: 2, background: focusCol, opacity: op * 0.45 + 0.05 }} />
                          ))}
                        </div>
                        <span style={{ fontSize: 10, color: N.muted }}>Low → High</span>
                      </div>
                    )}
                  </div>

                  {/* Role & Focus Editor Panel */}
                  <div style={{ flex: "1 1 220px", maxWidth: 280 }}>
                    {selPlayer ? (() => {
                      const slotPos = slotPositions[editingPlayer];
                      const isNatRole = (selPlayer.activeRole || selPlayer.role) === selPlayer.role;
                      return (
                        <div style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 12, padding: 16 }}>
                          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
                            <div>
                              <div style={{ fontSize: 15, fontWeight: 800, color: N.text }}>{selPlayer.firstName} {selPlayer.lastName}</div>
                              <div style={{ fontSize: 11, color: N.muted }}>{slotPos} · OVR {selPlayer.ovr}</div>
                            </div>
                            <button onClick={() => setEditingPlayer(null)} style={{ background: "none", border: "none", color: N.muted, fontSize: 18, cursor: "pointer" }}>✕</button>
                          </div>
                          <div style={{ marginBottom: 14 }}>
                            <div style={{ fontSize: 11, fontWeight: 700, color: N.muted, marginBottom: 6 }}>PLAYER ROLE</div>
                            <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                              {getAvailableRoles(slotPos).map((roleDef) => {
                                const isActive = (selPlayer.activeRole || selPlayer.role) === roleDef.role;
                                const isNatural = selPlayer.role === roleDef.role;
                                return (
                                  <button key={roleDef.role} onClick={() => changePlayerRole(editingPlayer, roleDef.role)} style={{
                                    padding: "7px 10px", fontSize: 11, fontWeight: 600, borderRadius: 6, cursor: "pointer",
                                    textAlign: "left", display: "flex", justifyContent: "space-between", alignItems: "center",
                                    background: isActive ? `${N.cyan}15` : N.card,
                                    border: `1px solid ${isActive ? N.cyan : N.border}`,
                                    color: isActive ? N.cyan : N.text,
                                  }}>
                                    <div style={{ flex: 1 }}>
                                      <div style={{ fontWeight: 800 }}>{roleDef.role}{isNatural ? " +" : ""}</div>
                                      <div style={{ fontSize: 9, color: N.muted, marginTop: 1 }}>{roleDef.label}</div>
                                      {isActive && <div style={{ fontSize: 9, color: N.cyan, marginTop: 3, lineHeight: 1.4, opacity: 0.8 }}>{roleDef.desc}</div>}
                                    </div>
                                    {isActive && <span style={{ fontSize: 12 }}>✓</span>}
                                  </button>
                                );
                              })}
                            </div>
                            {isNatRole && <div style={{ fontSize: 9, color: "#00ff88", marginTop: 4 }}>✅ Natural role: +1 OVR bonus</div>}
                          </div>
                          <div>
                            <div style={{ fontSize: 11, fontWeight: 700, color: N.muted, marginBottom: 6 }}>FOCUS</div>
                            <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                              {(FOCUS_OPTIONS[slotPos] || ["Balanced"]).map((foc) => {
                                const isActive = (selPlayer.focus || "Balanced") === foc;
                                return (
                                  <button key={foc} onClick={() => changePlayerFocus(editingPlayer, foc)} style={{
                                    padding: "6px 12px", fontSize: 11, fontWeight: 700, borderRadius: 6, cursor: "pointer",
                                    background: isActive ? `${FOCUS_COLORS[foc]}20` : N.card,
                                    border: `1px solid ${isActive ? FOCUS_COLORS[foc] : N.border}`,
                                    color: isActive ? FOCUS_COLORS[foc] : N.text,
                                  }}>{foc}</button>
                                );
                              })}
                            </div>
                          </div>
                        </div>
                      );
                    })() : (
                      <div style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 12, padding: 20, textAlign: "center" }}>
                        <div style={{ fontSize: 28, marginBottom: 8 }}>🗺️</div>
                        <div style={{ fontSize: 13, fontWeight: 700, color: N.text, marginBottom: 4 }}>Select a Player</div>
                        <div style={{ fontSize: 11, color: N.muted }}>Tap a player to see their activity map and edit role & focus.</div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })()}

          {/* ── Squad List Sub-tab ── */}
          {squadSubTab === "squadList" && (() => {
            // Combine squad and bench, tagging where each player lives
            const slotPositions = FORMATIONS[formation].positions;
            const roster = [
              ...squad.map((p, i) => ({ ...p, _group: "squad", _slot: slotPositions[i], _idx: i })),
              ...bench.map((p, i) => ({ ...p, _group: "bench", _slot: null, _idx: i })),
            ];

            // Position ordering for sensible default sort
            const POS_ORDER = ["GK", "CB", "LB", "RB", "LWB", "RWB", "CDM", "CM", "CAM", "LM", "RM", "LW", "RW", "ST", "CF"];
            const posRank = (p) => {
              const i = POS_ORDER.indexOf(p.naturalPosition);
              return i === -1 ? 99 : i;
            };

            const sortedRoster = [...roster].sort((a, b) => {
              const dir = squadListSort.dir === "asc" ? 1 : -1;
              switch (squadListSort.key) {
                case "pos": return (posRank(a) - posRank(b)) * dir;
                case "name": return a.lastName.localeCompare(b.lastName) * dir;
                case "age": return (a.age - b.age) * dir;
                case "ovr": return (a.ovr - b.ovr) * dir;
                case "pot": {
                  const pa = a.potential ?? a.ovr;
                  const pb = b.potential ?? b.ovr;
                  return (pa - pb) * dir;
                }
                case "plan": {
                  const rank = (p) => p.injuredFor ? 0 : sellList.some((s) => s.playerId === p.id) ? 1 : p._group === "squad" ? 2 : 3;
                  return (rank(a) - rank(b)) * dir;
                }
                default: return 0;
              }
            });

            const toggleSort = (key) => {
              setSquadListSort((s) => s.key === key ? { key, dir: s.dir === "asc" ? "desc" : "asc" } : { key, dir: "asc" });
            };

            const SortHeader = ({ label, k, width, align = "left" }) => (
              <div onClick={() => toggleSort(k)} style={{
                width, textAlign: align, cursor: "pointer",
                fontSize: 10, fontWeight: 800, color: squadListSort.key === k ? N.cyan : N.muted,
                textTransform: "uppercase", letterSpacing: 0.5, userSelect: "none",
                display: "flex", alignItems: "center", justifyContent: align === "left" ? "flex-start" : "center", gap: 3,
              }}>
                {label}
                {squadListSort.key === k && <span style={{ fontSize: 9 }}>{squadListSort.dir === "asc" ? "▲" : "▼"}</span>}
              </div>
            );

            return (
              <div style={{ maxWidth: 780, margin: "0 auto", padding: "20px 16px" }}>
                <div style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 12, overflow: "hidden" }}>
                  {/* Header bar */}
                  <div style={{ padding: "12px 14px", borderBottom: `1px solid ${N.border}`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div>
                      <div style={{ fontSize: 14, fontWeight: 800, color: N.cyan }}>📊 Full Squad List</div>
                      <div style={{ fontSize: 10, color: N.muted, marginTop: 2 }}>{roster.length} players · tap any row for details & actions</div>
                    </div>
                    <div style={{ fontSize: 10, color: N.muted, fontWeight: 700 }}>
                      🟢 Starting XI · 🟡 Sub · 📋 Listed · 🏥 Injured
                    </div>
                  </div>

                  {/* Column headers */}
                  <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 14px", borderBottom: `1px solid ${N.border}`, background: N.card }}>
                    <div style={{ width: 40 }}></div>
                    <SortHeader label="Pos ▲" k="pos" width={40} align="left" />
                    <SortHeader label="Name" k="name" width={0} align="left" />
                    <div style={{ flex: 1 }}></div>
                    <SortHeader label="Age" k="age" width={38} align="center" />
                    <SortHeader label="OVR" k="ovr" width={44} align="center" />
                    <SortHeader label="POT" k="pot" width={54} align="center" />
                    <SortHeader label="Plan" k="plan" width={72} align="center" />
                  </div>

                  {/* Rows */}
                  <div style={{ maxHeight: "68vh", overflowY: "auto" }}>
                    {sortedRoster.map((p) => {
                      const ts = TIER_STYLES[getTier(p.ovr)];
                      const isListed = sellList.some((s) => s.playerId === p.id);
                      const pot = p.potential ?? p.ovr;
                      const potLabel = getPotentialLabel(p.ovr, pot);

                      // Plan chip
                      let planChip;
                      if (p.injuredFor > 0) {
                        planChip = { text: `🏥 ${p.injuredFor}m`, bg: "#ff406018", color: "#ff4060" };
                      } else if (isListed) {
                        planChip = { text: "📋 Listed", bg: `${N.gold}18`, color: N.gold };
                      } else if (p._group === "squad") {
                        planChip = { text: "🟢 Starter", bg: `${N.green}18`, color: N.green };
                      } else {
                        planChip = { text: "🟡 Sub", bg: "#ffa80018", color: "#ffa800" };
                      }

                      return (
                        <div key={`${p._group}-${p.id}`}
                          onClick={() => { setDetailPlayer(p); setDetailSlot(p._slot); }}
                          onMouseEnter={(e) => { e.currentTarget.style.background = N.card; }}
                          onMouseLeave={(e) => { e.currentTarget.style.background = "transparent"; }}
                          style={{
                            display: "flex", alignItems: "center", gap: 8, padding: "10px 14px",
                            borderBottom: `1px solid ${N.border}`, cursor: "pointer",
                            transition: "background 0.15s",
                          }}>
                          {/* Mini player face card */}
                          <div style={{ width: 40, height: 44, flexShrink: 0, background: ts.bg, borderRadius: 4, border: `1px solid ${ts.border}60`, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
                            <span style={{ fontSize: 14, fontWeight: 900, color: ts.text, lineHeight: 1 }}>{p.ovr}</span>
                            <span style={{ fontSize: 7, fontWeight: 800, color: ts.statLabel, marginTop: 1 }}>{p.naturalPosition}</span>
                          </div>

                          {/* Pos badge */}
                          <div style={{ width: 40, textAlign: "left" }}>
                            <span style={{ fontSize: 12, fontWeight: 800, color: N.text }}>{p.naturalPosition}</span>
                          </div>

                          {/* Name */}
                          <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
                            <span style={{ fontSize: 13, fontWeight: 700, color: N.text, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                              {p.firstName[0]}. {p.lastName}
                            </span>
                            <span style={{ fontSize: 9, color: N.muted, marginTop: 1 }}>
                              {p.role} · {p.focus || "Balanced"}
                            </span>
                          </div>

                          {/* Age */}
                          <div style={{ width: 38, textAlign: "center", fontSize: 12, fontWeight: 700, color: p.age <= 21 ? N.green : p.age >= 32 ? "#ff8c66" : N.text }}>
                            {p.age}
                          </div>

                          {/* OVR */}
                          <div style={{ width: 44, textAlign: "center", fontSize: 13, fontWeight: 800, color: statColor(p.ovr) }}>
                            {p.ovr}
                          </div>

                          {/* POT — showing current → potential like the reference image */}
                          <div style={{ width: 54, textAlign: "center", fontSize: 10, fontWeight: 700 }}>
                            <span style={{ color: statColor(p.ovr) }}>{p.ovr}</span>
                            <span style={{ color: N.muted, margin: "0 2px" }}>→</span>
                            <span style={{ color: potLabel.color }}>{pot}</span>
                          </div>

                          {/* Plan chip */}
                          <div style={{ width: 72, textAlign: "center" }}>
                            <span style={{
                              display: "inline-block", padding: "3px 6px", borderRadius: 4,
                              fontSize: 9, fontWeight: 800, background: planChip.bg, color: planChip.color,
                              whiteSpace: "nowrap",
                            }}>
                              {planChip.text}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div style={{ textAlign: "center", marginTop: 10, fontSize: 10, color: N.muted }}>
                  💡 Tap any row to view full stats and manage the player
                </div>
              </div>
            );
          })()}
        </div>
      )}

      {/* ═══ LEAGUE TABLE TAB ═══ */}
      {tab === "league" && leagueTable && (() => {
        const sorted = [...leagueTable].sort((a, b) => b.points - a.points || (b.gf - b.ga) - (a.gf - a.ga) || b.gf - a.gf);
        const div = getDivision(currentDivision);
        const totalTeams = sorted.length;

        return (
          <div style={{ maxWidth: 700, margin: "0 auto", padding: "24px 16px" }} onClick={(e) => e.stopPropagation()}>
            <div style={{ textAlign: "center", marginBottom: 20 }}>
              <h2 style={{ fontSize: 22, fontWeight: 800, color: N.text, margin: "0 0 4px" }}>
                <span style={{ background: `linear-gradient(135deg, ${div.color}, ${N.magenta})`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>{div.icon} {div.name}</span>
              </h2>
              <p style={{ color: N.muted, fontSize: 13, margin: 0 }}>Season {seasonNumber} · OVR {div.ovrRange[0]}-{div.ovrRange[1]}</p>
              <div style={{ display: "flex", gap: 12, justifyContent: "center", marginTop: 8, fontSize: 10 }}>
                <span style={{ color: N.green }}>🟢 Top 3 = Promoted</span>
                <span style={{ color: "#ff4060" }}>🔴 Bottom 3 = Relegated</span>
              </div>
            </div>

            <div style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 12, overflow: "hidden" }}>
              {/* Points system reminder */}
              <div style={{ padding: "8px 14px", background: N.card, borderBottom: `1px solid ${N.border}`, display: "flex", justifyContent: "center", gap: 16, fontSize: 10, color: N.muted }}>
                <span>Win <span style={{ color: N.green, fontWeight: 800 }}>+3</span></span>
                <span>Draw <span style={{ color: N.gold, fontWeight: 800 }}>+1</span></span>
                <span>Loss <span style={{ color: "#ff4060", fontWeight: 800 }}>0</span></span>
              </div>
              {/* Table header */}
              <div style={{ display: "flex", alignItems: "center", padding: "10px 14px", background: N.card, borderBottom: `1px solid ${N.border}`, fontSize: 10, fontWeight: 700, color: N.muted }}>
                <span style={{ width: 24 }}>#</span>
                <span style={{ flex: 1 }}>Club</span>
                <span style={{ width: 26, textAlign: "center" }}>MP</span>
                <span style={{ width: 22, textAlign: "center" }}>W</span>
                <span style={{ width: 22, textAlign: "center" }}>D</span>
                <span style={{ width: 22, textAlign: "center" }}>L</span>
                <span style={{ width: 26, textAlign: "center" }}>GF</span>
                <span style={{ width: 26, textAlign: "center" }}>GA</span>
                <span style={{ width: 28, textAlign: "center" }}>GD</span>
                <span style={{ width: 30, textAlign: "center", color: N.gold }}>Pts</span>
                <span style={{ width: 80, textAlign: "center" }}>Last 5</span>
              </div>
              {/* Table rows */}
              {sorted.map((team, idx) => {
                const pos = idx + 1;
                const isPromoZone = pos <= 3;
                const isReleZone = pos > totalTeams - 3;
                const gd = team.gf - team.ga;
                const form = team.form || [];
                const formPadded = [...form, ...Array(5 - form.length).fill(null)].slice(0, 5);
                return (
                  <div key={team.name} style={{
                    display: "flex", alignItems: "center", padding: "10px 14px", fontSize: 12,
                    background: team.isYou ? `${N.cyan}08` : "transparent",
                    borderBottom: `1px solid ${N.border}`,
                    borderLeft: `3px solid ${isPromoZone ? N.green : isReleZone ? "#ff4060" : "transparent"}`,
                  }}>
                    <span style={{ width: 24, fontWeight: 800, fontSize: 13, color: isPromoZone ? N.green : isReleZone ? "#ff4060" : N.muted }}>{pos}</span>
                    <span style={{ flex: 1, fontWeight: team.isYou ? 800 : 500, color: team.isYou ? N.cyan : N.text, fontSize: team.isYou ? 13 : 12 }}>
                      {team.name}
                    </span>
                    <span style={{ width: 26, textAlign: "center", color: N.muted }}>{team.played}</span>
                    <span style={{ width: 22, textAlign: "center", color: N.text, fontWeight: 600 }}>{team.won}</span>
                    <span style={{ width: 22, textAlign: "center", color: N.muted }}>{team.drawn}</span>
                    <span style={{ width: 22, textAlign: "center", color: N.muted }}>{team.lost}</span>
                    <span style={{ width: 26, textAlign: "center", color: N.muted }}>{team.gf}</span>
                    <span style={{ width: 26, textAlign: "center", color: N.muted }}>{team.ga}</span>
                    <span style={{ width: 28, textAlign: "center", fontWeight: 700, color: gd > 0 ? N.green : gd < 0 ? "#ff4060" : N.muted }}>{gd > 0 ? "+" : ""}{gd}</span>
                    <span style={{ width: 30, textAlign: "center", fontWeight: 900, fontSize: 14, color: N.gold }}>{team.points}</span>
                    <div style={{ width: 80, display: "flex", gap: 3, justifyContent: "center" }}>
                      {formPadded.map((r, fi) => (
                        <div key={fi} style={{
                          width: 14, height: 14, borderRadius: "50%",
                          display: "flex", alignItems: "center", justifyContent: "center",
                          fontSize: 8, fontWeight: 900,
                          background: r === "W" ? N.green : r === "D" ? N.muted : r === "L" ? "#ff4060" : `${N.muted}30`,
                          color: r ? "#000" : "transparent",
                        }}>
                          {r === "W" ? "✓" : r === "D" ? "−" : r === "L" ? "✕" : ""}
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Division info */}
            <div style={{ marginTop: 16, display: "flex", gap: 8, justifyContent: "center", flexWrap: "wrap" }}>
              {LEAGUE_DIVISIONS.map((d) => (
                <div key={d.tier} style={{
                  padding: "6px 14px", borderRadius: 6, fontSize: 11, fontWeight: 700,
                  background: currentDivision === d.tier ? `${d.color}15` : N.card,
                  border: `1px solid ${currentDivision === d.tier ? d.color : N.border}`,
                  color: currentDivision === d.tier ? d.color : N.muted,
                }}>
                  {d.icon} {d.name}
                </div>
              ))}
            </div>
          </div>
        );
      })()}

      {/* ═══ TRANSFERS TAB ═══ */}
      {tab === "transfers" && (
        <div onClick={(e) => e.stopPropagation()}>
          {/* Sub-tab bar */}
          <div style={{ background: N.card, borderBottom: `1px solid ${N.border}`, padding: "0 16px" }}>
            <div style={{ maxWidth: 900, margin: "0 auto", display: "flex" }}>
              {[
                { id: "search", label: "🔍 Search" },
                { id: "scouts", label: `🕵️ Scouts (${hiredScouts.length})` },
                { id: "list", label: `⭐ Shortlist (${transferList.length})` },
                { id: "sell", label: `📋 Transfer List (${sellList.length})` },
                { id: "pending", label: `✍️ Agreed (${pendingSignings.length + agreedSales.length})` },
              ].map((st) => (
                <button key={st.id} onClick={() => setTransferSubTab(st.id)} style={{
                  padding: "10px 14px", fontSize: 11, fontWeight: 700, border: "none", cursor: "pointer",
                  background: "transparent", color: transferSubTab === st.id ? N.cyan : N.muted,
                  borderBottom: `2px solid ${transferSubTab === st.id ? N.cyan : "transparent"}`,
                  whiteSpace: "nowrap",
                }}>{st.label}</button>
              ))}
            </div>
          </div>

          {/* ── SEARCH (browse all players) ── */}
          {transferSubTab === "search" && (
            <div style={{ maxWidth: 950, margin: "0 auto", padding: "20px 16px" }}>
              {(
                <>
                  {/* Filters */}
                  <div style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 12, padding: 14, marginBottom: 16 }}>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10, flexWrap: "wrap", gap: 8 }}>
                      <div style={{ fontSize: 14, fontWeight: 800, color: N.text }}>Player Database</div>
                      <div style={{ fontSize: 11, color: N.muted }}>
                        <span style={{ color: N.cyan, fontWeight: 800 }}>{visiblePlayers.length}</span> players available worldwide
                      </div>
                    </div>
                    <input type="text" placeholder="Search by name..." value={filterName} onChange={(e) => setFilterName(e.target.value)}
                      style={{ width: "100%", padding: "8px 12px", fontSize: 13, background: N.card, border: `1px solid ${N.border}`, borderRadius: 6, color: N.text, outline: "none", boxSizing: "border-box", marginBottom: 10 }} />
                    <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                      <div style={{ flex: "1 1 130px" }}>
                        <div style={{ fontSize: 10, fontWeight: 700, color: N.muted, marginBottom: 3 }}>POSITION</div>
                        <select value={filterPos} onChange={(e) => setFilterPos(e.target.value)}
                          style={{ width: "100%", padding: "6px 8px", fontSize: 12, background: N.card, color: N.cyan, border: `1px solid ${N.border}`, borderRadius: 5, cursor: "pointer", outline: "none" }}>
                          <option value="ALL">All Positions</option>
                          {ALL_POSITIONS.map((pos) => <option key={pos} value={pos}>{pos}</option>)}
                        </select>
                      </div>
                      <div style={{ flex: "1 1 130px" }}>
                        <div style={{ fontSize: 10, fontWeight: 700, color: N.muted, marginBottom: 3 }}>MIN OVR: {filterMinOvr}</div>
                        <input type="range" min="0" max="99" value={filterMinOvr} onChange={(e) => setFilterMinOvr(Number(e.target.value))}
                          style={{ width: "100%", accentColor: N.cyan }} />
                      </div>
                      <div style={{ flex: "1 1 130px" }}>
                        <div style={{ fontSize: 10, fontWeight: 700, color: N.muted, marginBottom: 3 }}>MAX AGE: {filterMaxAge}</div>
                        <input type="range" min="17" max="40" value={filterMaxAge} onChange={(e) => setFilterMaxAge(Number(e.target.value))}
                          style={{ width: "100%", accentColor: N.gold }} />
                      </div>
                      <button onClick={() => { setFilterPos("ALL"); setFilterMinOvr(0); setFilterMaxAge(40); setFilterName(""); }}
                        style={{ padding: "6px 12px", fontSize: 11, fontWeight: 700, background: "transparent", border: `1px solid ${N.border}`, borderRadius: 5, color: N.muted, cursor: "pointer", alignSelf: "flex-end" }}>
                        Clear
                      </button>
                    </div>
                  </div>

                  {/* Player grid */}
                  {visiblePlayers.length === 0 ? (
                    <div style={{ textAlign: "center", padding: 40, background: N.surface, borderRadius: 12, border: `1px solid ${N.border}`, fontSize: 12, color: N.muted }}>
                      No players match your filters. Try widening your search or hiring a better scout.
                    </div>
                  ) : (
                    <>
                      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: 12 }}>
                        {visiblePlayers.slice(0, searchLimit).map((p) => {
                          const ts = TIER_STYLES[getTier(p.ovr)];
                          const pot = getPotentialLabel(p.ovr, p.potential);
                          return (
                            <div key={p.id} style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 10, padding: 14 }}>
                              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
                                <div style={{ width: 42, height: 54, background: ts.bg, borderRadius: 5, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                                  <span style={{ fontSize: 17, fontWeight: 900, color: ts.text, lineHeight: 1 }}>{p.ovr}</span>
                                  <span style={{ fontSize: 7, fontWeight: 800, color: ts.statLabel }}>{p.naturalPosition}</span>
                                </div>
                                <div style={{ flex: 1, minWidth: 0 }}>
                                  <div style={{ fontSize: 13, fontWeight: 800, color: N.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{p.firstName} {p.lastName}</div>
                                  <div style={{ fontSize: 10, color: N.muted }}>{p.nationality} · Age {p.age} · {p.preferredFoot}</div>
                                  <div style={{ fontSize: 10, color: pot.color, fontWeight: 700 }}>{pot.icon} POT {p.potential}</div>
                                </div>
                              </div>
                              <div style={{ fontSize: 10, color: N.muted, marginBottom: 6 }}>{p.currentClub}</div>
                              {p.altPositions?.length > 0 && (
                                <div style={{ display: "flex", gap: 4, marginBottom: 8, alignItems: "center" }}>
                                  <span style={{ fontSize: 9, color: N.muted }}>Alt:</span>
                                  {p.altPositions.map((ap) => (
                                    <span key={ap} style={{ fontSize: 9, fontWeight: 700, padding: "1px 5px", borderRadius: 3, background: `${N.green}15`, color: N.green }}>{ap}</span>
                                  ))}
                                </div>
                              )}
                              <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "3px 6px", marginBottom: 10 }}>
                                {[["PAC", p.pac], ["SHO", p.sho], ["PAS", p.pas], ["DRI", p.dri], ["DEF", p.def], ["PHY", p.phy]].map(([l, v]) => (
                                  <div key={l} style={{ display: "flex", justifyContent: "space-between", fontSize: 9 }}>
                                    <span style={{ color: N.muted, fontWeight: 700 }}>{l}</span>
                                    <span style={{ color: statColor(v), fontWeight: 800 }}>{v}</span>
                                  </div>
                                ))}
                              </div>
                              <button onClick={() => listPlayer(p)} style={{
                                width: "100%", padding: "8px", fontSize: 11, fontWeight: 800, borderRadius: 6,
                                background: `linear-gradient(135deg, ${N.cyan}, ${N.magenta})`, border: "none", color: "#000", cursor: "pointer",
                              }}>+ LIST PLAYER</button>
                            </div>
                          );
                        })}
                      </div>
                      {visiblePlayers.length > searchLimit && (
                        <div style={{ textAlign: "center", marginTop: 16 }}>
                          <button onClick={() => setSearchLimit((l) => l + 24)} style={{
                            padding: "10px 28px", fontSize: 12, fontWeight: 700, borderRadius: 8,
                            background: N.card, border: `1px solid ${N.border}`, color: N.cyan, cursor: "pointer",
                          }}>LOAD MORE ({visiblePlayers.length - searchLimit} remaining)</button>
                        </div>
                      )}
                    </>
                  )}
                </>
              )}
            </div>
          )}

          {/* ── TRANSFER LIST ── */}
          {transferSubTab === "list" && (
            <div style={{ maxWidth: 700, margin: "0 auto", padding: "20px 16px" }}>
              <div style={{ textAlign: "center", marginBottom: 16 }}>
                <div style={{ fontSize: 18, fontWeight: 800, color: N.text }}>Shortlist</div>
                <div style={{ fontSize: 11, color: N.muted }}>Players you're tracking. Open talks with their agent when you're ready.</div>
              </div>
              {transferList.length === 0 ? (
                <div style={{ textAlign: "center", padding: 40, background: N.surface, borderRadius: 12, border: `1px solid ${N.border}`, fontSize: 12, color: N.muted }}>
                  Nobody shortlisted yet. Find talent in Search or via your scouts.
                </div>
              ) : (
                <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                  {transferList.map((p) => {
                    const ts = TIER_STYLES[getTier(p.ovr)];
                    const pot = getPotentialLabel(p.ovr, p.potential);
                    return (
                      <div key={p.id} style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 10, padding: 14, display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
                        <div style={{ width: 40, height: 50, background: ts.bg, borderRadius: 5, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                          <span style={{ fontSize: 16, fontWeight: 900, color: ts.text, lineHeight: 1 }}>{p.ovr}</span>
                          <span style={{ fontSize: 7, fontWeight: 800, color: ts.statLabel }}>{p.naturalPosition}</span>
                        </div>
                        <div style={{ flex: 1, minWidth: 120 }}>
                          <div style={{ fontSize: 14, fontWeight: 800, color: N.text }}>{p.firstName} {p.lastName}</div>
                          <div style={{ fontSize: 10, color: N.muted }}>{p.nationality} · Age {p.age} · {p.role}</div>
                          <div style={{ fontSize: 10, color: pot.color, fontWeight: 700 }}>{pot.icon} POT {p.potential}</div>
                        </div>
                        <div style={{ display: "flex", gap: 6 }}>
                          <button onClick={() => startInterview(p)} style={{
                            padding: "8px 16px", fontSize: 11, fontWeight: 800, borderRadius: 6,
                            background: `linear-gradient(135deg, ${N.green}, ${N.cyan})`, border: "none", color: "#000", cursor: "pointer",
                          }}>💬 NEGOTIATE</button>
                          <button onClick={() => unlistPlayer(p.id)} style={{
                            padding: "8px 12px", fontSize: 11, fontWeight: 700, borderRadius: 6,
                            background: "transparent", border: `1px solid ${N.border}`, color: N.muted, cursor: "pointer",
                          }}>✕</button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* ── SCOUTS ── */}
          {transferSubTab === "scouts" && (
            <div style={{ maxWidth: 700, margin: "0 auto", padding: "20px 16px" }}>
              {hiredScouts.length > 0 && (
                <div style={{ marginBottom: 20 }}>
                  <div style={{ fontSize: 14, fontWeight: 800, color: N.cyan, marginBottom: 4 }}>Your Scouts</div>
                  <div style={{ fontSize: 11, color: N.muted, marginBottom: 10 }}>Give each scout a brief. They work between matches and their reports sharpen over time.</div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                    {hiredScouts.map((sc) => {
                      const a = sc.assignment;
                      const typeDef = a ? ASSIGNMENT_TYPES.find((t) => t.id === a.type) : null;
                      return (
                        <div key={sc.id} style={{ background: N.surface, border: `1px solid ${sc.color}30`, borderRadius: 10, padding: "12px 16px" }}>
                          <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 12, marginBottom: 8 }}>
                            <div style={{ flex: 1 }}>
                              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                                <span style={{ fontSize: 11, color: sc.color }}>{"\u2b50".repeat(sc.stars)}</span>
                                <span style={{ fontSize: 13, fontWeight: 800, color: N.text }}>{sc.name}</span>
                              </div>
                              <div style={{ fontSize: 10, color: N.muted }}>{sc.tierName} · ${sc.wage}/match · knows {sc.knownRegions.join(", ")}</div>
                              <div style={{ display: "flex", gap: 10, marginTop: 4, flexWrap: "wrap" }}>
                                {[["Ability", sc.judgingAbility], ["Potential", sc.judgingPotential], ["Tactical", sc.tacticalKnowledge], ["Adapt", sc.adaptability]].map(([l, v]) => (
                                  <span key={l} style={{ fontSize: 9, color: N.muted }}>
                                    {l} <span style={{ color: v >= 15 ? N.green : v >= 10 ? N.gold : "#ff6b6b", fontWeight: 800 }}>{v}</span>
                                  </span>
                                ))}
                              </div>
                            </div>
                            <button onClick={() => fireScout(sc.id)} style={{
                              padding: "6px 12px", fontSize: 10, fontWeight: 700, borderRadius: 5,
                              background: "rgba(255,64,96,0.1)", border: "1px solid #ff406030", color: "#ff4060", cursor: "pointer",
                            }}>FIRE</button>
                          </div>

                          {/* Current assignment */}
                          {a && typeDef ? (
                            <div style={{ padding: "8px 10px", borderRadius: 6, background: `${sc.color}10`, border: `1px solid ${sc.color}25`, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
                              <div>
                                <div style={{ fontSize: 11, fontWeight: 700, color: sc.color }}>{typeDef.icon} {typeDef.describe(a.params)}</div>
                                <div style={{ fontSize: 9, color: N.muted }}>{(a.found || []).length} player{(a.found || []).length === 1 ? "" : "s"} identified · {a.cycles || 0} report cycle{(a.cycles || 0) === 1 ? "" : "s"}</div>
                              </div>
                              <button onClick={() => clearAssignment(sc.id)} style={{
                                padding: "5px 10px", fontSize: 9, fontWeight: 700, borderRadius: 4,
                                background: "transparent", border: `1px solid ${N.border}`, color: N.muted, cursor: "pointer",
                              }}>Reassign</button>
                            </div>
                          ) : (
                            <div>
                              <div style={{ fontSize: 10, fontWeight: 700, color: N.muted, marginBottom: 5 }}>ASSIGN A BRIEF</div>
                              <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
                                {sc.knownRegions.slice(0, 3).map((rg) => (
                                  <button key={rg} onClick={() => assignScout(sc.id, "region", { region: rg })} style={{
                                    padding: "5px 9px", fontSize: 9, fontWeight: 700, borderRadius: 4,
                                    background: N.card, border: `1px solid ${N.border}`, color: N.text, cursor: "pointer",
                                  }}>🌍 {rg}</button>
                                ))}
                                {["ST", "CM", "CB", "GK"].map((pos) => (
                                  <button key={pos} onClick={() => assignScout(sc.id, "position", { position: pos })} style={{
                                    padding: "5px 9px", fontSize: 9, fontWeight: 700, borderRadius: 4,
                                    background: N.card, border: `1px solid ${N.border}`, color: N.text, cursor: "pointer",
                                  }}>🎯 {pos}s</button>
                                ))}
                                <button onClick={() => assignScout(sc.id, "youth", { maxAge: 21 })} style={{
                                  padding: "5px 9px", fontSize: 9, fontWeight: 700, borderRadius: 4,
                                  background: N.card, border: `1px solid ${N.border}`, color: N.text, cursor: "pointer",
                                }}>🌱 U21 talent</button>
                                {ASSIGNMENT_ATTRS.slice(0, 3).map((at) => (
                                  <button key={at.attr} onClick={() => assignScout(sc.id, "attribute", { attr: at.attr, attrLabel: at.label, min: 78 })} style={{
                                    padding: "5px 9px", fontSize: 9, fontWeight: 700, borderRadius: 4,
                                    background: N.card, border: `1px solid ${N.border}`, color: N.text, cursor: "pointer",
                                  }}>⚡ {at.label} 78+</button>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Scout reports */}
              {scoutReports.length > 0 && (
                <div style={{ marginBottom: 20 }}>
                  <div style={{ fontSize: 14, fontWeight: 800, color: N.green, marginBottom: 4 }}>📋 Scout Reports</div>
                  <div style={{ fontSize: 11, color: N.muted, marginBottom: 10 }}>Estimates, not facts. The longer a scout watches, the tighter the range.</div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                    {scoutReports.slice(0, 12).map(({ scout, player, report }) => {
                      const ab = report.ability;
                      const pt = report.potential;
                      const abTxt = ab.exact ? String(ab.value) : `${ab.lo}–${ab.hi}`;
                      const ptTxt = pt.exact ? String(pt.value) : `${pt.lo}–${pt.hi}`;
                      const confCol = report.progress >= 4 ? N.green : report.progress >= 2 ? N.gold : N.muted;
                      return (
                        <div key={player.id} style={{ background: N.surface, border: `1px solid ${N.green}25`, borderRadius: 10, padding: 12, display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
                          <div style={{ width: 40, height: 50, background: N.card, borderRadius: 5, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", flexShrink: 0, border: `1px solid ${N.border}` }}>
                            <span style={{ fontSize: 12, fontWeight: 900, color: N.text, lineHeight: 1 }}>{abTxt.length > 3 ? "?" : abTxt}</span>
                            <span style={{ fontSize: 7, fontWeight: 800, color: N.muted }}>{player.naturalPosition}</span>
                          </div>
                          <div style={{ flex: 1, minWidth: 150 }}>
                            <div style={{ fontSize: 13, fontWeight: 800, color: N.text }}>{player.firstName} {player.lastName}</div>
                            <div style={{ fontSize: 10, color: N.muted }}>Age {player.age} · {player.currentClub}</div>
                            <div style={{ display: "flex", gap: 10, marginTop: 3, flexWrap: "wrap" }}>
                              <span style={{ fontSize: 10, color: N.cyan }}>Ability <b>{abTxt}</b></span>
                              <span style={{ fontSize: 10, color: N.magenta }}>Potential <b>{ptTxt}</b></span>
                            </div>
                            <div style={{ fontSize: 9, color: confCol, marginTop: 3 }}>
                              {scout.name} · {report.confidence} report ({report.progress}/5)
                              {report.role ? ` · best as ${report.role}` : " · role unclear"}
                            </div>
                          </div>
                          <button onClick={() => listPlayer(player)} style={{
                            padding: "8px 14px", fontSize: 11, fontWeight: 800, borderRadius: 6,
                            background: `linear-gradient(135deg, ${N.green}, ${N.cyan})`, border: "none", color: "#000", cursor: "pointer",
                          }}>+ LIST</button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              <div style={{ fontSize: 14, fontWeight: 800, color: N.gold, marginBottom: 10 }}>Hire New Scouts</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {SCOUT_TIERS.map((t) => {
                  const canAfford = money >= t.hireCost;
                  return (
                    <div key={t.stars} style={{
                      background: N.surface, border: `1px solid ${canAfford ? t.color + "30" : N.border}`,
                      borderRadius: 10, padding: "14px 16px", opacity: canAfford ? 1 : 0.5,
                      display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, flexWrap: "wrap",
                    }}>
                      <div style={{ flex: 1, minWidth: 160 }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 2 }}>
                          <span style={{ fontSize: 12, color: t.color }}>{"⭐".repeat(t.stars)}</span>
                          <span style={{ fontSize: 14, fontWeight: 800, color: N.text }}>{t.name}</span>
                        </div>
                        <div style={{ fontSize: 11, color: N.muted }}>{t.desc}</div>
                        <div style={{ fontSize: 10, color: N.gold, marginTop: 2 }}>Wage: ${t.wage}/match</div>
                      </div>
                      <button onClick={() => hireScout(t.stars)} disabled={!canAfford} style={{
                        padding: "9px 18px", fontSize: 12, fontWeight: 800, borderRadius: 7, cursor: canAfford ? "pointer" : "not-allowed",
                        background: canAfford ? `linear-gradient(135deg, ${t.color}, ${t.color}cc)` : N.card,
                        border: canAfford ? "none" : `1px solid ${N.border}`,
                        color: canAfford ? "#000" : N.muted, whiteSpace: "nowrap",
                      }}>Hire ${t.hireCost.toLocaleString()}</button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ── SELL ── */}
          {transferSubTab === "sell" && (
            <div style={{ maxWidth: 760, margin: "0 auto", padding: "20px 16px" }}>
              <div style={{ textAlign: "center", marginBottom: 16 }}>
                <div style={{ fontSize: 18, fontWeight: 800, color: N.text }}>Transfer List</div>
                <div style={{ fontSize: 11, color: N.muted }}>Players here can be approached by other clubs. Offers arrive between matches.</div>
              </div>

              {approachAlert && approachAlert.length > 0 && (
                <div style={{ background: `${N.gold}10`, border: `1px solid ${N.gold}35`, borderRadius: 10, padding: "12px 16px", marginBottom: 16 }}>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 6 }}>
                    <span style={{ fontSize: 12, fontWeight: 800, color: N.gold }}>📨 New Approaches</span>
                    <button onClick={() => setApproachAlert(null)} style={{
                      background: "none", border: "none", color: N.muted, fontSize: 14, cursor: "pointer",
                    }}>✕</button>
                  </div>
                  {approachAlert.map((a, i) => (
                    <div key={i} style={{ fontSize: 11, color: N.text, marginBottom: 2 }}>
                      <b>{a.offer.clubName}</b> have come in for <b>{a.player.lastName}</b> — ${a.offer.amount}
                    </div>
                  ))}
                </div>
              )}

              {/* Players currently listed */}
              {sellList.length > 0 && (
                <div style={{ marginBottom: 22 }}>
                  <div style={{ fontSize: 13, fontWeight: 800, color: N.gold, marginBottom: 10 }}>Listed ({sellList.length})</div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                    {sellList.map((entry) => {
                      const player = (entry.source === "squad" ? squad : bench).find((p) => p.id === entry.playerId);
                      if (!player) return null;
                      const ts = TIER_STYLES[getTier(player.ovr)];
                      const value = playerMarketValue(player);
                      const offers = entry.offers || [];
                      return (
                        <div key={entry.playerId} style={{ background: N.surface, border: `1px solid ${N.gold}30`, borderRadius: 10, padding: 14 }}>
                          <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap", marginBottom: 10 }}>
                            <div style={{ width: 40, height: 50, background: ts.bg, borderRadius: 5, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                              <span style={{ fontSize: 16, fontWeight: 900, color: ts.text, lineHeight: 1 }}>{player.ovr}</span>
                              <span style={{ fontSize: 7, fontWeight: 800, color: ts.statLabel }}>{player.naturalPosition}</span>
                            </div>
                            <div style={{ flex: 1, minWidth: 130 }}>
                              <div style={{ fontSize: 14, fontWeight: 800, color: N.text }}>{player.firstName} {player.lastName}</div>
                              <div style={{ fontSize: 10, color: N.muted }}>Age {player.age} · {entry.source === "squad" ? "Starting XI" : "Bench"} · valued at ${value}</div>
                              <div style={{ fontSize: 10, color: N.muted, marginTop: 2 }}>
                                Listed {entry.weeksListed || 0} match{(entry.weeksListed || 0) === 1 ? "" : "es"} ago
                              </div>
                            </div>
                            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                              <span style={{ fontSize: 10, color: N.muted }}>Asking</span>
                              <input type="number" value={entry.askingPrice}
                                onChange={(e) => setAskingPrice(entry.playerId, Math.max(10, Number(e.target.value) || 0))}
                                style={{ width: 78, padding: "5px 8px", fontSize: 12, fontWeight: 700, background: N.card, border: `1px solid ${N.border}`, borderRadius: 5, color: N.gold, outline: "none" }} />
                              <button onClick={() => unlistFromSale(entry.playerId)} style={{
                                padding: "6px 10px", fontSize: 10, fontWeight: 700, borderRadius: 5,
                                background: "transparent", border: `1px solid ${N.border}`, color: N.muted, cursor: "pointer",
                              }}>Withdraw</button>
                            </div>
                          </div>

                          {/* Incoming offers */}
                          {offers.length === 0 ? (
                            <div style={{ padding: "8px 12px", borderRadius: 6, background: N.card, fontSize: 11, color: N.muted }}>
                              No offers yet. Clubs will look at him after the next match.
                            </div>
                          ) : (
                            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                              {offers.map((o) => {
                                const meetsAsking = o.amount >= entry.askingPrice;
                                const vsValue = o.amount / value;
                                const verdict = vsValue >= 1.15 ? { t: "Excellent", c: N.green }
                                  : vsValue >= 0.95 ? { t: "Fair", c: N.cyan }
                                  : vsValue >= 0.75 ? { t: "Low", c: N.gold }
                                  : { t: "Insulting", c: "#ff4060" };
                                return (
                                  <div key={o.id} style={{
                                    display: "flex", alignItems: "center", gap: 10, padding: "9px 12px", borderRadius: 6,
                                    background: meetsAsking ? `${N.green}10` : N.card,
                                    border: `1px solid ${meetsAsking ? N.green + "30" : N.border}`, flexWrap: "wrap",
                                  }}>
                                    <div style={{ flex: 1, minWidth: 140 }}>
                                      <div style={{ fontSize: 12, fontWeight: 700, color: N.text }}>{o.clubName}</div>
                                      <div style={{ fontSize: 9, color: N.muted }}>
                                        Div {o.clubDivision} · rep {o.clubReputation} · {o.interest}% keen
                                        {o.patience <= 1 ? <span style={{ color: "#ff4060" }}> · about to walk</span> : ""}
                                      </div>
                                    </div>
                                    <div style={{ textAlign: "right" }}>
                                      <div style={{ fontSize: 15, fontWeight: 900, color: N.gold }}>${o.amount}</div>
                                      <div style={{ fontSize: 9, fontWeight: 700, color: verdict.c }}>{verdict.t}</div>
                                    </div>
                                    <div style={{ display: "flex", gap: 5 }}>
                                      <button onClick={() => openSaleTalks(entry.playerId, o.id)} style={{
                                        padding: "7px 12px", fontSize: 11, fontWeight: 800, borderRadius: 5,
                                        background: `${N.cyan}18`, border: `1px solid ${N.cyan}40`, color: N.cyan, cursor: "pointer",
                                      }}>💬 TALK</button>
                                      <button onClick={() => acceptOffer(entry.playerId, o.id)} style={{
                                        padding: "7px 12px", fontSize: 11, fontWeight: 800, borderRadius: 5,
                                        background: `linear-gradient(135deg, ${N.green}, ${N.cyan})`, border: "none", color: "#000", cursor: "pointer",
                                      }}>ACCEPT</button>
                                      <button onClick={() => rejectOffer(entry.playerId, o.id)} style={{
                                        padding: "7px 10px", fontSize: 11, fontWeight: 700, borderRadius: 5,
                                        background: "transparent", border: `1px solid ${N.border}`, color: N.muted, cursor: "pointer",
                                      }}>✕</button>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Your squad — pick someone to list */}
              <div style={{ fontSize: 13, fontWeight: 800, color: N.cyan, marginBottom: 4 }}>Your Players</div>
              <div style={{ fontSize: 11, color: N.muted, marginBottom: 10 }}>Add a player to the transfer list and clubs will start making approaches.</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
                {[
                  ...squad.map((p, i) => ({ p, source: "squad", label: slotPositions[i] })),
                  ...bench.map((p) => ({ p, source: "bench", label: "SUB" })),
                ].filter(({ p }) =>
                  !sellList.some((s) => s.playerId === p.id) &&
                  !agreedSales.some((s) => s.player.id === p.id)
                ).map(({ p, source, label }) => {
                  const ts = TIER_STYLES[getTier(p.ovr)];
                  const value = playerMarketValue(p);
                  return (
                    <div key={p.id} style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 12px", borderRadius: 7, background: N.surface, border: `1px solid ${N.border}` }}>
                      <span style={{ fontSize: 13, fontWeight: 900, color: ts.accent, width: 26, textAlign: "center" }}>{p.ovr}</span>
                      <span style={{ fontSize: 8, fontWeight: 700, width: 34, textAlign: "center", padding: "2px 4px", borderRadius: 3, background: ts.bg, color: ts.text }}>{label}</span>
                      <div style={{ flex: 1, minWidth: 100 }}>
                        <div style={{ fontSize: 12, fontWeight: 700, color: N.text }}>{p.firstName[0]}. {p.lastName}</div>
                        <div style={{ fontSize: 9, color: N.muted }}>Age {p.age} · POT {p.potential ?? p.ovr} · ${getPlayerSalary(p)}/match</div>
                      </div>
                      <span style={{ fontSize: 12, fontWeight: 800, color: N.gold, width: 60, textAlign: "right" }}>${value}</span>
                      <button onClick={() => listForSale(p, source)} style={{
                        padding: "6px 14px", fontSize: 10, fontWeight: 800, borderRadius: 5,
                        background: `${N.gold}18`, border: `1px solid ${N.gold}40`, color: N.gold, cursor: "pointer",
                      }}>+ LIST</button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ── PENDING SIGNINGS ── */}
          {transferSubTab === "pending" && (
            <div style={{ maxWidth: 700, margin: "0 auto", padding: "20px 16px" }}>
              <div style={{ textAlign: "center", marginBottom: 16 }}>
                <div style={{ fontSize: 18, fontWeight: 800, color: N.text }}>Agreed Signings</div>
                <div style={{ fontSize: 11, color: N.muted }}>These players join your club when the transfer window opens</div>
              </div>
              {/* Departures you've agreed */}
              {agreedSales.length > 0 && (
                <div style={{ marginBottom: 20 }}>
                  <div style={{ fontSize: 13, fontWeight: 800, color: "#ff6b6b", marginBottom: 4 }}>Agreed Departures ({agreedSales.length})</div>
                  <div style={{ fontSize: 11, color: N.muted, marginBottom: 10 }}>
                    Leaving at the window · ${agreedSales.reduce((s, x) => s + x.offer.amount, 0)} incoming
                  </div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                    {agreedSales.map((s) => {
                      const ts = TIER_STYLES[getTier(s.player.ovr)];
                      return (
                        <div key={s.player.id} style={{ background: N.surface, border: "1px solid #ff6b6b30", borderRadius: 10, padding: 12, display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
                          <div style={{ width: 38, height: 48, background: ts.bg, borderRadius: 5, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                            <span style={{ fontSize: 15, fontWeight: 900, color: ts.text, lineHeight: 1 }}>{s.player.ovr}</span>
                            <span style={{ fontSize: 7, fontWeight: 800, color: ts.statLabel }}>{s.player.naturalPosition}</span>
                          </div>
                          <div style={{ flex: 1, minWidth: 130 }}>
                            <div style={{ fontSize: 13, fontWeight: 800, color: N.text }}>{s.player.firstName} {s.player.lastName}</div>
                            <div style={{ fontSize: 10, color: N.muted }}>Joining {s.offer.clubName}</div>
                            <div style={{ fontSize: 11, fontWeight: 800, color: N.gold }}>${s.offer.amount}</div>
                          </div>
                          <button onClick={() => cancelSale(s.player.id)} style={{
                            padding: "6px 12px", fontSize: 10, fontWeight: 700, borderRadius: 5,
                            background: "transparent", border: `1px solid ${N.border}`, color: N.muted, cursor: "pointer",
                          }}>Cancel</button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {pendingSignings.length === 0 ? (
                <div style={{ textAlign: "center", padding: 40, background: N.surface, borderRadius: 12, border: `1px solid ${N.border}`, fontSize: 12, color: N.muted }}>
                  No agreed signings yet. Negotiate with listed players! ✍️
                </div>
              ) : (
                <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                  {pendingSignings.map((ps, i) => {
                    const p = ps.player;
                    const ts = TIER_STYLES[getTier(p.ovr)];
                    return (
                      <div key={i} style={{ background: N.surface, border: `1px solid ${N.green}30`, borderRadius: 10, padding: 14, display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
                        <div style={{ width: 40, height: 50, background: ts.bg, borderRadius: 5, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                          <span style={{ fontSize: 16, fontWeight: 900, color: ts.text, lineHeight: 1 }}>{p.ovr}</span>
                          <span style={{ fontSize: 7, fontWeight: 800, color: ts.statLabel }}>{p.naturalPosition}</span>
                        </div>
                        <div style={{ flex: 1, minWidth: 120 }}>
                          <div style={{ fontSize: 14, fontWeight: 800, color: N.text }}>{p.firstName} {p.lastName}</div>
                          <div style={{ fontSize: 10, color: N.muted }}>Salary ${ps.salary}/match · Clause ${ps.clause}</div>
                          <div style={{ fontSize: 10, color: N.green, fontWeight: 700 }}>✅ Contract agreed</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ═══ SEASON TAB ═══ */}
      {tab === "season" && season && (
        <div style={{ maxWidth: 700, margin: "0 auto", padding: "24px 16px" }} onClick={(e) => e.stopPropagation()}>
          <div style={{ textAlign: "center", marginBottom: 20 }}>
            <h2 style={{ fontSize: 22, fontWeight: 800, color: N.text, margin: "0 0 4px" }}>
              <span style={{ background: `linear-gradient(135deg, ${getDivision(currentDivision).color}, ${N.magenta})`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>Season {seasonNumber}</span>
            </h2>
            <p style={{ color: getDivision(currentDivision).color, fontSize: 13, margin: 0, fontWeight: 700 }}>
              {getDivision(currentDivision).icon} {getDivision(currentDivision).name}
            </p>
            <div style={{ display: "flex", gap: 12, justifyContent: "center", marginTop: 10 }}>
              <span style={{ fontSize: 13, fontWeight: 700, color: N.green }}>{season.filter((m) => m.result?.outcome === "W").length}W</span>
              <span style={{ fontSize: 13, fontWeight: 700, color: N.gold }}>{season.filter((m) => m.result?.outcome === "D").length}D</span>
              <span style={{ fontSize: 13, fontWeight: 700, color: "#ff4060" }}>{season.filter((m) => m.result?.outcome === "L").length}L</span>
            </div>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {season.map((match, i) => {
              const isCurrent = i === matchIdx && !match.result;
              const isPast = !!match.result;
              const isFuture = i > matchIdx;
              return (
                <div key={match.id} style={{
                  background: isCurrent ? `linear-gradient(135deg, ${N.surface}, ${N.card})` : N.surface,
                  border: `1px solid ${isCurrent ? N.cyan + "40" : N.border}`, borderRadius: 10, padding: "14px 18px",
                  boxShadow: isCurrent ? `0 0 20px ${N.cyan}15` : "none", opacity: isFuture ? 0.6 : 1,
                }}>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 12, flex: 1 }}>
                      <div style={{
                        width: 36, height: 36, borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column",
                        background: isPast ? (match.result.outcome === "W" ? `${N.green}15` : match.result.outcome === "D" ? `${N.gold}15` : "rgba(255,64,96,0.1)") : isCurrent ? `${N.cyan}15` : N.card,
                        border: `1px solid ${isPast ? (match.result.outcome === "W" ? N.green + "30" : match.result.outcome === "D" ? N.gold + "30" : "#ff406030") : isCurrent ? N.cyan + "30" : N.border}`,
                      }}>
                        <span style={{ fontSize: 8, fontWeight: 700, color: N.muted, lineHeight: 1 }}>MD</span>
                        <span style={{ fontSize: 14, fontWeight: 900, lineHeight: 1, color: isPast ? (match.result.outcome === "W" ? N.green : match.result.outcome === "D" ? N.gold : "#ff4060") : isCurrent ? N.cyan : N.muted }}>{match.matchDay}</span>
                      </div>
                      <div>
                        <div style={{ fontSize: 14, fontWeight: 700, color: N.text }}>{match.opponent}</div>
                        <div style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 2 }}>
                          <span style={{ fontSize: 11, fontWeight: 700, color: DIFFICULTY_COLORS[match.difficulty] }}>{DIFFICULTY_LABELS[match.difficulty]}</span>
                          <span style={{ fontSize: 11, color: N.muted }}>OVR {match.oppOvr}</span>
                          <span style={{ fontSize: 11, color: N.muted }}>· {match.formation}</span>
                        </div>
                      </div>
                    </div>
                    {isPast && (
                      <div style={{ textAlign: "right" }}>
                        <div style={{ fontSize: 22, fontWeight: 900, color: match.result.outcome === "W" ? N.green : match.result.outcome === "D" ? N.gold : "#ff4060" }}>{match.result.homeGoals} - {match.result.awayGoals}</div>
                        <div style={{ fontSize: 10, color: N.gold, fontWeight: 600 }}>+${match.result.reward}</div>
                      </div>
                    )}
                    {isCurrent && (
                      <button onClick={() => setMatchPhase("preview")} style={{ padding: "8px 16px", fontSize: 12, fontWeight: 700, background: `linear-gradient(135deg, ${N.cyan}, ${N.magenta})`, border: "none", borderRadius: 6, color: "#000", cursor: "pointer" }}>MATCH DAY ▶</button>
                    )}
                    {isFuture && <span style={{ fontSize: 11, color: N.muted, fontWeight: 600 }}>Upcoming</span>}
                  </div>
                </div>
              );
            })}
            {matchIdx >= season.length && !transferWindow && !clubLeague && (() => {
              const pos = leagueTable ? getLeaguePosition(leagueTable) : 5;
              const status = getPromotionStatus(pos, leagueTable?.length || 10, currentDivision);
              const div = getDivision(currentDivision);
              const compType = getSeasonCompetition(seasonNumber);
              const compInfo = {
                club_league: { title: "CLUB LEAGUE", icon: "🏆", desc: "Qualified for the Club League!", color: N.gold },
                world_championship: { title: "WORLD CHAMPIONSHIP", icon: "🌍", desc: "Invited to the World Championship!", color: N.cyan },
                national_cup: { title: "NATIONAL CUP", icon: "🥈", desc: "Entering the National Cup!", color: "#c0c0c0" },
              }[compType];

              const statusColors = { promoted: N.green, champions: N.gold, relegated: "#ff4060", fired: "#ff2040", safe: N.muted };
              const statusLabels = { promoted: "📈 PROMOTED!", champions: "👑 LEAGUE CHAMPIONS!", relegated: "📉 RELEGATED", fired: "💀 FIRED!", safe: "✅ Safe" };

              return (
                <div style={{ textAlign: "center", padding: 30, background: N.surface, borderRadius: 12, border: `1px solid ${N.border}` }}>
                  <div style={{ fontSize: 30, marginBottom: 8 }}>{div.icon}</div>
                  <div style={{ fontSize: 20, fontWeight: 800, color: N.gold }}>Season {seasonNumber} Complete!</div>
                  <div style={{ fontSize: 13, color: div.color, fontWeight: 700, marginTop: 4 }}>{div.name}</div>
                  <div style={{ fontSize: 13, color: N.muted, marginTop: 4, marginBottom: 8 }}>
                    Finished #{pos} of {leagueTable?.length || 10} · Budget: ${money.toLocaleString()}
                  </div>

                  {/* League result */}
                  <div style={{ fontSize: 22, fontWeight: 900, color: statusColors[status], marginBottom: 12 }}>
                    {statusLabels[status]}
                  </div>

                  {status === "promoted" && <div style={{ fontSize: 12, color: N.green, marginBottom: 12 }}>Moving up to {getDivision(currentDivision - 1).name}!</div>}
                  {status === "champions" && <div style={{ fontSize: 12, color: N.gold, marginBottom: 12 }}>You're the best in the land! No higher to go!</div>}
                  {status === "relegated" && <div style={{ fontSize: 12, color: "#ff4060", marginBottom: 12 }}>Dropping down to {getDivision(currentDivision + 1).name}...</div>}
                  {status === "fired" && (
                    <div style={{ marginBottom: 12 }}>
                      <div style={{ fontSize: 12, color: "#ff4060", marginBottom: 8 }}>Bottom of the lowest division... the board has sacked you.</div>
                      <button onClick={resetSave} style={{ padding: "10px 24px", fontSize: 13, fontWeight: 700, background: `linear-gradient(135deg, #ff4060, ${N.magenta})`, border: "none", borderRadius: 6, color: "#fff", cursor: "pointer" }}>START OVER</button>
                    </div>
                  )}

                  {status !== "fired" && (
                    <div>
                      {/* Competition */}
                      <div style={{ fontSize: 13, color: compInfo.color, fontWeight: 800, marginBottom: 8, marginTop: 8 }}>
                        {compInfo.icon} {compInfo.desc}
                      </div>
                      <div style={{ padding: "8px 12px", borderRadius: 6, marginBottom: 12, background: "rgba(255,168,0,0.08)", border: "1px solid rgba(255,168,0,0.2)", maxWidth: 340, margin: "0 auto 12px", fontSize: 10, color: N.muted }}>
                        ⚠️ No Recovery Sessions during competition!
                      </div>
                      <div style={{ display: "flex", flexDirection: "column", gap: 10, alignItems: "center" }}>
                        <button onClick={() => {
                          const { world: balancedWorld } = applyPromotionRelegation();
                          startClubLeague(balancedWorld);
                        }} style={{
                          padding: "12px 30px", fontSize: 14, fontWeight: 800,
                          background: `linear-gradient(135deg, ${compInfo.color}, #ff8c00)`,
                          border: "none", borderRadius: 8, color: "#000", cursor: "pointer",
                        }}>
                          ENTER {compInfo.title} {compInfo.icon}
                        </button>
                        <button onClick={() => {
                          // "Skip Competition" = normal new season. Deals you
                          // already agreed still complete — skipping the window
                          // must not cost you money you'd earned.
                          settleAgreedSales();
                          const { newDiv, world: balancedWorld } = applyPromotionRelegation();
                          startNewSeason(newDiv, balancedWorld);
                        }} style={{
                          padding: "9px 22px", fontSize: 12, fontWeight: 700,
                          background: "transparent", border: `1px solid ${N.border}`,
                          borderRadius: 6, color: N.muted, cursor: "pointer",
                        }}>
                          ⏭️ Skip Competition · Start Next Season
                        </button>
                        <div style={{ fontSize: 9, color: N.muted, fontStyle: "italic", maxWidth: 320 }}>
                          Straight into the new season — no prize money, and no chance to buy. Deals you already agreed still complete and the fees are paid.
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })()}


          </div>

          {/* ═══ TEAM MANAGEMENT (Pre-Match) ═══ */}
          {matchPhase === "preview" && currentMatch && (
            <div style={{ position: "fixed", inset: 0, zIndex: 900, background: "rgba(0,0,0,0.85)", backdropFilter: "blur(8px)", display: "flex", alignItems: "center", justifyContent: "center", padding: 12 }}>
              <div style={{ width: "100%", maxWidth: 600, maxHeight: "95vh", overflowY: "auto", background: N.bg, borderRadius: 14, border: `1px solid ${N.border}` }}>
                {/* Header */}
                <div style={{ padding: "16px 20px", textAlign: "center", background: `linear-gradient(135deg, ${N.card}, ${N.surface})`, borderBottom: `1px solid ${N.border}`, borderRadius: "14px 14px 0 0" }}>
                  <div style={{ fontSize: 11, color: N.muted, fontWeight: 600, marginBottom: 6 }}>MATCH DAY {currentMatch.matchDay} · TEAM MANAGEMENT</div>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 20 }}>
                    <div>
                      <div style={{ fontSize: 15, fontWeight: 800, color: N.cyan }}>{clubName}</div>
                      <div style={{ fontSize: 24, fontWeight: 900, color: N.text }}>{teamOvr}</div>
                    </div>
                    <div style={{ fontSize: 16, color: N.muted, fontWeight: 700 }}>VS</div>
                    <div>
                      <div style={{ fontSize: 15, fontWeight: 800, color: "#ff6b6b" }}>{currentMatch.opponent}</div>
                      <div style={{ fontSize: 24, fontWeight: 900, color: N.text }}>{currentMatch.oppOvr}</div>
                    </div>
                  </div>
                  <span style={{ display: "inline-block", marginTop: 6, padding: "3px 10px", borderRadius: 4, fontSize: 10, fontWeight: 700, background: `${DIFFICULTY_COLORS[currentMatch.difficulty]}15`, color: DIFFICULTY_COLORS[currentMatch.difficulty], border: `1px solid ${DIFFICULTY_COLORS[currentMatch.difficulty]}30` }}>
                    {DIFFICULTY_LABELS[currentMatch.difficulty]}
                  </span>
                </div>

                {/* Pitch with tactical cards */}
                <div style={{ padding: "12px 16px 8px" }}>
                  <div style={{ width: "100%", aspectRatio: "5/4", background: "linear-gradient(180deg, #0a3d23 0%, #0d5a30 30%, #0a4525 70%, #082e19 100%)", borderRadius: 10, position: "relative", overflow: "hidden", border: `1px solid ${N.green}20` }}>
                    <div style={{ position: "absolute", top: "50%", left: "8%", right: "8%", height: 1, background: N.pitchLine }} />
                    <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)", width: 60, height: 60, borderRadius: "50%", border: `1px solid ${N.pitchLine}` }} />
                    {squad.map((player, i) => {
                      const coords = FORMATIONS[formation].coords[i];
                      const slotPos = slotPositions[i];
                      const eff = getEffectiveOvr(player, slotPos);
                      const isNatRole = player.activeRole === player.role;
                      const focusCol = FOCUS_COLORS[player.focus] || N.text;
                      return (
                        <div key={player.id} onClick={() => setEditingPlayer(editingPlayer === i ? null : i)} style={{
                          position: "absolute", left: `${coords.x}%`, top: `${coords.y}%`,
                          transform: "translate(-50%,-50%)", zIndex: editingPlayer === i ? 30 : 10,
                          cursor: "pointer",
                        }}>
                          <div style={{
                            width: 64, padding: "3px 3px 2px",
                            background: editingPlayer === i ? `${N.cyan}20` : `rgba(15,22,40,0.92)`,
                            border: `1.5px solid ${editingPlayer === i ? N.cyan : focusCol + "40"}`,
                            borderRadius: 5,
                            boxShadow: editingPlayer === i ? `0 0 8px ${N.cyan}30` : "none",
                          }}>
                            {player.injuredFor > 0 && <div style={{ position: "absolute", top: -5, right: -5, fontSize: 8, background: "#ff2040", borderRadius: "50%", width: 14, height: 14, display: "flex", alignItems: "center", justifyContent: "center" }}>🏥</div>}
                            <div style={{ fontSize: 8.5, fontWeight: 800, color: N.text, textAlign: "center", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{player.lastName}</div>
                            <div style={{ fontSize: 6.5, fontWeight: 700, textAlign: "center", color: isNatRole ? N.green : N.gold, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", marginTop: 1 }}>
                              {(player.activeRole || player.role)}{isNatRole ? "+" : ""}
                            </div>
                            <div style={{ display: "flex", justifyContent: "center", gap: 2, marginTop: 1 }}>
                              <span style={{ fontSize: 6, fontWeight: 700, color: focusCol }}>{player.focus}</span>
                              <span style={{ fontSize: 6, color: N.muted }}>·</span>
                              <span style={{ fontSize: 6, fontWeight: 700, color: N.muted }}>{slotPos}</span>
                              <span style={{ fontSize: 6, fontWeight: 800, color: statColor(eff) }}>{eff}</span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Role/Focus Editor (appears when a player is selected) */}
                {editingPlayer !== null && squad[editingPlayer] && (
                  <div style={{ padding: "8px 16px 12px", borderTop: `1px solid ${N.border}` }}>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
                      <div style={{ fontSize: 13, fontWeight: 800, color: N.text }}>
                        {squad[editingPlayer].firstName} {squad[editingPlayer].lastName}
                      </div>
                      <button onClick={() => setEditingPlayer(null)} style={{ background: "none", border: "none", color: N.muted, fontSize: 16, cursor: "pointer" }}>✕</button>
                    </div>
                    {/* Role selector */}
                    <div style={{ marginBottom: 8 }}>
                      <div style={{ fontSize: 10, fontWeight: 700, color: N.muted, marginBottom: 4 }}>PLAYER ROLE</div>
                      <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                        {getAvailableRoles(slotPositions[editingPlayer]).map((roleDef) => {
                          const isActive = squad[editingPlayer].activeRole === roleDef.role;
                          const isNatural = squad[editingPlayer].role === roleDef.role;
                          return (
                            <button key={roleDef.role} onClick={() => changePlayerRole(editingPlayer, roleDef.role)} style={{
                              padding: "7px 10px", fontSize: 10, fontWeight: 600, borderRadius: 6, cursor: "pointer",
                              textAlign: "left", display: "flex", justifyContent: "space-between", alignItems: "flex-start",
                              background: isActive ? `${N.cyan}15` : N.card,
                              border: `1px solid ${isActive ? N.cyan : N.border}`,
                              color: isActive ? N.cyan : N.text,
                            }}>
                              <div style={{ flex: 1 }}>
                                <div style={{ fontWeight: 800 }}>{roleDef.role}{isNatural ? " +" : ""}</div>
                                <div style={{ fontSize: 9, color: N.muted, marginTop: 1 }}>{roleDef.label}</div>
                                {isActive && <div style={{ fontSize: 9, color: N.cyan, marginTop: 3, lineHeight: 1.4, fontWeight: 500, opacity: 0.8 }}>{roleDef.desc}</div>}
                              </div>
                              {isActive && <span style={{ fontSize: 12, marginLeft: 6 }}>✓</span>}
                            </button>
                          );
                        })}
                      </div>
                      {(squad[editingPlayer].activeRole || squad[editingPlayer].role) === squad[editingPlayer].role && (
                        <div style={{ fontSize: 9, color: "#00ff88", marginTop: 4 }}>✅ Natural role: +1 OVR bonus</div>
                      )}
                    </div>
                    {/* Focus selector */}
                    <div>
                      <div style={{ fontSize: 10, fontWeight: 700, color: N.muted, marginBottom: 4 }}>FOCUS</div>
                      <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                        {(FOCUS_OPTIONS[slotPositions[editingPlayer]] || ["Balanced"]).map((foc) => {
                          const isActive = squad[editingPlayer].focus === foc;
                          return (
                            <button key={foc} onClick={() => changePlayerFocus(editingPlayer, foc)} style={{
                              padding: "5px 10px", fontSize: 10, fontWeight: 700, borderRadius: 4, cursor: "pointer",
                              background: isActive ? `${FOCUS_COLORS[foc]}20` : N.card,
                              border: `1px solid ${isActive ? FOCUS_COLORS[foc] : N.border}`,
                              color: isActive ? FOCUS_COLORS[foc] : N.text,
                            }}>
                              {foc}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                )}

                {/* Formation + Tactic row */}
                <div style={{ padding: "8px 16px", display: "flex", gap: 12, borderTop: `1px solid ${N.border}` }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 10, fontWeight: 700, color: N.muted, marginBottom: 4 }}>FORMATION</div>
                    <select value={formation} onChange={(e) => setFormation(e.target.value)} style={{ width: "100%", background: N.card, color: N.cyan, border: `1px solid ${N.border}`, borderRadius: 4, padding: "6px 8px", fontSize: 13, fontWeight: 700, cursor: "pointer", outline: "none" }}>
                      {FORMATION_KEYS.map((f) => <option key={f} value={f}>{f}</option>)}
                    </select>
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 10, fontWeight: 700, color: N.muted, marginBottom: 4 }}>TEAM TACTIC</div>
                    <select value={selectedTactic} onChange={(e) => setSelectedTactic(e.target.value)} style={{ width: "100%", background: N.card, color: TACTICS[selectedTactic].color, border: `1px solid ${N.border}`, borderRadius: 4, padding: "6px 8px", fontSize: 13, fontWeight: 700, cursor: "pointer", outline: "none" }}>
                      {Object.entries(TACTICS).map(([key, tac]) => <option key={key} value={key}>{tac.icon} {tac.name}</option>)}
                    </select>
                  </div>
                </div>

                {/* Injured warning */}
                {squad.filter((p) => p.injuredFor > 0).length > 0 && (
                  <div style={{ padding: "8px 16px" }}>
                    <div style={{ padding: "8px 12px", borderRadius: 6, background: "rgba(255,64,96,0.1)", border: "1px solid #ff406030", fontSize: 11, color: "#ff4060", fontWeight: 700 }}>
                      🏥 {squad.filter((p) => p.injuredFor > 0).length} injured starter(s)! Swap them in the Squad tab first.
                    </div>
                  </div>
                )}

                {/* Actions */}
                <div style={{ padding: "10px 16px 16px", display: "flex", gap: 10, justifyContent: "center" }}>
                  <button onClick={() => { setMatchPhase(null); setEditingPlayer(null); }} style={{ padding: "10px 20px", fontSize: 13, fontWeight: 700, background: N.card, border: `1px solid ${N.border}`, borderRadius: 6, color: N.muted, cursor: "pointer" }}>Back</button>
                  <button onClick={() => { setMatchPhase(null); setTab("squad"); setEditingPlayer(null); }} style={{ padding: "10px 20px", fontSize: 13, fontWeight: 700, background: N.card, border: `1px solid ${N.border}`, borderRadius: 6, color: N.cyan, cursor: "pointer" }}>Squad 🔄</button>
                  {squad.filter((p) => p.injuredFor > 0).length === 0 ? (
                    <button onClick={() => { setEditingPlayer(null); startMatch(); }} style={{ padding: "10px 30px", fontSize: 14, fontWeight: 800, background: `linear-gradient(135deg, ${N.cyan}, ${N.magenta})`, border: "none", borderRadius: 6, color: "#000", cursor: "pointer" }}>PLAY MATCH ⚔️</button>
                  ) : (
                    <button disabled style={{ padding: "10px 30px", fontSize: 14, fontWeight: 800, background: N.card, border: `1px solid ${N.border}`, borderRadius: 6, color: N.muted, cursor: "not-allowed" }}>FIX SQUAD FIRST</button>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── Global overlay modals (visible on any tab) ── */}
      {/* Club League Bracket & Matches */}
      {clubLeague && clPhase && (
        <div style={{ position: "fixed", inset: 0, zIndex: 950, background: "rgba(0,0,0,0.9)", backdropFilter: "blur(8px)", display: "flex", alignItems: "center", justifyContent: "center", padding: 16, overflowY: "auto" }}>
          <div style={{ width: "100%", maxWidth: 520, maxHeight: "90vh", overflowY: "auto" }}>

            {/* Bracket View */}
            {/* ── Groups / Bracket overview ── */}
            {clPhase === "bracket" && (
              <div style={{ background: N.surface, borderRadius: 14, border: `1px solid ${clubLeague.color}30`, overflow: "hidden" }}>
                <div style={{ padding: "20px 24px", textAlign: "center", background: "linear-gradient(135deg, #1a1000, #3a2800)", borderBottom: `1px solid ${clubLeague.color}30` }}>
                  <div style={{ fontSize: 32, marginBottom: 4 }}>{clubLeague.icon}</div>
                  <div style={{ fontSize: 22, fontWeight: 900, color: clubLeague.color }}>{clubLeague.title}</div>
                  <div style={{ fontSize: 11, color: N.muted, marginTop: 4 }}>
                    {clubLeague.format === "knockout"
                      ? `${clubLeague.field.length} clubs · straight knockout`
                      : clubLeague.stage === "group"
                        ? `${clubLeague.field.length} clubs · ${clubLeague.groups.length} groups · top 2 advance`
                        : "Knockout stage"}
                  </div>
                </div>

                {/* Next fixture */}
                {!clCurrentTie && !clubLeague.eliminated && !clubLeague.champion && (
                  // Should never happen now that every club gets a seat, but if it
                  // ever does, leave the manager a way forward instead of a dead end.
                  <div style={{ padding: "16px 20px", borderBottom: `1px solid ${N.border}`, textAlign: "center" }}>
                    <div style={{ fontSize: 12, color: N.muted, marginBottom: 10 }}>There's no fixture for you in this round.</div>
                    <button onClick={exitClubLeague} style={{
                      padding: "9px 20px", fontSize: 12, fontWeight: 800, borderRadius: 6, cursor: "pointer",
                      background: "transparent", border: `1px solid ${N.border}`, color: N.text,
                    }}>Leave competition →</button>
                  </div>
                )}
                {clCurrentTie && (
                  <div style={{ padding: "16px 20px", borderBottom: `1px solid ${N.border}`, background: `${clubLeague.color}08` }}>
                    <div style={{ fontSize: 10, fontWeight: 800, color: clubLeague.color, marginBottom: 8, textAlign: "center" }}>
                      {clCurrentTie.roundName}
                    </div>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 14, fontWeight: 800, color: N.text }}>{clCurrentTie.opponent.name}</div>
                        <div style={{ fontSize: 10, color: N.muted }}>
                          OVR {clubOvr(clCurrentTie.opponent)} · {clCurrentTie.opponent.formation} · {clCurrentTie.isHome ? "Home" : "Away"}
                        </div>
                        <div style={{ fontSize: 10, color: clubLeague.color, marginTop: 2 }}>
                          👔 {clCurrentTie.opponent.manager.name} — {managerPhilosophy(clCurrentTie.opponent.manager)}
                        </div>
                      </div>
                      <button onClick={() => setClPhase("preview")} style={{
                        padding: "9px 18px", fontSize: 12, fontWeight: 800,
                        background: `linear-gradient(135deg, ${clubLeague.color}, #ff8c00)`,
                        border: "none", borderRadius: 6, color: "#000", cursor: "pointer", whiteSpace: "nowrap",
                      }}>PLAY ▶</button>
                    </div>
                  </div>
                )}

                {/* Group tables */}
                {clubLeague.stage === "group" && (
                  <div style={{ padding: "14px 16px" }}>
                    {clubLeague.groups.map((g) => {
                      const sorted = sortTable(g.table);
                      const isYours = g.clubIds.includes(playerClubId);
                      return (
                        <div key={g.letter} style={{ marginBottom: 14, opacity: isYours ? 1 : 0.65 }}>
                          <div style={{ fontSize: 11, fontWeight: 800, color: isYours ? clubLeague.color : N.muted, marginBottom: 5 }}>
                            GROUP {g.letter}{isYours ? " — your group" : ""}
                          </div>
                          <div style={{ display: "flex", padding: "4px 8px", fontSize: 9, fontWeight: 700, color: N.muted }}>
                            <span style={{ width: 16 }}>#</span>
                            <span style={{ flex: 1 }}>Club</span>
                            <span style={{ width: 22, textAlign: "center" }}>P</span>
                            <span style={{ width: 26, textAlign: "center" }}>GD</span>
                            <span style={{ width: 26, textAlign: "center" }}>Pts</span>
                          </div>
                          {sorted.map((row, idx) => {
                            const gd = row.gf - row.ga;
                            return (
                              <div key={row.clubId} style={{
                                display: "flex", padding: "5px 8px", fontSize: 11, borderRadius: 4,
                                background: row.isYou ? `${N.cyan}10` : "transparent",
                                borderLeft: `3px solid ${idx < 2 ? N.green : "transparent"}`,
                              }}>
                                <span style={{ width: 16, fontWeight: 700, color: idx < 2 ? N.green : N.muted }}>{idx + 1}</span>
                                <span style={{ flex: 1, fontWeight: row.isYou ? 800 : 500, color: row.isYou ? N.cyan : N.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{row.name}</span>
                                <span style={{ width: 22, textAlign: "center", color: N.muted }}>{row.played}</span>
                                <span style={{ width: 26, textAlign: "center", color: gd > 0 ? N.green : gd < 0 ? "#ff4060" : N.muted }}>{gd > 0 ? "+" : ""}{gd}</span>
                                <span style={{ width: 26, textAlign: "center", fontWeight: 900, color: N.gold }}>{row.points}</span>
                              </div>
                            );
                          })}
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Knockout bracket */}
                {clubLeague.stage === "knockout" && (
                  <div style={{ padding: "14px 16px" }}>
                    {clubLeague.bracket.map((round, ri) => (
                      <div key={ri} style={{ marginBottom: 12, opacity: ri < clubLeague.knockoutRound ? 0.5 : ri === clubLeague.knockoutRound ? 1 : 0.35 }}>
                        <div style={{ fontSize: 11, fontWeight: 800, color: clubLeague.color, marginBottom: 5 }}>
                          {round.name}{ri === clubLeague.knockoutRound ? " — current" : ""}
                        </div>
                        {round.ties.length === 0 ? (
                          <div style={{ fontSize: 10, color: N.muted, fontStyle: "italic", padding: "4px 8px" }}>Awaiting qualifiers</div>
                        ) : round.ties.map((t, ti) => {
                          const h = world.find((c) => c.id === t.homeId);
                          const a = world.find((c) => c.id === t.awayId);
                          const involvesYou = t.homeId === playerClubId || t.awayId === playerClubId;
                          return (
                            <div key={ti} style={{
                              display: "flex", alignItems: "center", justifyContent: "space-between",
                              padding: "6px 10px", fontSize: 11, borderRadius: 5, marginBottom: 3,
                              background: involvesYou ? `${N.cyan}10` : N.card,
                              border: `1px solid ${involvesYou ? N.cyan + "30" : N.border}`,
                            }}>
                              <span style={{ flex: 1, fontWeight: t.homeId === playerClubId ? 800 : 500, color: t.homeId === playerClubId ? N.cyan : N.text }}>{h?.name || "TBD"}</span>
                              <span style={{ color: N.muted, fontSize: 9, padding: "0 8px" }}>vs</span>
                              <span style={{ flex: 1, textAlign: "right", fontWeight: t.awayId === playerClubId ? 800 : 500, color: t.awayId === playerClubId ? N.cyan : N.text }}>{a?.name || "TBD"}</span>
                            </div>
                          );
                        })}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* ── Pre-match ── */}
            {clPhase === "preview" && clCurrentTie && (
              <div style={{ background: N.surface, borderRadius: 14, border: `1px solid ${clubLeague.color}30`, overflow: "hidden" }}>
                <div style={{ padding: "20px 24px", textAlign: "center", background: "linear-gradient(135deg, #1a1000, #3a2800)", borderBottom: `1px solid ${clubLeague.color}30` }}>
                  <div style={{ fontSize: 11, color: clubLeague.color, fontWeight: 700, marginBottom: 6 }}>{clubLeague.icon} {clCurrentTie.roundName}</div>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 20 }}>
                    <div>
                      <div style={{ fontSize: 16, fontWeight: 800, color: N.cyan }}>{clubName}</div>
                      <div style={{ fontSize: 28, fontWeight: 900, color: N.text }}>{teamOvr}</div>
                    </div>
                    <div style={{ fontSize: 18, color: N.muted, fontWeight: 700 }}>VS</div>
                    <div>
                      <div style={{ fontSize: 16, fontWeight: 800, color: "#ff6b6b" }}>{clCurrentTie.opponent.name}</div>
                      <div style={{ fontSize: 28, fontWeight: 900, color: N.text }}>{clubOvr(clCurrentTie.opponent)}</div>
                    </div>
                  </div>
                  <div style={{ fontSize: 10, color: N.muted, marginTop: 8 }}>
                    👔 {clCurrentTie.opponent.manager.name} · {managerPhilosophy(clCurrentTie.opponent.manager)}
                  </div>
                  {!clCurrentTie.isGroup && (
                    <div style={{ fontSize: 11, color: "#ff4060", fontWeight: 700, marginTop: 6 }}>⚠️ Knockout — lose and you're out!</div>
                  )}
                </div>
                <div style={{ padding: 16 }}>
                  <h4 style={{ fontSize: 13, fontWeight: 700, color: N.cyan, margin: "0 0 10px" }}>🧠 Choose Tactic</h4>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                    {Object.entries(TACTICS).map(([key, tac]) => (
                      <div key={key} onClick={() => setSelectedTactic(key)} style={{
                        padding: "9px 11px", borderRadius: 8, cursor: "pointer",
                        background: selectedTactic === key ? `${tac.color}15` : N.card,
                        border: `1.5px solid ${selectedTactic === key ? tac.color : N.border}`,
                      }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                          <span style={{ fontSize: 15 }}>{tac.icon}</span>
                          <span style={{ fontSize: 11, fontWeight: 800, color: selectedTactic === key ? tac.color : N.text }}>{tac.name}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                {squad.filter((p) => p.injuredFor > 0).length > 0 && (
                  <div style={{ padding: "0 16px 12px" }}>
                    <div style={{ padding: "10px 14px", borderRadius: 8, background: "rgba(255,64,96,0.1)", border: "1px solid #ff406030" }}>
                      <div style={{ fontSize: 12, fontWeight: 800, color: "#ff4060" }}>🏥 Injured starters! Swap them in the Squad tab first.</div>
                    </div>
                  </div>
                )}
                <div style={{ padding: "12px 24px 20px", display: "flex", gap: 10, justifyContent: "center" }}>
                  <button onClick={() => setClPhase("bracket")} style={{ padding: "10px 24px", fontSize: 13, fontWeight: 700, background: N.card, border: `1px solid ${N.border}`, borderRadius: 6, color: N.muted, cursor: "pointer" }}>Back</button>
                  {squad.filter((p) => p.injuredFor > 0).length === 0 ? (
                    <button onClick={startClMatch} style={{ padding: "10px 30px", fontSize: 14, fontWeight: 800, background: `linear-gradient(135deg, ${clubLeague.color}, #ff8c00)`, border: "none", borderRadius: 6, color: "#000", cursor: "pointer" }}>PLAY ⚔️</button>
                  ) : (
                    <button onClick={() => { setClPhase("bracket"); setTab("squad"); }} style={{ padding: "10px 30px", fontSize: 14, fontWeight: 800, background: `linear-gradient(135deg, #ff6b6b, ${N.magenta})`, border: "none", borderRadius: 6, color: "#000", cursor: "pointer" }}>GO TO SQUAD 🔄</button>
                  )}
                </div>
              </div>
            )}

            {/* CL Match simulation */}
            {(clPhase === "simulating" || clPhase === "result") && clResult && (
              <div>
                <div style={{ background: N.surface, borderRadius: 12, padding: "20px 24px", marginBottom: 16, textAlign: "center", border: `1px solid ${(clubLeague.color || N.gold)}30` }}>
                  <div style={{ fontSize: 11, color: clubLeague.color || N.gold, fontWeight: 700, marginBottom: 8 }}>
                    {clubLeague.icon} {clCurrentTie?.roundName || clubLeague.title}
                  </div>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 24, marginBottom: 8 }}>
                    <div style={{ fontSize: 14, fontWeight: 800, color: N.cyan }}>{clubName}</div>
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <span style={{ fontSize: 40, fontWeight: 900, color: N.text }}>
                        {clPhase === "simulating" ? clResult.events.filter((e, idx) => e.type === "goal" && e.team === "home" && idx < clVisibleEvts).length : clResult.homeGoals}
                      </span>
                      <span style={{ fontSize: 20, color: N.muted }}>-</span>
                      <span style={{ fontSize: 40, fontWeight: 900, color: N.text }}>
                        {clPhase === "simulating" ? clResult.events.filter((e, idx) => e.type === "goal" && e.team === "away" && idx < clVisibleEvts).length : clResult.awayGoals}
                      </span>
                    </div>
                    <div style={{ fontSize: 14, fontWeight: 800, color: "#ff6b6b" }}>{clCurrentTie?.opponent?.name || "Opponent"}</div>
                  </div>
                  {(() => {
                    const live = liveMatchStats(clResult, clVisibleEvts, clPhase === "simulating");
                    if (!live) return null;
                    const rows = [
                      ["Possession", live.possession + "%", (100 - live.possession) + "%", live.possession],
                      ["Shots", live.homeShots, live.awayShots, (live.homeShots / Math.max(1, live.homeShots + live.awayShots)) * 100],
                      ["xG", live.homeXg.toFixed(2), live.awayXg.toFixed(2), (live.homeXg / Math.max(0.1, live.homeXg + live.awayXg)) * 100],
                    ];
                    return (
                      <div style={{ marginBottom: 8 }}>
                        {rows.map(([label, hv, av, pct]) => (
                          <div key={label} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                            <span style={{ fontSize: 11, fontWeight: 800, color: N.cyan, width: 40, textAlign: "right" }}>{hv}</span>
                            <div style={{ flex: 1 }}>
                              <div style={{ fontSize: 9, color: N.muted, textAlign: "center", marginBottom: 2 }}>{label}</div>
                              <div style={{ height: 4, background: "#ff6b6b40", borderRadius: 2, overflow: "hidden" }}>
                                <div style={{ width: `${pct}%`, height: "100%", background: N.cyan, borderRadius: 2, transition: "width 0.4s ease" }} />
                              </div>
                            </div>
                            <span style={{ fontSize: 11, fontWeight: 800, color: "#ff6b6b", width: 40 }}>{av}</span>
                          </div>
                        ))}
                      </div>
                    );
                  })()}
                  {clPhase === "simulating" && (() => {
                    const live = liveMatchStats(clResult, clVisibleEvts, true);
                    return <div style={{ fontSize: 12, color: N.green, fontWeight: 600 }}>⏱️ {live?.minute || 0}' — match in progress</div>;
                  })()}
                  {clPhase === "result" && clCurrentTie && (() => {
                    // Mirrors collectClReward exactly, so the banner never
                    // promises a different outcome or amount than you receive.
                    const won = clResult.homeGoals > clResult.awayGoals;
                    const draw = clResult.homeGoals === clResult.awayGoals;
                    const t = clCurrentTie;
                    const reward = won ? t.reward : draw && t.isGroup ? Math.round(t.reward * 0.5) : t.consolation;
                    const [label, color] = t.isGroup
                      ? (won ? ["GROUP WIN", N.gold] : draw ? ["POINT EARNED", N.cyan] : ["GROUP DEFEAT", "#ff8c66"])
                      : (won ? ["ADVANCING!", N.gold] : draw ? ["EXTRA TIME & PENALTIES", N.cyan] : ["ELIMINATED", "#ff4060"]);
                    return (
                      <div>
                        <div style={{ fontSize: 26, fontWeight: 900, color, marginBottom: 4 }}>{label}</div>
                        <div style={{ fontSize: 14, color: N.gold, fontWeight: 700 }}>+${reward}</div>
                      </div>
                    );
                  })()}
                </div>
                <div ref={clLogRef} style={{ background: N.surface, borderRadius: 12, border: `1px solid ${N.border}`, padding: 16, maxHeight: 300, overflowY: "auto", marginBottom: 16 }}>
                  <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                    {clResult.events.slice(0, clPhase === "result" ? 999 : clVisibleEvts).map((evt, i) => (
                      <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 10, padding: "8px 10px", borderRadius: 6, background: evt.type === "goal" ? `${evt.color}10` : "transparent", border: evt.type === "goal" ? `1px solid ${evt.color}25` : "1px solid transparent" }}>
                        <span style={{ fontSize: 11, fontWeight: 800, color: evt.type === "whistle" ? N.muted : evt.color, width: 36, textAlign: "center", flexShrink: 0 }}>{evt.min}'</span>
                        <span style={{ fontSize: 15 }}>{evt.icon}</span>
                        <span style={{ fontSize: 12, fontWeight: evt.type === "goal" ? 800 : 500, color: evt.type === "goal" ? evt.color : N.text }}>{evt.text}</span>
                      </div>
                    ))}
                  </div>
                </div>
                {clPhase === "result" && clResult.stats && (
                  <div style={{ background: N.surface, borderRadius: 12, border: `1px solid ${N.border}`, padding: 16, marginBottom: 16 }}>
                    <h4 style={{ fontSize: 13, fontWeight: 800, color: N.gold, margin: "0 0 10px" }}>📋 Player Ratings</h4>
                    <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                      {squad.map((p, i) => {
                        const s = clResult.stats[p.id];
                        if (!s) return null;
                        const acc = s.passes > 0 ? Math.round((s.passesCompleted / s.passes) * 100) : 100;
                        const rc = s.rating >= 8 ? N.magenta : s.rating >= 7 ? N.green : s.rating >= 6 ? N.cyan : s.rating >= 5 ? N.gold : "#ff4060";
                        const bits = [];
                        if (s.goals) bits.push(`${s.goals}G`);
                        if (s.assists) bits.push(`${s.assists}A`);
                        if (s.shots) bits.push(`${s.shots} sh`);
                        if (s.xg >= 0.05) bits.push(`${s.xg.toFixed(2)} xG`);
                        if (s.keyPasses) bits.push(`${s.keyPasses} KP`);
                        if (s.saves) bits.push(`${s.saves} sv`);
                        if (s.tackles) bits.push(`${s.tackles} tkl`);
                        bits.push(`${acc}%`);
                        return (
                          <div key={p.id} style={{ display: "flex", alignItems: "center", gap: 8, padding: "5px 8px", borderRadius: 6, background: s.rating >= 8 ? `${N.magenta}08` : "transparent" }}>
                            <span style={{ fontSize: 8, fontWeight: 700, width: 30, textAlign: "center", padding: "2px 3px", borderRadius: 3, background: N.card, color: N.muted }}>{slotPositions[i]}</span>
                            <span style={{ fontSize: 11, fontWeight: 700, color: N.text, width: 78, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{p.lastName}</span>
                            <span style={{ fontSize: 9, color: N.muted, flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{bits.join(" · ")}</span>
                            <span style={{ fontSize: 13, fontWeight: 900, color: rc, width: 30, textAlign: "right" }}>{s.rating.toFixed(1)}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
                {clPhase === "result" && (
                  <div style={{ textAlign: "center" }}>
                    <button onClick={collectClReward} style={{ padding: "14px 40px", fontSize: 15, fontWeight: 800, background: `linear-gradient(135deg, ${N.gold}, #ff8c00)`, border: "none", borderRadius: 10, color: "#000", cursor: "pointer" }}>CONTINUE ✓</button>
                  </div>
                )}
              </div>
            )}

            {/* Eliminated */}
            {clPhase === "eliminated" && (
              <div style={{ background: N.surface, borderRadius: 14, border: `1px solid #ff406030`, padding: 40, textAlign: "center" }}>
                <div style={{ fontSize: 40, marginBottom: 12 }}>😔</div>
                <div style={{ fontSize: 22, fontWeight: 900, color: "#ff4060", marginBottom: 8 }}>Eliminated from {clubLeague.title || "Club League"}</div>
                <div style={{ fontSize: 13, color: N.muted, marginBottom: 20 }}>Better luck in 3 seasons! Keep building your squad.</div>
                <button onClick={exitClubLeague} style={{ padding: "12px 30px", fontSize: 14, fontWeight: 800, background: `linear-gradient(135deg, ${N.cyan}, ${N.magenta})`, border: "none", borderRadius: 8, color: "#000", cursor: "pointer" }}>
                  TRANSFER WINDOW →
                </button>
              </div>
            )}

            {/* Champion! */}
            {clPhase === "champion" && (
              <div style={{ background: N.surface, borderRadius: 14, border: `1px solid ${N.gold}40`, padding: 40, textAlign: "center" }}>
                <div style={{ fontSize: 50, marginBottom: 12 }}>{clubLeague.icon || "🏆"}</div>
                <div style={{ fontSize: 26, fontWeight: 900, color: clubLeague.color || N.gold, marginBottom: 8 }}>{(clubLeague.title || "CLUB LEAGUE").toUpperCase()} CHAMPIONS!</div>
                <div style={{ fontSize: 15, color: N.text, marginBottom: 4 }}>{clubName} have conquered {clubLeague.type === "world_championship" ? "the world" : clubLeague.type === "national_cup" ? "the nation" : "Europe"}!</div>
                <div style={{ fontSize: 13, color: N.muted, marginBottom: 20 }}>Your name will be written in football history.</div>
                <button onClick={exitClubLeague} style={{ padding: "12px 30px", fontSize: 14, fontWeight: 800, background: `linear-gradient(135deg, ${N.gold}, #ff8c00)`, border: "none", borderRadius: 8, color: "#000", cursor: "pointer" }}>
                  TRANSFER WINDOW →
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Transfer Window Modal */}
      {transferWindow && (
        <div style={{ position: "fixed", inset: 0, zIndex: 900, background: "rgba(0,0,0,0.85)", backdropFilter: "blur(8px)", display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
          <div style={{ width: "100%", maxWidth: 560, maxHeight: "90vh", overflowY: "auto", background: N.surface, borderRadius: 14, border: `1px solid ${N.border}` }}>
            <div style={{ padding: "20px 24px", textAlign: "center", background: `linear-gradient(135deg, ${N.card}, ${N.surface})`, borderBottom: `1px solid ${N.border}`, borderRadius: "14px 14px 0 0" }}>
              <div style={{ fontSize: 28, marginBottom: 4 }}>📋</div>
              <div style={{ fontSize: 20, fontWeight: 800, color: N.text }}>Transfer Window</div>
              <div style={{ fontSize: 12, color: N.muted, marginTop: 4 }}>Season {seasonNumber} → {seasonNumber + 1}</div>
            </div>

            {/* Current Squad & Bench Viewer */}
            <details style={{ borderBottom: `1px solid ${N.border}` }}>
              <summary style={{ padding: "12px 24px", fontSize: 13, fontWeight: 700, color: N.cyan, cursor: "pointer", userSelect: "none" }}>
                📊 View Current Squad ({squad.length} starters, {bench.length} bench)
              </summary>
              <div style={{ padding: "0 24px 16px" }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: N.muted, marginBottom: 6 }}>STARTING XI</div>
                <div style={{ display: "flex", flexDirection: "column", gap: 3, marginBottom: 12 }}>
                  {squad.map((p, i) => {
                    const ts2 = TIER_STYLES[getTier(p.ovr)];
                    return (
                      <div key={p.id} style={{ display: "flex", alignItems: "center", gap: 8, padding: "5px 8px", borderRadius: 4, background: N.card }}>
                        <span style={{ fontSize: 12, fontWeight: 900, color: ts2.accent, width: 24, textAlign: "center" }}>{p.ovr}</span>
                        <span style={{ fontSize: 8, fontWeight: 700, padding: "2px 5px", borderRadius: 3, background: ts2.bg, color: ts2.text }}>{slotPositions[i]}</span>
                        <span style={{ fontSize: 11, fontWeight: 600, color: N.text, flex: 1 }}>{p.firstName[0]}. {p.lastName}</span>
                        <span style={{ fontSize: 9, color: N.muted }}>{p.role}</span>
                        <span style={{ fontSize: 9, color: N.gold }}>${getPlayerSalary(p)}</span>
                      </div>
                    );
                  })}
                </div>
                {bench.length > 0 && (
                  <>
                    <div style={{ fontSize: 11, fontWeight: 700, color: N.muted, marginBottom: 6 }}>BENCH</div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
                      {bench.map((p) => {
                        const ts2 = TIER_STYLES[getTier(p.ovr)];
                        return (
                          <div key={p.id} style={{ display: "flex", alignItems: "center", gap: 5, padding: "4px 8px", borderRadius: 4, background: N.card, border: `1px solid ${N.border}` }}>
                            <span style={{ fontSize: 11, fontWeight: 800, color: ts2.accent }}>{p.ovr}</span>
                            <span style={{ fontSize: 9, color: N.muted }}>{p.naturalPosition}</span>
                            <span style={{ fontSize: 10, color: N.text }}>{p.lastName}</span>
                          </div>
                        );
                      })}
                    </div>
                  </>
                )}
              </div>
            </details>

            {/* Agreed signings arriving */}
            {transferWindow.pending && transferWindow.pending.length > 0 && (
              <div style={{ padding: "16px 24px", borderBottom: `1px solid ${N.border}`, background: `${N.green}05` }}>
                <h3 style={{ fontSize: 14, fontWeight: 700, color: N.green, margin: "0 0 10px" }}>
                  ✍️ Agreed Signings Arriving ({transferWindow.pending.length})
                </h3>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {transferWindow.pending.map((ps, i) => {
                    const p = ps.player;
                    const ts2 = TIER_STYLES[getTier(p.ovr)];
                    return (
                      <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", borderRadius: 8, background: N.card, border: `1px solid ${N.green}25` }}>
                        <span style={{ fontSize: 14, fontWeight: 900, color: ts2.accent, width: 26, textAlign: "center" }}>{p.ovr}</span>
                        <span style={{ fontSize: 9, fontWeight: 700, padding: "2px 6px", borderRadius: 3, background: ts2.bg, color: ts2.text }}>{p.naturalPosition}</span>
                        <div style={{ flex: 1 }}>
                          <div style={{ fontSize: 12, fontWeight: 700, color: N.text }}>{p.firstName} {p.lastName}</div>
                          <div style={{ fontSize: 10, color: N.muted }}>Age {p.age} · ${ps.salary}/match · Clause ${ps.clause}</div>
                        </div>
                        <span style={{ fontSize: 10, color: N.green, fontWeight: 700 }}>JOINING ✓</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Departures */}
            <div style={{ padding: "16px 24px", borderBottom: `1px solid ${N.border}` }}>
              <h3 style={{ fontSize: 14, fontWeight: 700, color: "#ff6b6b", margin: "0 0 12px" }}>
                👋 Players Wanting to Leave
              </h3>
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {transferWindow.departures.map((dep, i) => {
                  const decided = transferWindow.decisions[`dep-${i}`];
                  const ts = TIER_STYLES[getTier(dep.player.ovr)];
                  return (
                    <div key={dep.player.id} style={{
                      padding: "12px", borderRadius: 8, background: N.card,
                      border: `1px solid ${decided === true ? N.green + "40" : decided === false ? "#ff406040" : N.border}`,
                    }}>
                      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 6 }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                          <span style={{ fontSize: 14, fontWeight: 900, color: ts.accent }}>{dep.player.ovr}</span>
                          <span style={{ fontSize: 9, fontWeight: 700, padding: "2px 6px", borderRadius: 3, background: ts.bg, color: ts.text }}>{dep.player.naturalPosition}</span>
                          <span style={{ fontSize: 13, fontWeight: 700, color: N.text }}>{dep.player.firstName} {dep.player.lastName}</span>
                        </div>
                        <span style={{ fontSize: 13, fontWeight: 800, color: N.gold }}>+${dep.value}</span>
                      </div>
                      <div style={{ fontSize: 11, color: N.muted, marginBottom: 4 }}>"{dep.reason}"</div>
                      {dep.player.altPositions?.length > 0 && (
                        <div style={{ display: "flex", gap: 4, marginBottom: 6, alignItems: "center" }}>
                          <span style={{ fontSize: 9, color: N.muted }}>Alt:</span>
                          {dep.player.altPositions.map((ap) => (
                            <span key={ap} style={{ fontSize: 9, fontWeight: 700, padding: "1px 6px", borderRadius: 3, background: `${N.green}15`, color: N.green, border: `1px solid ${N.green}25` }}>{ap}</span>
                          ))}
                        </div>
                      )}
                      {decided === undefined ? (
                        <div style={{ display: "flex", gap: 8 }}>
                          <button onClick={() => handleTransferDecision("dep", i, true)} style={{ flex: 1, padding: "6px", fontSize: 11, fontWeight: 700, background: `${N.green}15`, border: `1px solid ${N.green}30`, borderRadius: 4, color: N.green, cursor: "pointer" }}>
                            Accept · Receive ${dep.value}
                          </button>
                          <button onClick={() => handleTransferDecision("dep", i, false)} style={{ flex: 1, padding: "6px", fontSize: 11, fontWeight: 700, background: "#ff406010", border: "1px solid #ff406030", borderRadius: 4, color: "#ff6b6b", cursor: "pointer" }}>
                            Reject · -5 Morale
                          </button>
                        </div>
                      ) : (
                        <div style={{ fontSize: 11, fontWeight: 700, color: decided ? N.green : "#ff6b6b" }}>
                          {decided ? "✅ Transfer accepted" : "❌ Transfer rejected"}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Arrivals */}
            <div style={{ padding: "16px 24px", borderBottom: `1px solid ${N.border}` }}>
              <h3 style={{ fontSize: 14, fontWeight: 700, color: N.green, margin: "0 0 12px" }}>
                🆕 Players Wanting to Join
              </h3>
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {transferWindow.arrivals.map((arr, i) => {
                  const decided = transferWindow.decisions[`arr-${i}`];
                  const ts = TIER_STYLES[getTier(arr.player.ovr)];
                  return (
                    <div key={arr.player.id} style={{
                      padding: "12px", borderRadius: 8, background: N.card,
                      border: `1px solid ${decided === true ? N.green + "40" : decided === false ? N.border : N.border}`,
                    }}>
                      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 6 }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                          <span style={{ fontSize: 14, fontWeight: 900, color: ts.accent }}>{arr.player.ovr}</span>
                          <span style={{ fontSize: 9, fontWeight: 700, padding: "2px 6px", borderRadius: 3, background: ts.bg, color: ts.text }}>{arr.player.naturalPosition}</span>
                          <span style={{ fontSize: 13, fontWeight: 700, color: N.text }}>{arr.player.firstName} {arr.player.lastName}</span>
                        </div>
                        <div style={{ textAlign: "right" }}>
                          <div style={{ fontSize: 11, color: N.gold, fontWeight: 700 }}>Fee: ${arr.askingFee}</div>
                          <div style={{ fontSize: 10, color: N.muted }}>Salary: ${arr.salary}/match</div>
                        </div>
                      </div>
                      <div style={{ fontSize: 10, color: N.muted, marginBottom: 8 }}>
                        {arr.player.role} · {arr.player.nationality} · Age {arr.player.age}
                      </div>
                      {arr.player.altPositions?.length > 0 && (
                        <div style={{ display: "flex", gap: 4, marginBottom: 6, alignItems: "center" }}>
                          <span style={{ fontSize: 9, color: N.muted }}>Alt:</span>
                          {arr.player.altPositions.map((ap) => (
                            <span key={ap} style={{ fontSize: 9, fontWeight: 700, padding: "1px 6px", borderRadius: 3, background: `${N.green}15`, color: N.green, border: `1px solid ${N.green}25` }}>{ap}</span>
                          ))}
                        </div>
                      )}
                      {decided === undefined ? (
                        <div style={{ display: "flex", gap: 8 }}>
                          <button onClick={() => handleTransferDecision("arr", i, true)} disabled={money < arr.askingFee}
                            style={{ flex: 1, padding: "6px", fontSize: 11, fontWeight: 700, background: money >= arr.askingFee ? `${N.green}15` : N.card, border: `1px solid ${money >= arr.askingFee ? N.green + "30" : N.border}`, borderRadius: 4, color: money >= arr.askingFee ? N.green : N.muted, cursor: money >= arr.askingFee ? "pointer" : "not-allowed" }}>
                            {money >= arr.askingFee ? `Sign · Pay $${arr.askingFee}` : "Can't afford"}
                          </button>
                          <button onClick={() => handleTransferDecision("arr", i, false)} style={{ flex: 1, padding: "6px", fontSize: 11, fontWeight: 700, background: N.card, border: `1px solid ${N.border}`, borderRadius: 4, color: N.muted, cursor: "pointer" }}>
                            Pass
                          </button>
                        </div>
                      ) : (
                        <div style={{ fontSize: 11, fontWeight: 700, color: decided ? N.green : N.muted }}>
                          {decided ? "✅ Player signed!" : "— Passed"}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Confirm */}
            <div style={{ padding: "16px 24px 20px", textAlign: "center" }}>
              {Object.keys(transferWindow.decisions).length >= transferWindow.departures.length + transferWindow.arrivals.length ? (
                <button onClick={confirmTransfers} style={{
                  padding: "12px 36px", fontSize: 14, fontWeight: 800,
                  background: `linear-gradient(135deg, ${N.cyan}, ${N.magenta})`,
                  border: "none", borderRadius: 8, color: "#000", cursor: "pointer",
                }}>
                  CONFIRM & START SEASON {seasonNumber + 1} ▶
                </button>
              ) : (
                <div style={{ fontSize: 12, color: N.muted }}>
                  Decide on all transfers to continue ({Object.keys(transferWindow.decisions).length}/{transferWindow.departures.length + transferWindow.arrivals.length})
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ═══ MORALE TAB ═══ */}
      {tab === "morale" && (
        <div style={{ maxWidth: 700, margin: "0 auto", padding: "24px 16px" }} onClick={(e) => e.stopPropagation()}>
          <div style={{ textAlign: "center", marginBottom: 20 }}>
            <h2 style={{ fontSize: 22, fontWeight: 800, color: N.text, margin: "0 0 4px" }}>
              <span style={{ background: `linear-gradient(135deg, ${N.cyan}, ${N.magenta})`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>Team Morale</span>
            </h2>
            <p style={{ color: N.muted, fontSize: 13, margin: 0 }}>Keep your squad happy and performing</p>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {/* Big Morale Display */}
            <div style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 12, padding: 20 }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
                <div>
                  <div style={{ fontSize: 16, fontWeight: 800, color: N.text }}>Team Morale</div>
                  <div style={{ fontSize: 12, color: getMoraleColor(morale), fontWeight: 700 }}>
                    {getMoraleLabel(morale)} · {getMoraleMatchBonus(morale) >= 0 ? "+" : ""}{getMoraleMatchBonus(morale)} match OVR
                  </div>
                </div>
                <div style={{ fontSize: 36, fontWeight: 900, color: getMoraleColor(morale) }}>{morale}</div>
              </div>
              <div style={{ width: "100%", height: 12, background: "#1a2236", borderRadius: 6, overflow: "hidden" }}>
                <div style={{ width: `${morale}%`, height: "100%", background: getMoraleColor(morale), borderRadius: 6, transition: "width 0.4s ease" }} />
              </div>
              <div style={{ marginTop: 10, fontSize: 11, color: N.muted, lineHeight: 1.6 }}>
                Morale affects match performance. Win matches, maintain chemistry, pay salaries, and upgrade training to keep it high.
                {morale < 30 && <span style={{ color: "#ff4060", fontWeight: 700 }}> ⚠️ Critically low! Players may leave!</span>}
              </div>
            </div>

            {/* Overview Bars */}
            <div style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 12, padding: 20 }}>
              <h3 style={{ fontSize: 14, fontWeight: 700, color: N.cyan, margin: "0 0 16px" }}>📊 Team Overview</h3>
              <BarChart items={[
                { label: "Morale", value: morale, max: 100, color: getMoraleColor(morale), valueLabel: getMoraleLabel(morale) },
                { label: "Chemistry", value: chemistry.total, max: 100, color: chemistry.total >= 60 ? N.green : chemistry.total >= 35 ? N.gold : "#ff4060", valueLabel: `${chemistry.total}/100` },
                { label: "Avg Fitness", value: Math.round(squad.reduce((s, p) => s + (p.fitness ?? 100), 0) / Math.max(1, squad.length)), max: 100, color: getFitnessColor(Math.round(squad.reduce((s, p) => s + (p.fitness ?? 100), 0) / Math.max(1, squad.length))), valueLabel: `${Math.round(squad.reduce((s, p) => s + (p.fitness ?? 100), 0) / Math.max(1, squad.length))}%` },
                { label: "Training", value: (trainingLevel + 1) * 25, max: 100, color: TRAINING_LEVELS[trainingLevel].color, valueLabel: TRAINING_LEVELS[trainingLevel].name },
              ]} />
            </div>

            {/* Training Facility */}
            <div style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 12, padding: 20 }}>
              <h3 style={{ fontSize: 14, fontWeight: 700, color: N.cyan, margin: "0 0 4px" }}>🏋️ Training Facility</h3>
              <p style={{ fontSize: 11, color: N.muted, margin: "0 0 16px" }}>Better training = faster recovery, match bonuses, and happier players</p>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                {TRAINING_LEVELS.map((level, i) => {
                  const isCurrent = trainingLevel === i;
                  const isNext = trainingLevel === i - 1;
                  const isLocked = i > trainingLevel + 1;
                  const isPast = i < trainingLevel;
                  return (
                    <div key={i} style={{ flex: "1 1 120px", padding: "12px", borderRadius: 8, background: isCurrent ? `${level.color}12` : N.card, border: `1.5px solid ${isCurrent ? level.color : N.border}`, opacity: isLocked ? 0.4 : 1 }}>
                      <div style={{ fontSize: 12, fontWeight: 800, color: isCurrent ? level.color : isPast ? N.green : N.text, marginBottom: 4 }}>
                        {isPast ? "✅ " : isCurrent ? "⭐ " : ""}{level.name}
                      </div>
                      <div style={{ fontSize: 10, color: N.muted, marginBottom: 2 }}>Recovery: +{level.benchRecovery}/match</div>
                      <div style={{ fontSize: 10, color: N.muted, marginBottom: 2 }}>Match bonus: +{level.matchBonus} OVR</div>
                      <div style={{ fontSize: 10, color: N.muted, marginBottom: 8 }}>Morale boost: +{level.moraleBoost}/match</div>
                      {isNext && (
                        <button onClick={upgradeTraining} disabled={money < level.cost} style={{
                          width: "100%", padding: "6px", fontSize: 11, fontWeight: 700, borderRadius: 4,
                          background: money >= level.cost ? `linear-gradient(135deg, ${N.cyan}, ${N.magenta})` : N.card,
                          border: money >= level.cost ? "none" : `1px solid ${N.border}`,
                          color: money >= level.cost ? "#000" : N.muted,
                          cursor: money >= level.cost ? "pointer" : "not-allowed",
                        }}>
                          Upgrade ${level.cost}
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Salary Breakdown */}
            <div style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 12, padding: 20 }}>
              <h3 style={{ fontSize: 14, fontWeight: 700, color: N.cyan, margin: "0 0 4px" }}>💰 Salary Overview</h3>
              <p style={{ fontSize: 11, color: N.muted, margin: "0 0 12px" }}>Salaries are deducted from match rewards. Can't pay = morale tanks and players leave.</p>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 14px", borderRadius: 8, background: N.card, marginBottom: 12 }}>
                <span style={{ fontSize: 13, fontWeight: 700, color: N.text }}>Total Squad Salary</span>
                <span style={{ fontSize: 18, fontWeight: 900, color: N.gold }}>${getTotalSalary(squad) + hiredScouts.reduce((s, sc) => s + sc.wage, 0)}/match</span>
              </div>
              {hiredScouts.length > 0 && (
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 14px", borderRadius: 8, background: N.card, marginBottom: 12, fontSize: 11 }}>
                  <span style={{ color: N.muted }}>🕵️ Scout wages ({hiredScouts.length} staff)</span>
                  <span style={{ fontWeight: 700, color: N.gold }}>${hiredScouts.reduce((s, sc) => s + sc.wage, 0)}/match</span>
                </div>
              )}
              <div style={{ display: "flex", flexDirection: "column", gap: 4, maxHeight: 200, overflowY: "auto" }}>
                {[...squad].sort((a, b) => getPlayerSalary(b) - getPlayerSalary(a)).map((p) => (
                  <div key={p.id} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "6px 10px" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <span style={{ fontSize: 11, fontWeight: 800, color: TIER_STYLES[getTier(p.ovr)].accent }}>{p.ovr}</span>
                      <span style={{ fontSize: 11, color: N.text }}>{p.firstName[0]}. {p.lastName}</span>
                    </div>
                    <span style={{ fontSize: 11, fontWeight: 700, color: N.gold }}>${getPlayerSalary(p)}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Warnings */}
            {(morale < 30 || chemistry.total < 30 || getTotalSalary(squad) > money) && (
              <div style={{ background: "rgba(255,64,96,0.08)", border: "1px solid #ff406030", borderRadius: 12, padding: 20 }}>
                <h3 style={{ fontSize: 14, fontWeight: 700, color: "#ff4060", margin: "0 0 12px" }}>⚠️ Warnings</h3>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {morale < 30 && <div style={{ fontSize: 12, color: "#ff4060" }}>😤 Morale is critically low! Players may demand transfers.</div>}
                  {chemistry.total < 30 && <div style={{ fontSize: 12, color: "#ff4060" }}>💔 Chemistry is terrible! Players feel isolated and may leave.</div>}
                  {getTotalSalary(squad) > money && <div style={{ fontSize: 12, color: "#ff4060" }}>💸 You can't afford your squad's salary! Your best player may leave.</div>}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ═══ TROPHY CASE TAB ═══ */}
      {tab === "trophies" && (() => {
        const prestige = calculatePrestige(trophies);
        const pLabel = getPrestigeLabel(prestige);
        const arrivalBonus = getPrestigeArrivalBonus(prestige);

        return (
          <div style={{ maxWidth: 700, margin: "0 auto", padding: "24px 16px" }} onClick={(e) => e.stopPropagation()}>
            <div style={{ textAlign: "center", marginBottom: 20 }}>
              <h2 style={{ fontSize: 22, fontWeight: 800, color: N.text, margin: "0 0 4px" }}>
                <span style={{ background: `linear-gradient(135deg, ${N.gold}, #ff8c00)`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>Trophy Case</span>
              </h2>
              <p style={{ color: N.muted, fontSize: 13, margin: 0 }}>Your legacy as a manager</p>
            </div>

            {/* Prestige Score */}
            <div style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 12, padding: 20, marginBottom: 16, textAlign: "center" }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: N.muted, marginBottom: 4 }}>CLUB PRESTIGE</div>
              <div style={{ fontSize: 40, fontWeight: 900, color: pLabel.color, lineHeight: 1 }}>{prestige}</div>
              <div style={{ fontSize: 14, fontWeight: 800, color: pLabel.color, marginTop: 4 }}>{pLabel.label}</div>
              <div style={{ fontSize: 11, color: N.muted, marginTop: 8 }}>Transfer bonus: elite players up to +{arrivalBonus} OVR higher want to join</div>
              <div style={{ width: "80%", height: 6, background: "#1a2236", borderRadius: 3, overflow: "hidden", margin: "8px auto 0" }}>
                <div style={{ width: `${Math.min(100, prestige)}%`, height: "100%", background: `linear-gradient(90deg, ${N.green}, ${N.gold}, ${N.magenta})`, borderRadius: 3 }} />
              </div>
            </div>

            {/* Trophies */}
            <div style={{ background: N.surface, border: `1px solid ${N.border}`, borderRadius: 12, padding: 20 }}>
              <h3 style={{ fontSize: 14, fontWeight: 700, color: N.gold, margin: "0 0 12px" }}>🏆 Trophies ({trophies.length})</h3>
              {trophies.length === 0 ? (
                <div style={{ fontSize: 12, color: N.muted, textAlign: "center", padding: 20 }}>No trophies yet. Win a competition to earn your first! 🏆</div>
              ) : (
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(140px, 1fr))", gap: 10 }}>
                  {trophies.map((t, i) => (
                    <div key={i} style={{
                      padding: "14px 12px", borderRadius: 10, textAlign: "center",
                      background: `linear-gradient(135deg, ${TROPHY_PRESTIGE[t.type] >= 15 ? "#0a1848" : TROPHY_PRESTIGE[t.type] >= 10 ? "#1a1000" : "#1a1a20"}, ${N.card})`,
                      border: `1px solid ${TROPHY_PRESTIGE[t.type] >= 15 ? N.cyan + "30" : TROPHY_PRESTIGE[t.type] >= 10 ? N.gold + "30" : "#c0c0c030"}`,
                    }}>
                      <div style={{ fontSize: 28, marginBottom: 4 }}>{t.icon}</div>
                      <div style={{ fontSize: 11, fontWeight: 800, color: N.text }}>{t.title}</div>
                      <div style={{ fontSize: 10, color: N.muted, marginTop: 2 }}>Season {t.season}</div>
                      <div style={{ fontSize: 9, color: N.gold, marginTop: 2 }}>+{TROPHY_PRESTIGE[t.type]} prestige</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        );
      })()}
    </div>
  );
}
